systems-installer
=================

README last updated on 09/29/15 for 8.4 <br>
        - added support for the new 8.4 style installers, and enhanced the "-ip auto" functionality 

NOTE: To use automated installer with oracle 12. give the name of the pluggable database in the -orasid option. and give the option -db_version oracle_12

NOTE: Any database on the automation servers NOT following the automation name format are candidates for deletion.


The installer.jar must be executed on the UIM server.

EXAMPLES
========================================================================================================================

UIM:

    java -jar Installer.jar -drop -ip <IP OF UIM SYSTEM> -version 8.30 -install NMS -db_type Oracle
          -db_server <IP OF DB SERVER> -domain <DOMAIN NAME> -hub <HUB NAME> -robot <ROBOT NAME>

UMP:
    
    java -jar Installer.jar -ip <IP OF UIM SYSTEM> -version 8.30 -install UMP -domain <DOMAIN NAME> 
          -hub <HUB NAME> -robot <ROBOT NAME> -user administrator -password t3sti9

Robot:

    java -jar Installer.jar -ip auto -install robot -domain <DOMAIN NAME> -hub <HUB NAME> -robot <ROBOT NAME>
          -user administrator -password t3sti9 -targets <IP OF robot SYSTEM>,<IP OF robot SYSTEM>


========================================================================================================================



USAGE HELP
========================================================================================================================

-bitsonly                                          (optional) stages bits but does not start the installation

-bnpp                                              (optional) Uses bnpp installers

-build \<build\>                                     (optional) build date to install:
                                                    NMS: YYYY_MM_DD-mm_ss
                                                    UMP: YYYY-MM-DD

-custom_path \<custom_path\>                         (optional) full path from fileshare to the location of the Installer
                                                to be used, starting a fileshare\QA\

-db_auth \<db_auth\>                                 (optional) sqlserver_dbauthmode_sqlserver | sqlserver_dbauthmode_windows
                                                     NOTE: MSSQL only. sqlserver_dbauthmode_windows for Windows Authentication.

-db_name \<NIMDBNAME\>                               (optional) Nimsoft database name

-db_pass \<DB_ADMIN_PASSWORD\>                       (optional) Database password for MSSQL||MYSQL

-db_port \<DB_PORT\>                                 (optional) Database port

-db_server \<DB_SERVER\>                             (optional) Database server

-db_type \<db_type\>                                 MSSQL|MySQL|ORACLE

-db_user \<DB_ADMIN_USER\>                           (optional) Database username for MSSQL||MYSQL

-db_version \<DB_VERSION\>                           Oracle Version: use oracle_12 if you want to install as oracle 12
                                                to the automation database

-domain \<NMSDOMAIN\>                                Nimsoft domain name
                                                NMS: (optional)
                                                UMP: (required)

-drop \<drop\>                                       (optional) Drop database if it exists
                                                NOTE: Will drop default 'ip_auto' db if not specified on command line

-help                                              Display usage

-hub \<NMSHUB\>                                      Nimsoft hub name
                                                NMS: (optional)
                                                UMP: (required)

-hubrobotname \<HUBROBOTNAME\>                       Name of the robot containing the hub for the installed robot to
                                                connect to

-hubversion \<HUBVERSION\>                           Version of the hub to  deploy

-install \<install\>                                 NMS|UMP|ROBOT|HUB

-install_robot \<INSTALL_ROBOT\>                     Remote installation of a robot option
                                                    NMS: (optional)
                                                    UMP: (optional)

-instantclient_dir \<DB_ORACLE_INSTANTCLIENT_DIR\>   Path to the Oracle instant client directory

-ip \<ip\>                                           IP address of system installing to. can also use "auto" to find the IP of the system. 

-local_installer \<local_installer\>                 (optional) full path location of the installer to be used

-nimdb_pass \<NIMDB_PASS\>                           (optional) Oracle database password

-nimdb_user \<NIMDB_USER\>                           (optional) Oracle database user

-orasid \<ORASID\>                                   (optional) Oracle SID or service name or pdbName

-password \<NIMBUS_PASSWORD\>                        Nimsoft password
                                                    NMS: (optional)
                                                    UMP: (required)

-properties \<properties\>                           (optional) custom properties file, will fill properties contained in
                                                this file

-robot \<NMSROBOT\>                                  Nimsoft robot name
                                                    NMS: (optional)
                                                    UMP: (required)

-robot_ip \<UMP_ROBOT_IP\>                           Remote robot ip (REQUIRED if -robot_name option is used)

-robot_name \<UMP_ROBOT\>                            Remote robot name to deploy UMP to (OPTIONAL)

-secondary_robots \<SECONDARY_ROBOTS\>               Comma-separated list of robot names for multi UMP install.

-targets \<TARGETS\>                                 Comma-separated list of robot names for ADE installation

-user \<NIMBUS_USERNAME\>                            Nimsoft username (REQUIRED for UMP installs)

-user_install_dir \<USER_INSTALL_DIR\>               (optional) custom Nimsoft install location

-version \<version\>                                 Version to install



========================================================================================================================
