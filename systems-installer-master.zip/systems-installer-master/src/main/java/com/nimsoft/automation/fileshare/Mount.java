package com.nimsoft.automation.fileshare;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileNotFoundException;
import java.io.IOException;


/**
 * Created by lisdu02 on 1/23/14.
 *
 */
public class Mount {
    static Logger logger = LoggerFactory.getLogger(Mount.class);

    /*
     * Only responsibility should be to handle mounting of drives for Windows
     */

    private final String FILESHARE = "fileshare.dev.fco";
    private final String USER = "qateam";
    private final String PASSWD = "t3sti9";

    private String fullDir;
    private String drive;

    public Mount(String fullDir) {
        this.fullDir = fullDir;
        setDrive();
    }

    public String setDrive() {
        drive = fullDir.substring(0,fullDir.indexOf("NimBUS")).replace("\\","");
        logger.info("Drive = " + drive);
        return drive;
    }

    public int unmountFileshare() {
        String[] unmountCmdArray = {"net","use","/delete", "/yes", drive};
        CommandLine unmountCmdCL = buildCommandLine(unmountCmdArray);
        return executeCmd(unmountCmdCL);
    }

    public int mountFileshare() throws FileNotFoundException {
        String[] mountArray;
        logger.info("Checking to see if windows drive is busy");
        //* Attempting to mount the drive */
        mountArray = new String[] {"net", "use", drive, "\\\\" + FILESHARE + "\\QA" , "/user:" + USER + "\\username", PASSWD};
        CommandLine mountCmdCL = buildCommandLine(mountArray);
        return executeCmd(mountCmdCL);
    }


    public CommandLine buildCommandLine(String[] cmdArray) {
        CommandLine cmdLine;
        cmdLine = new CommandLine(cmdArray[0]);
        int maxLength = cmdArray.length;
        int count = 1;
        while (count != maxLength) {
            cmdLine.addArgument(cmdArray[count]);
            count++;
        }

        return cmdLine;
    }

    public int executeCmd(CommandLine cmdLine) {
        int exitValue = -1;
        DefaultExecutor executor = new DefaultExecutor();
        executor.setExitValue(0);
        logger.info("Attempting to run command [" + cmdLine.toString() + "]");
        try {
            exitValue = executor.execute(cmdLine);
            return exitValue;
        } catch (ExecuteException e) {
            logger.error(e.getMessage(), e);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
        return exitValue;
    }

}
