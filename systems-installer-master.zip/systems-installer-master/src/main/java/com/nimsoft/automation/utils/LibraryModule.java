package com.nimsoft.automation.utils;

import java.io.*;

/**
 * Created by krasa02 on 2/29/2016.
 */
public enum LibraryModule {

    MSSQL_WIN_AUTH("sqljdbc_auth", "dll");

    private String libraryName, libraryExtension;
    public static final String LIBRARY_FOLDER="libs";
    public static final String X64 = "amd64";

    LibraryModule(String libraryName, String libraryExtension) {
        this.libraryName = libraryName;
        this.libraryExtension = libraryExtension;
    }

    public void loadLibrary() throws IOException {
        try {
            System.loadLibrary(this.libraryName);
        } catch(UnsatisfiedLinkError e) {
            loadLibraryFromJar();
        }
    }

    private String getSystemArch() {
        if(X64.equalsIgnoreCase(System.getProperty("os.arch"))) {
            return "x64";
        } else {
            return "x86";
        }
    }

    private File extractLibraryFromJar() throws IOException {
        InputStream libraryFileInputStream = getClass().getClassLoader().getResourceAsStream(LIBRARY_FOLDER + "/" + getSystemArch() + "/" + getLibraryName()+"." + getLibraryExtension());
        File temporaryLibraryFile = new File(getLibraryName()+"."+getLibraryExtension());
        temporaryLibraryFile.createNewFile();
        OutputStream outputStream = new BufferedOutputStream(new FileOutputStream(temporaryLibraryFile));
        byte[] buffer = new byte[2048];
        for(;;) {
            int nBytes = libraryFileInputStream.read(buffer);
            if(nBytes <= 0) break;
            outputStream.write(buffer,0,nBytes);
        }
        outputStream.flush();
        outputStream.close();
        libraryFileInputStream.close();
        return temporaryLibraryFile;
    }

    private void loadLibraryFromJar() throws IOException {
        System.load(extractLibraryFromJar().getAbsolutePath());
    }

    public String getLibraryExtension() {
        return libraryExtension;
    }

    public void setLibraryExtension(String libraryExtension) {
        this.libraryExtension = libraryExtension;
    }

    public String getLibraryName() {
        return libraryName;
    }

    public void setLibraryName(String libraryName) {
        this.libraryName = libraryName;
    }
}
