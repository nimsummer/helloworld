package com.nimsoft.automation.database;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by lisdu02 on 1/30/14.
 *
 */
public class DBConnectionInfo {

    static Logger logger = LoggerFactory.getLogger(DBConnectionInfo.class);

    private final List<String> DB_TYPES = Arrays.asList("mssql", "mysql", "oracle");

    public static final String MICROSOFT_SQL = "mssql";

    private String dbType;
    private String dbUsername;
    private String dbPassword;
    private String dbServer;
    private String dbName;
    private String dbPort;
    private String oracleSID = "ORCLAUTO";
    private boolean oracle12 = false;
    private boolean dbUserOnly;
    private boolean isWindowsAuthentication;

    public DBConnectionInfo(String dbType, String dbServer, String dbName, String dbUsername, String dbPassword, String dbPort) {
        if(dbType.equalsIgnoreCase("sqlserver")) dbType = "mssql";
        if (!DB_TYPES.contains(dbType.toLowerCase()))
            throw new IllegalArgumentException("Unknown dbType passed: " + dbType + "\n" + "Supported dbTypes are: " + DB_TYPES.toString());

        this.dbType = dbType.toLowerCase();
        this.dbServer = dbServer;
        this.dbName = dbName;
        this.dbUsername = dbUsername;
        this.dbPassword = dbPassword;
        this.dbPort = dbPort;
        this.dbUserOnly = false;
    }

    public DBConnectionInfo(String dbType, String dbServer, String dbUsername, String dbPassword, String dbPort) {
        if(dbType.equalsIgnoreCase("sqlserver")) dbType = "mssql";
        if (!DB_TYPES.contains(dbType.toLowerCase()))
            throw new IllegalArgumentException("Unknown dbType passed: " + dbType + "\n" + "Supported dbTypes are: " + DB_TYPES.toString());

        this.dbType = dbType.toLowerCase();
        this.dbServer = dbServer;
        this.dbName = "";
        this.dbUsername = dbUsername;
        this.dbPassword = dbPassword;
        this.dbPort = dbPort;
        this.dbUserOnly = false;
    }

    public DBConnectionInfo(String dbType, String dbServer, String dbName, String dbUsername, String dbPassword, String oracleSID, String dbPort) {
        if(dbType.equalsIgnoreCase("sqlserver")) dbType = "mssql";
        if (!DB_TYPES.contains(dbType.toLowerCase()))
            throw new IllegalArgumentException("Unknown dbType passed: " + dbType + "\n" + "Supported dbTypes are: " + DB_TYPES.toString());

        this.dbType = dbType.toLowerCase();
        this.dbServer = dbServer;
        this.dbName = dbName;
        this.dbUsername = dbUsername;
        this.dbPassword = dbPassword;
        this.dbPort = dbPort;
        this.oracleSID = oracleSID;
        this.dbUserOnly = false;

    }

    public String getConnectionURL() {
        String conn_url = getJdbcUrl() + dbServer + ":" + dbPort;
        if (dbType.equals("oracle") && !oracle12) return conn_url + ":" + oracleSID;
        else if (dbType.equals("oracle") && oracle12) return conn_url + "/" + oracleSID;
        else if (dbType.equals("mysql")) return conn_url;
        else if (dbType.equals("mssql")) {
            if (isWindowsAuthentication) {
                return conn_url + ";databaseName="+dbName+";integratedSecurity=true";
            } else {
                return conn_url;
            }
        }
        else return null;
    }

    public String getDatabaseDriverClass() {
        if (dbType.equals("mysql")) return "com.mysql.jdbc.Driver";
        else if (dbType.equals("oracle") ) return "oracle.jdbc.driver.OracleDriver";
        else return "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    }

    @Override
    public String toString() {
        return "DatabaseConnectionInfo [databaseName=" + dbName + ", dbServer=" + dbServer + ", dbUsername=" + dbUsername
                + ", dbPassword=" + dbPassword + ", dbType=" + dbType + "]";
    }

    public String getJdbcUrl() {
        if (dbType.equals("mssql")) return "jdbc:sqlserver://";
        else if (dbType.equals("oracle")) return "jdbc:oracle:thin:@";
        else if (dbType.equals("mysql")) return "jdbc:mysql://";
        else return null;
    }

    public String getDbType() {
        return dbType;
    }

    public String getDbUsername() {
        return dbUsername;
    }

    public String getDbPassword() {
        return dbPassword;
    }

    public String getDbServer() {
        return dbServer;
    }

    public String getDbName() {
        return dbName;
    }

    public void setDbName(String dbName) {
        this.dbName = dbName;
    }

    public String getDbPort() {
        return dbPort;
    }

    public String getOracleSID() {
        return oracleSID;
    }

    public void setOracleSID(String oracleSID) {
        this.oracleSID = oracleSID;
    }

    public void setDbUsername(String dbUsername) {
        this.dbUsername = dbUsername;
    }

    public void setDbPassword(String dbPassword) { this.dbPassword = dbPassword; }

    public void setDbUserOnly(boolean dbUserOnly) {
        this.dbUserOnly = dbUserOnly;
    }

    public boolean getDbUserOnly() {
        return dbUserOnly;
    }

    public boolean isOracle12(){
        return oracle12;
    }

    public void setOracle12(boolean oracle12){
        this.oracle12 = oracle12;
    }

    public boolean isWindowsAuthentication() {
        return isWindowsAuthentication;
    }

    public void setWindowsAuthentication(boolean isWindowsAuthentication) {
        this.isWindowsAuthentication = isWindowsAuthentication;
    }
}
