package com.nimsoft.automation.installer;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.nimsoft.automation.database.DBConnection;
import com.nimsoft.automation.database.DBConnectionInfo;
import com.nimsoft.automation.database.DBOperations;
import com.nimsoft.automation.fileshare.CopyBits;
import com.nimsoft.automation.fileshare.Mount;
import com.nimsoft.automation.fileshare.Sftp;
import com.nimsoft.automation.nimbus.DiscoveryAuthentication;
import com.nimsoft.automation.nimbus.DiscoveryAuthentication.Type;
import com.nimsoft.automation.nimbus.NimAddress;
import com.nimsoft.automation.robot.RobotDeploy;
import com.nimsoft.automation.utils.OS;
import com.nimsoft.automation.utils.Utils;
import com.nimsoft.automation.verify.ScanOutput;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.nimbus.NimRequest;
import com.nimsoft.nimbus.NimUserLogin;
import com.nimsoft.nimbus.PDS;

import org.apache.commons.cli.MissingArgumentException;
import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.BasicConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.Inet4Address;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by dustinlish on 1/11/14.
 * Modified by Bruce Hajdu on 12/29/14 - refactoring and code cleanup.
 */
public class Install {
    static Logger logger = LoggerFactory.getLogger(Install.class);

    private static final String FILESHARE = "fileshare.dev.fco";
    private static final String USER = "qateam";
    private static final String PASSWD = "t3sti9";
    private static final String PROPERTIES = "installer.properties";
    private static final int WAIT_TIME = 120000; // time in milliseconds to wait if permission denied encountered

    private NimsoftInstall nimInstall;
    private String installer;
    private String installType;
    private String sid;
    private Map<String, String> opts;
    private boolean isMultiUMP = false;

    public static void main(String[] args) {
        try {
            logger.info("Starting installation...");
            BasicConfigurator.configure();
            InstallOptions install_opts = new InstallOptions(args);
            Map<String, String> optsMap;
            optsMap = install_opts.getOptionsMap();
            Install install = new Install();
            install.launch(optsMap);
            logger.info("Install finished");
            System.exit(0);
        } catch (Exception e) {
            printStackTraceAndExit(e);
        }
    }

    public Install() { }

    public void launch(Map<String, String> optsMap) throws NimException, IOException, SQLException, JSchException, SftpException, InterruptedException {
        this.opts = optsMap;
        installType = opts.get("install").toLowerCase();
        isMultiUMP = (installType.equals("ump") && opts.get("SECONDARY_ROBOTS") != null);
        logger.info(opts.keySet().toString());

        setSID(opts);
        checkInstallType();
        nimInstall.loadProps(opts, opts.get("properties"));

        if(opts.containsKey("drop") && opts.get("drop") != null && opts.get("drop").toLowerCase().equals("only")) {
            try {
                dropDb(nimInstall);
            } catch(Exception e) {
                logger.warn("Could not drop database -- exception was thrown");
                logger.warn(e.getMessage());
            }
        } else {
            logger.info("Running " + opts.get("install") + " installer with the following properties");
            nimInstall.listProps();
            copyBits();
            if(opts.containsKey("drop")) {
                try {
                    dropDb(nimInstall);
                } catch(Exception e) {
                    logger.warn("Could not drop database -- exception was thrown");
                    logger.warn(e.getMessage());
                }
            }
            copyProperties(installType);
            startInstallation();
        }
    }

    private void checkInstallType() {
        if(installType.equals("nms")) nimInstall = new NMS(opts.get("install"), opts.get("ip"), opts.get("db_type"), opts.get("version"));
        else if(installType.equals("ump")) nimInstall = new UMP("UMP", opts.get("ip"));
        else if(installType.equals("robot")) deployRobots(opts);
        else if(installType.equals("hub")) deployHubs(opts, opts.get("HUBVERSION"));
        else logger.error("UR not yet supported");
    }

    private void copyBits() {
        try {
            if (opts.containsKey("local_installer")) {
                checkLocalInstallerExists(opts);
                InstallPaths installPaths = new InstallPaths(opts.get("local_installer"));
                installer = installPaths.getInstallName();
            } else {
                copyInstaller(opts);
            }

            if (opts.containsKey("bitsonly")) {
                logger.info("Bits-only mode detected, exiting installer...");
                System.exit(0);
            }
        } catch (Exception e) {
            printStackTraceAndExit(e);
        }
    }

    private void dropDb(NimsoftInstall install) throws SQLException, InterruptedException {
        DBConnectionInfo dbInfo;
        try {
            dbInfo = new DBConnectionInfo(install.getProp("NIMDBTYPE"), install.getProp("DB_SERVER"), install.getProp("NIMDBNAME"),
                    install.getProp("DB_ADMIN_USER"), install.getProp("DB_ADMIN_PASSWORD"), install.getProp("DB_PORT"));

            if (install.getProp("NIMDBTYPE").equals("oracle")) {
                dbInfo.setOracleSID(install.getProp("ORASID"));
                install.getProp("NIMDBUSER");
                install.getProp("NIMDBPASS");
            }
        } catch(Exception e) {
            dbInfo = new DBConnectionInfo(install.getProp("DB_NORMALIZED_PROVIDER_NAME"), install.getProp("DB_SERVER"),
                    install.getProp("DB_NAME"), install.getProp("DB_ADMIN_USERNAME"), install.getProp("DB_ADMIN_PASSWD"),
                    install.getProp("DB_PORT"));

            if(install.getProp("DB_NORMALIZED_PROVIDER_NAME").equals("oracle")) {
                dbInfo.setOracleSID(install.getProp("DB_SERVICENAME"));
                install.getProp("DB_TABLESPACENAME");
                install.getProp("DB_SYS_PASSWD");
            }
        }

        if (dbInfo.MICROSOFT_SQL.equalsIgnoreCase(dbInfo.getDbType())) {
            if("sqlserver_dbauthmode_windows".equalsIgnoreCase(install.getProp("DB_AUTH_MODE"))) {
                dbInfo.setWindowsAuthentication(true);
            }
        }

        DBConnection dbConn = connectDb(dbInfo);
        try {
            logger.info("Connected to database: " + dbInfo.toString() + " with connection url " + dbConn.getConnectionUrl());
        } catch (IOException e) {
            e.printStackTrace();
        }
        logger.info("Checking if database currently exists...");

        DBOperations operation = new DBOperations();
        if (operation.dbExists(dbConn)) {
            logger.info("Dropping database: " + dbInfo.getDbName());
            if (dbConn.getDbType().toLowerCase().equals("oracle") && dbConn.getDbUserOnly()){
                logger.info("Tablespace doesnt exist but user exists, attempting to close all connections first");
                operation.closeConnections(dbConn, dbInfo.getDbName());
            }
            operation.dropDb(dbConn);
        } else
            logger.info("No database named: " + dbInfo.getDbName() + " found... Skipping drop\n");

        dbConn.disconnect();
    }

    private void startInstallation() {
        try
        {
            ScanOutput scanOutput = new ScanOutput(installType, opts.get("version"));
            boolean install_succeeded = verifyInstall(launchSilentInstall(nimInstall.getPropertiesFile()), nimInstall.getPropertiesFile(), scanOutput);
            
            // Go again if the install is UMP and the wasp probe doesn't respond to a get_info callback.
            if (installType.equals("ump") && !isUMPInstallSuccessful(opts)) {
                logger.warn("UMP Install Failed - Re-trying...");
                install_succeeded = verifyInstall(launchSilentInstall(nimInstall.getPropertiesFile()), nimInstall.getPropertiesFile(), scanOutput);
            }

            if (!install_succeeded) {
                logger.error("FAILED installer, see install log");
                printFailedLogFile(scanOutput);
                System.exit(1);
            }

            if (isMultiUMP) {
                launchMultiUmpInstalls(opts.get("NMSDOMAIN"), opts.get("NMSHUB"), opts.get("NMSROBOT"), opts.get("UMP_ROBOT"),
                        opts.get("SECONDARY_ROBOTS"), opts.get("version"));
            }
        } catch (Exception e) {
            printStackTraceAndExit(e);
        }
    }

    private void setSID(Map<String, String> opts) throws UnknownHostException {
        try {
            if (!installType.equals("nms")) {
                String ip = (opts.get("ip").equals("auto")) ? Inet4Address.getLocalHost().getHostAddress() : opts.get("ip");
                sid = opts.get("NIMBUS_USERNAME") != null && opts.get("NIMBUS_PASSWORD") != null ?
                        new NimUserLogin(opts.get("NIMBUS_USERNAME"), opts.get("NIMBUS_PASSWORD"), ip).loginImpersonate() :
                        new NimUserLogin("administrator", "t3sti9", ip).loginImpersonate();
            }
        } catch(NimException e) {
            printStackTraceAndExit(e);
        }

    }

    private void deployRobots(Map<String, String> opts) {
        logger.info("Checking robot deployment method...");
        try {
            if(opts.get("TARGETS") == null && opts.get("XML") == null) {
                throw new MissingArgumentException("Either targets or path to xml file must be " +
                        "specified for ADE robot deployments");
            }
            if(opts.get("XML") != null) deployRobotsUsingXml();
            if(opts.get("TARGETS") != null) deployRobotsUsingDiscovery();
            System.exit(0);
        } catch(Exception e) {
            printStackTraceAndExit(e);
        }
    }

    private void deployRobotsUsingXml() {
        try {
            logger.info("Deploying robots using provided host-profiles.xml");
            NimAddress primary_hub = new NimAddress(opts.get("NMSDOMAIN"), opts.get("NMSHUB"), opts.get("NMSROBOT"));
            String ade_probe = primary_hub.toString() + "/automated_deployment_engine";
            String file_path = opts.get("XML");
            String file_content = FileUtils.readFileToString(new File(file_path), "UTF-8");

            PDS job_pds = new PDS();
            job_pds.put("file_content", file_content.getBytes("UTF-8"));
            job_pds.put("filename", "host-profiles.xml");

            PDS job = new NimRequest(ade_probe, "submit_job_xml", job_pds).sendImpersonate(sid);
            String job_id = job.getString("JobID");
            logger.info("Job ID: " + job_id);
            String result;
            PDS job_result;

            do {
                job_result = Utils.executeCallback(primary_hub, sid, "automated_deployment_engine", "get_status", job_id);
                result = job_result.getString("JobStatus");
                logger.info("ADE Job status: " + result);
                if(result.equalsIgnoreCase("Failed")) {
                    logger.error("One or more ADE deployments failed, please check the results and try again.");
                    logger.error(job_result.toString());
                }
                Thread.sleep(5000);
            } while(result.equalsIgnoreCase("Running") || result.equalsIgnoreCase("Pending") || result.equalsIgnoreCase("Queued"));
        } catch(Exception e) {
            printStackTraceAndExit(e);
        }
    }

    private void deployRobotsUsingDiscovery() {
        try {
            NimAddress target_hub;
            DiscoveryAuthentication wmi = new DiscoveryAuthentication(Type.wmi, "administrator", "t3sti9");
            DiscoveryAuthentication ssh = new DiscoveryAuthentication(Type.shell, "root", "t3sti9");
            ArrayList<DiscoveryAuthentication> auths = new ArrayList<DiscoveryAuthentication>();
            auths.add(wmi);
            auths.add(ssh);
            String[] targets = opts.get("TARGETS").split(",");
            String db_password = opts.get("DB_ADMIN_PASSWORD") != null ? opts.get("DB_ADMIN_PASSWORD") : "t3sti9";
            NimAddress primary_hub = new NimAddress(opts.get("NMSDOMAIN"), opts.get("NMSHUB"), opts.get("NMSROBOT"));
            if (opts.get("HUBNAME") != null && opts.get("HUBROBOTNAME") != null)
                target_hub = new NimAddress(opts.get("NMSDOMAIN"), opts.get("HUBNAME"), opts.get("HUBROBOTNAME"));
            else
                target_hub = new NimAddress(opts.get("NMSDOMAIN"), opts.get("NMSHUB"), opts.get("NMSROBOT"));

            RobotDeploy.deploy(primary_hub.toString(), target_hub.toString(), targets, auths, db_password, sid);
        } catch(Exception e) {
            printStackTraceAndExit(e);
        }
    }

    private void deployHubs(Map<String, String> opts, String version) {
        String[] targets = opts.get("TARGETS").split(",");
        NimAddress primary_hub = new NimAddress(opts.get("NMSDOMAIN"), opts.get("NMSHUB"), opts.get("NMSROBOT"));
        RobotDeploy.deployHubs(primary_hub ,sid, targets, version);
        System.exit(0);
    }

    private void launchMultiUmpInstalls(String domain, String hub, String nmsrobot, String umprobot, String secondary_robots, String version) throws NimException {
        new MultiUmpInstall(sid, domain, hub, nmsrobot, umprobot, secondary_robots, version).launch();
    }

    //this is for nms and ump only. need more logic in the scanoutput class to handle more logs
    public ArrayList printFailedLogFile(ScanOutput scanOutput) {
        ArrayList<String> ra = new ArrayList<String>();
        String text;
        try {
            BufferedReader in = new BufferedReader(new FileReader(scanOutput.getOutputFile()));
            while (in.ready()) {
                text = in.readLine();
                ra.add(text);
                logger.info(text);
            }
        } catch (Exception e){
            logger.error(e.getMessage(), e);
        }
        return ra;
    }

    private int launchSilentInstall(String properties) throws FileNotFoundException {

        if (!new File(properties).exists())
            throw new FileNotFoundException("Could not find properties file: " + properties);

        // installNMS.exe -f <install.properties> -i silent
        CommandLine cmdLine;
        File exe = new File(installer);
        if (exe.exists() && exe.setExecutable(true)) {
            cmdLine = new CommandLine(exe);
            cmdLine.addArgument("-f");
            cmdLine.addArgument(PROPERTIES);
            cmdLine.addArgument("-i");
            cmdLine.addArgument("silent");
        } else
            throw new FileNotFoundException("ERROR: Could not find'" + installer);

        StringBuilder sb = new StringBuilder("Executing: " + cmdLine.getExecutable());
        for (String arg : cmdLine.getArguments()) {
            sb.append(" ");
            sb.append(arg);
        }
        logger.info(sb.toString());

        DefaultExecutor executor = new DefaultExecutor();
        executor.setExitValue(0);

        int exitValue = -1;
        try {
            exitValue = executor.execute(cmdLine);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }

        return exitValue;
    }

    private boolean isUMPInstallSuccessful(Map<String, String> opts)
    {
        try {
            logger.info("Verifying UMP Install...");
            NimAddress addr = (opts.get("UMP_ROBOT") == null) ?
                    new NimAddress(opts.get("NMSDOMAIN"), opts.get("NMSHUB"), opts.get("NMSROBOT")) :
                    new NimAddress(opts.get("NMSDOMAIN"), opts.get("NMSHUB"), opts.get("UMP_ROBOT"));

            String result = Utils.executeCallback(addr, sid, "wasp", "get_info").toString();
            return result.contains("webapps");
        }
        catch(Exception e) {
            logger.error(e.getMessage(), e);
            return false;
        }
    }

    private void copyProperties(String installType) {
        try {
            String propertyFileName =  (installType.equals("nms")) ? PROPERTIES : "ump." + PROPERTIES;
            propertyFileName = (OS.isWindows()) ? "c:\\tmp\\" + propertyFileName : "/tmp/" + propertyFileName;
            Utils.copyFile(new File(PROPERTIES), new File(propertyFileName));
        } catch(IOException e) {
            logger.error(e.getMessage(), e);
        }
    }

    private void copyInstaller(Map<String, String> optsMap) throws FileNotFoundException, InterruptedException {
        InstallPaths installPaths;
        if (optsMap.containsKey("bnpp")) {
            String build = "";
            if (optsMap.containsKey("build"))
                build = optsMap.get("build");
            installPaths = new InstallPaths(optsMap.get("install"), optsMap.get("version"), build, "bnpp");
        } else if (optsMap.containsKey("build")) {
            installPaths = new InstallPaths(optsMap.get("install"), optsMap.get("version"), optsMap.get("build"));
        } else if (optsMap.containsKey("custom_path")){
            installPaths = new InstallPaths(optsMap.get("install"), optsMap.get("version"), optsMap.get("custom_path"),optsMap);
        }
        else
            installPaths = new InstallPaths(optsMap.get("install"), optsMap.get("version"));

        logger.info("Copying "
                + optsMap.get("install").toUpperCase() + " "
                + optsMap.get("version")
                + " bits from: " + FILESHARE + "...");

        if (OS.isWindows()) {
            Mount mount = new Mount(installPaths.getInstaller());
            mount.mountFileshare();
            CopyBits copyBits = new CopyBits(installPaths);
            copyBits.runCopyCmd();
            mount.unmountFileshare();
        } else {
            // added to address permission denied issue caused by race condition
            // in jenkins kicking off builds and cron setting the correct permissions
            // on the fileshare
            int retries = 2;
            while (retries > 0) {
                try {
                    Sftp sftp = new Sftp(FILESHARE, USER, PASSWD);
                    sftp.connect();
                    sftp.sftpCmd(installPaths.getInstaller(), "./" + installPaths.getInstallName());
                    //If the packeges zip exists, copy that over too.
                    if(installPaths.packagesExist()){
                        logger.info("Archive packages exists, copying packages.zip as well. ");
                        logger.info("Copying " + installPaths.packagesPath() + " to ./" + installPaths.getPackageZip());
                        sftp.sftpCmd(installPaths.packagesPath(), "./" + installPaths.getPackageZip());
                    }
                    sftp.disconnect();
                    logger.info("Copy complete");
                    break;
                } catch (SftpException e) {
                    logger.info("Caught permission denied... retries left:  " + retries);
                    e.printStackTrace();
                } catch (JSchException e) {
                    e.printStackTrace();
                }

                retries--;
                Thread.sleep(WAIT_TIME);
            }
        }
        logger.info("DONE");

        installer = installPaths.getInstallName();
    }

    private boolean verifyInstall(int exitCode, String properties, ScanOutput scanOutput) throws IOException {

        if (exitCode != 0)
            return false;

        boolean is_v2_installer = nimInstall.getProp().isV2Installer();
        List<String> rc = new ArrayList<String>();
        if (installType.equals("nms")) {
            String[] listSearchStrings = {"failed", "error"};
            try {
                rc = scanOutput.scanForText(listSearchStrings);
            } catch (FileNotFoundException r) {
                logger.warn("Did not find the iaoutput.txt file" + r);
            }
        } else if (installType.equals("ump")) {
            String[] listSearchStrings = {"failed", "error", "exception" };
            try {
                scanOutput.scanForText(listSearchStrings);
            } catch (FileNotFoundException r) {
                logger.warn("Did not find the iaoutput.txt file" + r);
            }
        }

        String summaryFile;
        if(!is_v2_installer) {
            summaryFile = scanOutput.summaryInstall(properties, rc, is_v2_installer);
            logger.info("You can find the summary of the install at " + summaryFile);
        }

        //this is hardcoded return true. Meaning no matter what the scanner finds for ump or nms logs
        // it will only print the errors in the logs and not fail this java installer
        return true;
    }

    private DBConnection connectDb(DBConnectionInfo dbInfo) {
        DBConnection dbConn = new DBConnection(dbInfo);
        try {
            dbConn.connect();
        } catch (Exception e) {
            logger.info("\nCould not connect to database, connection string used: " +dbConn.getDbInfo().toString()+
                    "\nPlease check is database is up and accepting connections\n");
            printStackTraceAndExit(e);
        }
        return dbConn;
    }

    public boolean checkLocalInstallerExists(Map <String, String> opts) throws FileNotFoundException {
        File bd = new File(opts.get("local_installer"));

        if(bd.exists()) {
            logger.info("Installer already exists, will use for installation purposes");
            return true;
        } else {
            throw new FileNotFoundException("Couldnt find the intaller you specificed at " + opts.get("local_installer"));
        }
    }


    public String getInstaller() {
        return installer;
    }

    public void setInstaller(String installer) {
        this.installer = installer;
    }

    public static String getFileshare() { return FILESHARE; }

    public static String getUser() { return USER; }

    public static String getPassword() { return PASSWD; }

    public static void printStackTraceAndExit(Exception e) {
        logger.error(e.getMessage(), e);
        System.exit(1);
    }
}