package com.nimsoft.automation.fileshare;

import com.nimsoft.automation.installer.InstallPaths;
import com.nimsoft.automation.utils.OS;
import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteException;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.File;

/**
 * Created by dustinlish on 1/11/14.
 */
public class CopyBits {
    static Logger logger = LoggerFactory.getLogger(CopyBits.class);

    public final String WINCOPYDIR = ".\\";

    private String installer;
    private String installFullPath;
    private String fullDir;
    private InstallPaths installPaths;

    public CopyBits(InstallPaths installPaths) {
        this.installPaths = installPaths;
        this.fullDir = installPaths.getFullDir();
    }

    public int runCopyCmd() {
        //NOW RUN THE COMMAND
        int rc = -1;
        setInstaller();
        File FullPath = new File(WINCOPYDIR + "\\" + installer).getAbsoluteFile();
        installFullPath =FullPath.toString();
        logger.info("installfullpath: " + installFullPath);
        checkBaseDir();
        checkAlreadyExists();
        File fileFullDir = new File(fullDir);
        File fileCopyDir = new File(installFullPath);
        logger.info("FullDir = " + fullDir + " will be copied to InstallFullDir  " + installFullPath);
        try {
            FileUtils.copyFile(fileFullDir, fileCopyDir);
            if(installPaths.packagesExist()){
                logger.info("Archive packages found in in folder, copying packges as well.");
                File packagesDir = new File(installPaths.packagesPath());
                File localPackagesPath = new File(WINCOPYDIR + "\\" +installPaths.getPackageZip());
                logger.info("Copying " + packagesDir.toString() + " to " + localPackagesPath.toString());
                FileUtils.copyFile(packagesDir, localPackagesPath);
            }
            rc = 0;
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
        return rc;
    }

    public String setInstaller() {
        if (OS.isWindows()) {
            if (!installPaths.isPre80Version() && installPaths.getInstallType().toLowerCase().equals("nms"))
                installer = fullDir.substring(fullDir.indexOf("\\setupCA")).replace("\\", "");
            else
                installer = fullDir.substring(fullDir.indexOf("\\install")).replace("\\", "");
        }
        else
            if (!installPaths.isPre80Version() && installPaths.getInstallType().toLowerCase().equals("nms")) {
                installer = fullDir.substring(fullDir.indexOf("/setupCA")).replace("/", "");
            }
            else
               installer = fullDir.substring(fullDir.indexOf("/install")).replace("/", "");

        logger.info("Installer = " + installer);
        return installer;
    }

    public String checkBaseDir() {
        File bd;
        bd = new File(WINCOPYDIR);
        String rc;
        if(bd.exists()) {
            rc = "BaseDir already Exists";
        } else {
            bd.mkdir();
            rc = "Made a new BaseDir";
        }
        logger.info(rc);
        return rc;
    }

    public String checkAlreadyExists() {
        String rc = "";
        File bd;
        logger.info("AT" + installFullPath);
        bd = new File(installFullPath);

        if(bd.exists()) {
            logger.info("Installer already exists, will now remove it");
            bd.delete();
        } else {
            logger.info("Installer does not currently exist");
        }
        return rc;
    }

    public CommandLine buildCommandLine(String[] cmdArray) {
        CommandLine cmdLine;
        cmdLine = new CommandLine(cmdArray[0]);
        int maxLength = cmdArray.length;
        int count = 1;
        while (count != maxLength) {
            cmdLine.addArgument(cmdArray[count]);
            count++;
        }

        return cmdLine;
    }

    public int executeCmd(CommandLine cmdLine) {
        int exitValue = -1;
        DefaultExecutor executor = new DefaultExecutor();
        executor.setExitValue(0);
        logger.info("Attempting to run command [" + cmdLine.toString() + "]");
        try {
            exitValue = executor.execute(cmdLine);
            return exitValue;
        } catch (ExecuteException e) {
            logger.error(e.getMessage(), e);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
        return exitValue;
    }



}
