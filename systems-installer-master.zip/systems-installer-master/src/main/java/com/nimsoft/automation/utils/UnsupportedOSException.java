package com.nimsoft.automation.utils;

/**
 * Created by dustinlish on 1/20/14.
 *
 */
public class UnsupportedOSException extends RuntimeException {

    public UnsupportedOSException(String s) {
        super(s);
    }

}
