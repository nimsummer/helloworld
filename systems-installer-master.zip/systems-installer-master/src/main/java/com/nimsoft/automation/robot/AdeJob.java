package com.nimsoft.automation.robot;

import com.nimsoft.automation.nimbus.NimAddress;
import com.nimsoft.automation.utils.Utils;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.nimbus.NimRequest;
import com.nimsoft.nimbus.PDS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Enumeration;
import java.util.LinkedList;

/**
 * Created by cullen on 4/18/14.
 *
 */
public class AdeJob {
    static Logger logger = LoggerFactory.getLogger(AdeJob.class);

    private LinkedList<PDS> hosts = new LinkedList<PDS>();
    private PDS authentication = new PDS();
    private PDS robotInfo = new PDS();
    private String jobId = null;
    private Status status;
    private NimAddress adeAddress;
    private String sid;

    private enum Status {
        define,
        deploy,
        deployed
    }

    public AdeJob(NimAddress adeAddress, String sid) {
        this.sid = sid;
        this.adeAddress = adeAddress;
        status = Status.define;
    }

    public void addHostProfile(String profile, String architecture, String hostname, String ipAddress, String authId, String robInfoId) {
        if (status != Status.define)
            throw new RuntimeException("Cannot add host profile after job submitted");

        PDS host = new PDS();
        try {
            host.put("profile", profile);
            host.put("arch", architecture);
            host.put("hostname", ipAddress);
            host.put("hostip", ipAddress);
            host.put("auth_id", authId);
            host.put("robot_id", robInfoId);
        } catch (NimException e) {
            logger.error(e.getMessage(), e);
            System.exit(1);
        }
        hosts.add(host);
    }

    public void addAuthentication(String username, String password, String id, boolean encrypted) {
        if (status != Status.define)
            throw new RuntimeException("Cannot add authentication after job submitted");

        PDS auth = new PDS();
        try {
            auth.put("username", username);
            auth.put("password", password);
            auth.put("nimcrypt", String.valueOf(encrypted));
            authentication.put(id, auth);
        } catch (NimException e) {
            logger.error(e.getMessage(), e);
            System.exit(1);
        }
    }

    public void addRobotInfo(String id, String hubIp, NimAddress hubAddress) {
        addRobotInfo(id, hubIp, hubAddress, "48002");
    }

    public void addRobotInfo(String id, String hubIp, NimAddress hubAddress, String hubPort) {
        if (status != Status.define)
            throw new RuntimeException("Cannot add robot info after job submitted");

        PDS info = new PDS();
        try {
            info.put("hubip", hubIp);
            info.put("domain", hubAddress.domain);
            info.put("hub", hubAddress.hub);
            info.put("hubrobotname", hubAddress.robot);
            info.put("hubport", hubPort);
            robotInfo.put(id, info);
        } catch (NimException e) {
            logger.error(e.getMessage(), e);
            System.exit(1);
        }
    }

    public void submit() throws NimException {
        if (status != Status.define)
            throw new RuntimeException("Cannot submit job after it was already submitted");
        if (hosts.size() < 1)
            throw new RuntimeException("Cannot submit job with no hosts added");

        PDS job = new PDS();
        PDS hostsTable = new PDS();
        PDS[] hostsArray = new PDS[hosts.size()];
        int i=0;
        for(PDS p: hosts) {
            hostsArray[i] = p;
            ++i;
        }
        hostsTable.putTablePDSs("hosts", hostsArray);
        job.put("hosts", hostsTable);
        job.put("authentication", authentication);
        job.put("robot_info", robotInfo);
        job.put("jobname", "Automated ADE");
        NimRequest request = new NimRequest(adeAddress.toString() + "/automated_deployment_engine", "submit_job", job);
        PDS result = request.sendImpersonate(sid);
        jobId = result.getString("JobID");
        status = Status.deploy;
    }

    /**
     *
     * @return true if job succeeded.  false otherwise
     * @throws NimException
     */
    public boolean waitForFinish() throws NimException, InterruptedException {
        if (status != Status.deploy && status != Status.deployed)
            throw new RuntimeException("Cannot wait for job completion before submitting job");

        while(true) {
            PDS result = Utils.executeCallback(adeAddress, sid, "automated_deployment_engine", "get_status", jobId);
            if (!result.getString("JobStatus").equalsIgnoreCase("Running") &&
                    !result.getString("JobStatus").equalsIgnoreCase("Pending") &&
                    !result.getString("JobStatus").equalsIgnoreCase("Queued")) {
                status = Status.deployed;
                return result.getString("JobStatus").equalsIgnoreCase("Success");
            }
            Thread.sleep(1000);
        }
    }

    public boolean reportResults() throws NimException {
        if (status != Status.deployed)
            throw new RuntimeException("Cannot report job results until confirmed finished");

        PDS result = Utils.executeCallback(adeAddress, sid, "automated_deployment_engine", "get_status", jobId);
        Enumeration<String> keys = result.getPDS("StatusTable").keys();
        boolean succeeded = result.getString("JobStatus").equalsIgnoreCase("Success");
        while(keys.hasMoreElements()) {
            PDS host = result.getPDS("StatusTable").getPDS(keys.nextElement());
            String status = host.getString("Status");
            String desc = host.getString("Description");
            if (status.equalsIgnoreCase("Success")) {
                if (desc.length() > 0) {
                    logger.warn("    Warning on " +host.getString("Host") +": " +desc);
                    succeeded = false;
                }
            } else {
                succeeded = false;
                if (desc.length() > 0)
                    logger.warn("    " +status +" on " +host.getString("Host") +": " +desc);
                else
                    logger.warn("    Unknown " +status +" on " +host.getString("Host"));
            }
        }
        return succeeded;
    }

    public String getId() {
        if (status != Status.deployed && status != Status.deploy)
            throw new RuntimeException("Cannot get job status before submitting");

        return jobId;
    }
}
