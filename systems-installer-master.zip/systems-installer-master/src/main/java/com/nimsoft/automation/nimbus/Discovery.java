package com.nimsoft.automation.nimbus;

import com.nimsoft.automation.database.DBConnection;
import com.nimsoft.automation.database.DBConnectionInfo;
import com.nimsoft.automation.database.DBOperations;
import com.nimsoft.automation.utils.Utils;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.nimbus.PDS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.sql.*;
import java.util.*;

/**
 * Created by cullen on 4/23/14.
 *
 */
public class Discovery {

    static Logger logger = LoggerFactory.getLogger(Discovery.class);

    private NimAddress disServerAddress;
    private NimAddress disAgentAddress;
    private DBConnectionInfo connectionInfo;
    private DBOperations dbOperator;
    private int disAgentId;
    private Status status;
    private LinkedList<DiscoveryAuthentication> credentialsList = new LinkedList<DiscoveryAuthentication>();
    private LinkedList<Integer> ranges = new LinkedList<Integer>();
    private String sid;

    private enum Status {
        configure,
        discovering,
        inquire
    }

    public Discovery(NimAddress discoveryServerAddress, NimAddress discoveryAgentAddress, NimAddress dataEngineAddress, String dbPassword, String sid) throws NimException, ClassNotFoundException, SQLException,IOException {
        this.sid = sid;
        disServerAddress = discoveryServerAddress;
        disAgentAddress = discoveryAgentAddress;
        dbOperator = new DBOperations();
        status = Status.configure;
        setup(dataEngineAddress, dbPassword);
    }

    private void setup(NimAddress dataEngineAddress, String dbPassword) throws NimException, ClassNotFoundException, SQLException, IOException {
        String dbHost = getControllerDbInfo(dataEngineAddress, "setup/server");
        String port = getControllerDbInfo(dataEngineAddress, "setup/port");
        String dbType = getControllerDbInfo(dataEngineAddress, "setup/db_plugin").toLowerCase();
        String parameters = getControllerDbInfo(dataEngineAddress, "setup/parameters");
        String schema = dbType.equalsIgnoreCase("oracle") ? getControllerDbInfo(dataEngineAddress, "setup/user") : getControllerDbInfo(dataEngineAddress, "setup/database");
        String orasid = dbType.equalsIgnoreCase("oracle") ? getControllerDbInfo(dataEngineAddress, "setup/servicename") : null;
        String user = getControllerDbInfo(dataEngineAddress, "setup/user");

        if(dbHost.contains(",")) dbHost = dbHost.substring(0, dbHost.indexOf(','));
        if (dbType.equalsIgnoreCase("microsoft")) dbType = "mssql";

        connectionInfo = dbType.equalsIgnoreCase("oracle") ?
                new DBConnectionInfo(dbType, dbHost, schema, user, dbPassword, orasid, port) :
                new DBConnectionInfo(dbType, dbHost, schema, user, dbPassword, port);
        if(parameters != null) {
            connectionInfo.setWindowsAuthentication(parameters.contains("Integrated Security"));
        }

        DBConnection con = new DBConnection(connectionInfo);
        con.connect();

        ArrayList<String> columns = new ArrayList<String>();
        columns.add("da_id");
        columns.add("address");
        //ResultSet result = c.prepareStatement("SELECT da_id, address FROM cm_discovery_agent").executeQuery();
        ResultSet result = dbOperator.selectStatement(con, columns, "cm_discovery_agent");

        while(result.next()) {
            if (result.getString("address").equalsIgnoreCase(disAgentAddress.toString() + "/discovery_agent")) {
                disAgentId = result.getInt("da_id");
                break;
            }
        }
        if (result.isAfterLast())
            throw new RuntimeException("Could not find discovery agent " + disAgentAddress.toString() + " in database");

        con.disconnect();
    }

    public void addCredentials(DiscoveryAuthentication auth) throws IOException, SQLException, ClassNotFoundException {
        if (status != Status.configure)
            throw new RuntimeException("Cannot configure discovery after already discovering");

        DBConnection con = new DBConnection(connectionInfo);
        con.connect();
        HashMap<String, String> values = new HashMap<String, String>();
        values.put("description", "Automated Discovery");
        values.put("user_name", auth.user);
        String encryptedPassword = Utils.encryptDiscoveryPassword(auth.password);
        values.put("password", encryptedPassword);
        if (auth.type == DiscoveryAuthentication.Type.shell) {
            values.put("protocol", "SSH");
        } else if (auth.type == DiscoveryAuthentication.Type.snmp) {
            values.put("version", "2");
            values.put("method", "MD5");
        }
        ResultSet set = dbOperator.insert(con, "cm_" + auth.type + "_authentication", values, new String[]{auth.type + "_id"});
        if (!set.next())
            throw new RuntimeException("Insertion of " + auth.type + " credentials did not successfully return primary key; user_name: " +auth.user +", password: " + Utils.encryptDiscoveryPassword(auth.password));
        auth.id = set.getInt(1);
        credentialsList.add(auth);
        con.disconnect();
    }

    public void addRange(String range) throws SQLException, ClassNotFoundException, IOException {
        if (status != Status.configure)
            throw new RuntimeException("Cannot configure discovery after already discovering");

        DBConnection con = new DBConnection(connectionInfo);
        con.connect();
        HashMap<String, String> values = new HashMap<String, String>();
        values.put("description", "Automated Discovery");
        values.put("network", range);
        values.put("da_id", String.valueOf(disAgentId));
        ResultSet set = dbOperator.insert(con, "cm_discovery_network", values, new String[] {"network_id"});
        if (!set.next())
            throw new RuntimeException("Insertion of network range did not successfully return primary key; da_id: " +disAgentId +", network: " +range);
        ranges.add(set.getInt(1));
        con.disconnect();
    }

    public void beginDiscovery() throws ClassNotFoundException, SQLException, NimException, IOException {
        if (status != Status.configure)
            throw new RuntimeException("Cannot begin discovery after already discovering");

        // first we need to link the ranges to the credentials
        DBConnection con = new DBConnection(connectionInfo);
        con.connect();
        for(int range: ranges) {
            for(DiscoveryAuthentication creds: credentialsList) {
                String table = "cm_network_" +creds.type.name;
                String field = creds.type.name +"_id";
                HashMap<String, String> values = new HashMap<String, String>();
                values.put("network_id", String.valueOf(range));
                values.put(field, String.valueOf(creds.id));
                dbOperator.insert(con, table, values);
            }
        }
        con.disconnect();

        // now we can make the callback to discover now
        String dis_agent_addr = disAgentAddress.toString() + "/discovery_agent";
        Utils.executeCallback(disServerAddress, sid, "discovery_server", "discover_now", dis_agent_addr);
        status = Status.discovering;
    }

    public void waitForFinish() throws NimException {
        if (status == Status.inquire)
            return;
        if (status != Status.discovering)
            throw new RuntimeException("Cannot wait for job completion before starting discovery");

        while(true) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                logger.error(e.getMessage(), e);
                return;
            }
            PDS result = Utils.executeCallback(disAgentAddress, sid, "discovery_agent", "get_discovery_run_status");
            if (!result.getString("state").equalsIgnoreCase("RUNNING")) {
                status = Status.inquire;
                return;
            }
        }
    }

    /**
     * Gets some specific information about discovered devices with a specific set of ip addresses from the database.
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    public HashMap<Integer, HashMap<String, String>> getDeviceInfo(String[] deviceIps, long minChangeTime) throws SQLException, ClassNotFoundException, IOException {

        DBConnection con = new DBConnection(connectionInfo);
        con.connect();
        ArrayList<String> columns = new ArrayList<String>();
        columns.add("ip");
        columns.add("dns_name");
        columns.add("os_type");
        columns.add("os_name");
        columns.add("linux_dist_name");
        columns.add("processor_type");
        columns.add("shell_profile");
        columns.add("wmi_profile");
        columns.add("snmp_profile");
        columns.add("alive_time");
        ResultSet set = dbOperator.selectStatement(con, columns, "cm_computer_system");

        // parse data from ResultSet
        Arrays.sort(deviceIps);
        HashMap<Integer, HashMap<String, String>> devices = new HashMap<Integer, HashMap<String, String>>();
        ResultSetMetaData metaData = set.getMetaData();
        int ipColumn = set.findColumn("ip");

        while(set.next()) {
            String ip = set.getString(ipColumn);
            int index = Arrays.binarySearch(deviceIps, ip);
            if (index < 0 || set.getTimestamp("alive_time").getTime() < minChangeTime) continue;
            HashMap<String, String> device;
            if (devices.get(index) == null)
                device = new HashMap<String, String>();
            else
                device = devices.get(index);
            for(int i=1; i<=metaData.getColumnCount(); ++i) {
                if (set.getString(i) != null)
                    device.put(metaData.getColumnName(i), set.getString(i));
            }
            devices.put(index, device);
        }

        con.disconnect();

        return devices;
    }

    public HashMap<String, String> getCredentials(DiscoveryAuthentication.Type type, int credentialId) throws SQLException, ClassNotFoundException, IOException {
        DBConnection con = new DBConnection(connectionInfo);
        con.connect();
        ArrayList<String> columns = new ArrayList<String>();
        columns.add(type.name +"_id");
        columns.add("description");
        columns.add("user_name");
        columns.add("password");
        ResultSet set = dbOperator.selectStatement(con, columns, "cm_" +type.name +"_authentication");

        // parse data from ResultSet
        HashMap<String, String> creds = new HashMap<String, String>();
        ResultSetMetaData metaData = set.getMetaData();
        int idColumn = set.findColumn(type.name +"_id");

        while(set.next()) {
            int id = set.getInt(idColumn);
            if (id != credentialId) continue;

            for(int i=1; i<=metaData.getColumnCount(); ++i) {
                creds.put(metaData.getColumnName(i), set.getString(i));
            }
            con.disconnect();
            return creds;
        }

        // failed to find credentials
        con.disconnect();
        return null;
    }

    /**
     * Gets information from data_engine's configuration file via controller callbacks.
     * @param dataEngineAddress The address of the data_engine probe.
     * @param key The full key to get the value of.  e.g. setup/db_plugin.
     * @return The value of the specified key.
     * @throws NimException
     */
    private String getControllerDbInfo(NimAddress dataEngineAddress, String key) throws NimException {
        PDS result = Utils.executeCallback(dataEngineAddress, sid, "controller", "probe_config_get", "data_engine", null, key);
        return result.getString("value");
    }

    private String getDataEngineDbInfo(NimAddress dataEngineAddress, String key) throws NimException {
        PDS result = Utils.executeCallback(dataEngineAddress, sid, "data_engine", "get_info");
        return result.getString(key);
    }

    public void cleanupScopesAndCreds() throws SQLException, ClassNotFoundException,IOException {
        final String[] tables = {"CM_DISCOVERY_NETWORK", "CM_WMI_AUTHENTICATION", "CM_SHELL_AUTHENTICATION", "CM_SNMP_AUTHENTICATION"};
        DBConnection connection = new DBConnection(connectionInfo);
        connection.connect();
        String db_type = connection.getDbInfo().getDbType().toLowerCase();
        StringBuilder sql_statement_begin = new StringBuilder("DELETE FROM ");
        PreparedStatement p;

        if (connection.getConnection() == null)
            throw new IllegalArgumentException("connection cannot be null!");

        //building a string array that is dynamic based on the values array passed in for the use in the prepare statement
        if (db_type.equals("oracle") || db_type.equals("mysql"))
            sql_statement_begin.append(connection.getDbName()).append(".");

        for(String table : tables) {
            String delete_query = sql_statement_begin + table + " WHERE DESCRIPTION = 'Automated Discovery'";
            p = connection.getConnection().prepareStatement(delete_query);
            executeOnDB(p, connection);
        }

        connection.disconnect();
    }
    
    private void executeOnDB(PreparedStatement p, DBConnection c) throws SQLException {
        Statement s = c.getConnection().createStatement();
        if (c.getDbInfo().getDbType().toLowerCase().equals("mssql"))
            s.executeUpdate("USE " + c.getDbName());

        p.executeUpdate();
    }
}
