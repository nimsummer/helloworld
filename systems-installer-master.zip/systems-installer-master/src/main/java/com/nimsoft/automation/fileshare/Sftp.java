package com.nimsoft.automation.fileshare;

import com.jcraft.jsch.*;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

/**
 * Created by lisdu02 on 1/22/14.
 *
 */
public class Sftp {

    static Logger logger = LoggerFactory.getLogger(Sftp.class);

    private String ip;
    private String username;
    private String password;
    private int timeout = 300000;

    private Session session = null;

    public Sftp(String ip, String username, String password) {
        this.ip = ip;
        this.username = username;
        this.password = password;
    }

    public boolean connect() throws JSchException {
        JSch jsch = new JSch();
        session = jsch.getSession(username, ip, 22);

        session.setConfig("StrictHostKeyChecking", "no");
        session.setPassword(password);
        session.setHost(ip);
        session.setTimeout(timeout);
        session.connect();

        return true;
    }

    public void disconnect() {
        this.session.disconnect();
    }

    public boolean sftpCmd(String remoteFile, String localFile) throws JSchException, SftpException {
        if (remoteFile == null || localFile == null)
            throw new IllegalArgumentException("Cannot pass null parameter");

        Channel channel = this.session.openChannel("sftp");
        channel.connect();

        ChannelSftp sftpChannel = (ChannelSftp) channel;

        sftpChannel.get(remoteFile, localFile);
        sftpChannel.exit();

        return true;
    }

    public String getIp() {
        return ip;
    }

    public String getPassword() {
        return password;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }
}
