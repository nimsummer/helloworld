package com.nimsoft.automation.installer;

import com.jcraft.jsch.JSchException;
import com.nimsoft.automation.nimbus.NimAddress;
import com.nimsoft.automation.utils.Utils;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.nimbus.PDS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.*;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;

/**
 * Created by hajbr03 on 10/15/2014.
 *
 */
public class MultiUmpInstall {
    static Logger logger = LoggerFactory.getLogger(MultiUmpInstall.class);

    private List<String> ump_pkg_list;
    private NimAddress primary_hub_robot;
    private NimAddress primary_ump_robot_address;
    private String[] secondary_robots;
    private String version, sid;
    private Map<String, String> secondary_portal_ext_properties_files;

    public MultiUmpInstall(String sid, String domain, String hub, String nmsrobot, String umprobot, String secondary_robots, String version) throws NimException {
        this.sid = sid;
        this.primary_hub_robot = new NimAddress(domain, hub, nmsrobot);
        this.primary_ump_robot_address = new NimAddress(domain, hub, umprobot);
        this.version = version;
        this.secondary_robots = secondary_robots.split(",");
        secondary_portal_ext_properties_files = new HashMap<String, String>();

        this.ump_pkg_list = getUmpPackages();
        extractPsExec();
    }

    private List<String> getUmpPackages() throws NimException {
        List<String> pkgs = new ArrayList<String>();
        PDS result = Utils.executeCallback(primary_ump_robot_address, sid, "controller", "inst_list_summary");
        PDS[] p = result.getTablePDSsIfPresent("pkg");

        for(PDS pkg : p) {
            if(isUMPPackage(pkg.getString("name"))) pkgs.add(pkg.getString("name"));
        }

        return pkgs;
    }

    private boolean isUMPPackage(String name) {
        return name.contains("wasp") || name.contains("ump") || name.equals("dap") || name.equals("dashboard_engine") || name.equals("java_jre");
    }

    public boolean launch() {
        try {
            logger.info("\n**************************************\n* MULTIPLE UMP INSTALLATION DETECTED *\n" +
                    "**************************************");

            String primary_portal_ext_properties = getPortalExtProperties(primary_ump_robot_address);
            configurePrimaryUMP();
            setIPv4Stack(primary_ump_robot_address.robot);
            enablePortalClustering(primary_portal_ext_properties, primary_ump_robot_address);

            for (String robot : secondary_robots) {
                deployAndConfigureSecondary(robot);
                postSetupSecondary(robot);
                setIPv4Stack(robot);
            }

            startUMP(primary_ump_robot_address.robot);
            for(String robot : secondary_robots)  startUMP(robot);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return false;
        }

        return true;
    }

    private void configurePrimaryUMP() throws NimException, InterruptedException, IOException, JSchException {
        logger.info("Configuring Primary UMP Server for multi-instance...");

        Utils.executeCallback(primary_ump_robot_address, sid, "controller", "probe_config_set", "dashboard_engine", "data", "enable_multi_instance", "1");
        Utils.executeCallback(primary_ump_robot_address, sid, "controller", "probe_config_set", "dashboard_engine", "updateintervals", "multi_instance_check", "30");
        Utils.executeCallback(primary_ump_robot_address, sid, "controller", "probe_config_set", "wasp", "webapps/umpmedia", "enable_multi_instance", "1");
        Utils.executeCallback(primary_ump_robot_address, sid, "controller", "probe_config_set", "wasp", "webapps/umpmedia", "media_update_interval", "30");

        logger.info("Deactivating primary wasp, waiting 10 seconds for it to go down...");
        Utils.deactivateProbes(primary_ump_robot_address, sid, "wasp");
        Thread.sleep(10000);
        createSharedDir(primary_ump_robot_address);
    }

    private void deployAndConfigureSecondary(String robot) throws NimException, IOException, JSchException, InterruptedException {
        NimAddress robot_addr = new NimAddress(primary_hub_robot.domain, primary_hub_robot.hub, robot);
        logger.info("Deploying UMP to " + robot_addr.toString());
        logger.info("Backing up portal-ext.properties if it exists");
        secondary_portal_ext_properties_files.put(robot, getPortalExtProperties(robot_addr));
        logger.info("Package Deployment Starting");
        pushPackages(robot_addr);
        configureSecondaryUMP(robot_addr);
        logger.info("Activating wasp on " + robot_addr.toString());
        Utils.activateProbes(robot_addr, sid, "wasp");
        Utils.waitForProbeStart(robot_addr, sid, "wasp", 600);
        logger.info("Deactivating wasp on " + robot_addr.toString());
        Utils.deactivateProbes(robot_addr, sid, "wasp");
    }

    private void postSetupSecondary(String robot) throws NimException, IOException, JSchException {
        NimAddress robot_addr = new NimAddress(primary_hub_robot.domain, primary_hub_robot.hub, robot);
        linkToSharedDir(primary_ump_robot_address, robot_addr);
        String portal_ext_properties = secondary_portal_ext_properties_files.get(robot);
        enablePortalClustering(portal_ext_properties, robot_addr);
    }

    private void startUMP(String robot) throws NimException {
        NimAddress robot_addr = new NimAddress(primary_hub_robot.domain, primary_hub_robot.hub, robot);
        Utils.activateProbes(robot_addr, sid, "dap", "dashboard_engine", "wasp");
        Utils.waitForProbeStart(robot_addr, sid, "dap", 60);
        Utils.waitForProbeStart(robot_addr, sid, "dashboard_engine", 60);
        Utils.waitForProbeStart(robot_addr, sid, "wasp", 600);
    }

    private void enablePortalClustering(String portal_ext_properties, NimAddress robot_addr) throws NimException {
        if(portal_ext_properties == null) portal_ext_properties = getPortalExtProperties(robot_addr);

        portal_ext_properties = portal_ext_properties.replace("# cluster.link.enabled=true","cluster.link.enabled=true");
        portal_ext_properties = portal_ext_properties.replace("# lucene.replicate.write=true","lucene.replicate.write=true");

        Utils.executeCallback(robot_addr, sid, "controller", "text_file_put",
                "probes/service/wasp/webapps/ROOT/WEB-INF/classes",
                "portal-ext.properties",
                null,
                portal_ext_properties);
    }

    private void setIPv4Stack(String robot) throws NimException {
        NimAddress robot_addr = new NimAddress(primary_hub_robot.domain, primary_hub_robot.hub, robot);
        PDS result = Utils.executeCallback(robot_addr, sid, "controller", "probe_config_get", "wasp", null, "startup/options");

        String opts = result.getString("value");
        if(!opts.contains("-Djava.net.preferIPv4Stack=true")) opts = opts.concat(" -Djava.net.preferIPv4Stack=true");

        Utils.executeCallback(robot_addr, sid, "controller", "probe_config_set", "wasp", "startup", "options", opts);
    }

    private String getPortalExtProperties(NimAddress robot_addr) {
        try
        {
            PDS result = Utils.executeCallback(robot_addr, sid, "controller", "text_file_get",
                    "probes/service/wasp/webapps/ROOT/WEB-INF/classes",
                    "portal-ext.properties",
                    "10000000");

            return result.getString("file_content");
        } catch(Exception e) {
            return null;
        }
    }

    private void configureSecondaryUMP(NimAddress robot_address) throws NimException {
        logger.info("Configuring UMP probes for " + robot_address + "... ");
        String primary_hub = primary_hub_robot.toString();

        // Setting probe locations
        Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "dap", "setup", "data_engine", primary_hub + "/data_engine");
        Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "dashboard_engine", "nimbus", "data_engine_address", primary_hub + "/data_engine");
        Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "dashboard_engine", "nimbus", "nas_address", primary_hub + "/nas");

        // Enabling multi-instance for the secondary UMP probes
        Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "dashboard_engine", "data", "enable_multi_instance", "1");
        Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "dashboard_engine", "updateintervals", "multi_instance_check_interval", "1");
        Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "wasp", "setup", "data_engine", primary_hub + "/data_engine");
        Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "wasp", "webapps/umpmedia", "enable_multi_instance", "1");
        Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "wasp", "webapps/umpmedia", "media_update_interval", "30");

        // Setting probe locations back to the primary hub
        Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "wasp", "ump_common", "ace", primary_hub + "/ace");
        Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "wasp", "ump_common", "automated_deployment_engine", primary_hub + "/automated_deployment_engine");
        Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "wasp", "ump_common", "discovery_server", primary_hub + "/discovery_server");
        Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "wasp", "ump_common", "maintenance_mode", primary_hub + "/maintenance_mode");
        Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "wasp", "ump_common", "nas", primary_hub + "/nas");
        Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "wasp", "ump_common", "service_host", primary_hub + "/service_host");
        Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "wasp", "ump_common", "sla_engine", primary_hub + "/sla_engine");
        Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "wasp", "ump_common", "nis_server", primary_hub + "/nis_server");

        if(version.contains("8."))
            Utils.executeCallback(robot_address, sid, "controller", "probe_config_set", "wasp", "ump_common", "ugs", primary_hub + "/ugs");

        logger.info("done!");
    }

    private boolean createSharedDir(NimAddress primary_ump_addr) throws NimException, IOException, JSchException {
        PDS result = Utils.executeCallback(primary_ump_addr, sid, "controller", "get_info");

        String os = result.getString("os_major");
        String os_minor = result.getString("os_minor");
        String home_dir = result.getString("workdir").replace("\\", "\\\\");
        String ip = result.getString("robotip");

        if (os.equals("Windows")) {
            Utils.executeProcess("psexec", "\\\\" + ip, "-u", "Administrator", "-p", "t3sti9", "C:\\windows\\system32\\cmd.exe",
                    "/c", "mkdir", home_dir + "\\probes\\service\\data\\document_library\"");

            Utils.executeProcess("psexec", "\\\\" + ip, "-u", "Administrator", "-p", "t3sti9", "C:\\windows\\system32\\cmd.exe",
                    "/c", "net share", "document_library=\"" + home_dir + "\\probes\\service\\data\\document_library\"",
                    "/unlimited", "/GRANT:Everyone,FULL");
        } else if (os.equals("UNIX")) {
            if(os_minor.equals("Linux")) {
                Utils.executeSSHCommand("mkdir " + home_dir + "/probes/service/data/document_library", ip, "root", "t3sti9");
                Utils.executeSSHCommand("exportfs -o rw,sync,no_root_squash *:" + home_dir + "/probes/service/data/document_library", ip, "root", "t3sti9");
            }
            else if(os_minor.equals("Solaris")) {
                Utils.executeSSHCommand("share -f nfs -o rw=*,root=* " + home_dir + "/probes/service/data/document_library", ip, "root", "t3sti9");
            }
        }

        return true;
    }

    private boolean linkToSharedDir(NimAddress primary_ump_addr, NimAddress robot_addr) throws NimException, IOException, JSchException
    {
        logger.info("Linking to shared folder from " + robot_addr.toString() + " to " + primary_ump_robot_address);

        PDS primary_result = Utils.executeCallback(primary_ump_addr, sid, "controller", "get_info");
        PDS local_result = Utils.executeCallback(robot_addr, sid, "controller", "get_info");

        String primary_home_dir = primary_result.getString("workdir").replace("\\", "\\\\");
        String primary_ip = primary_result.getString("robotip");

        String local_os = local_result.getString("os_major");
        String local_os_minor = local_result.getString("os_minor");
        String local_home_dir = primary_result.getString("workdir").replace("\\", "\\\\");
        String local_ip = local_result.getString("robotip");

        if(local_os.equals("Windows")) {
            Utils.executeProcess("psexec", "\\\\" + local_ip, "-u", "Administrator", "-p", "t3sti9", "C:\\windows\\system32\\cmd.exe",
                    "/c", "mklink", "/d", local_home_dir + "\\probes\\service\\data\\document_library", "\\\\" + primary_ip + "\\document_library");
        }
        else if(local_os.equals("UNIX")) {
            Utils.executeSSHCommand("mkdir " + local_home_dir + "/probes/service/data/document_library", local_ip, "root", "t3sti9");

            if(local_os_minor.equals("Linux"))
                Utils.executeSSHCommand("mount -t nfs " + primary_ip + ":" + primary_home_dir + "/probes/service/data/document_library " +
                        local_home_dir + "/probes/service/data/document_library", local_ip, "root", "t3sti9");
            else if(local_os_minor.equals("Solaris"))
                Utils.executeSSHCommand("mount -F nfs " + primary_ip + ":" + primary_home_dir + "/probes/service/data/document_library " +
                        local_home_dir + "/probes/service/data/document_library", local_ip, "root", "t3sti9");
        }

        return true;
    }

    private boolean check_job_status(NimAddress robot_address, String job_name) {
        PDS deploy_status;
        PDS[] status_tables;
        boolean deployed = false;
        double finished_jobs, size;

        Utils.printProgBar(0);
        while(!deployed) {
            try {
                Thread.sleep(5000);
                finished_jobs = 0.0;
                deploy_status = Utils.executeCallback(robot_address, sid, "distsrv", "job_list", job_name);
                status_tables = deploy_status.getTablePDSsIfPresent("entry");
                size = (float) status_tables.length;

                for (PDS p : status_tables)
                    finished_jobs += (p.getString("status").equals("finished")) ? 1 : 0;

                Utils.printProgBar((int) ((finished_jobs / size) * 100));
                if (finished_jobs == size) deployed = true;
            } catch(InterruptedException e) {
                logger.warn("Job status thread interrupted");
            } catch(NimException e) {
                logger.error(e.getMessage(), e);
            }
        }

        return false;
    }

    private boolean pushPackages(NimAddress robot_address) throws InterruptedException {
        String job_name = "auto_installer_" + sid.substring(0,8);

        for(String pkg : ump_pkg_list)
            pushPackage(primary_hub_robot, robot_address, job_name, pkg, null);

        return check_job_status(primary_hub_robot, job_name);
    }

    private void pushPackage(NimAddress primary_hub_address, NimAddress robot_address, String job_name, String pkg, String version) {
        try {
            Utils.executeCallback(primary_hub_address, sid, "distsrv", "job_add", job_name, null, pkg, version, robot_address.toString());
        } catch(NimException e) {
            logger.error("Unable to push package: " + pkg);
        }
    }

    private void extractPsExec()
    {
        try {
            String home = getClass().getProtectionDomain()
                    .getCodeSource().getLocation()
                    .getPath().replaceAll("%20", " ");
            JarFile jar = new JarFile(home);
            ZipEntry entry = jar.getEntry("PsExec.exe");

            File efile = new File(entry.getName());

            InputStream in =
                    new BufferedInputStream(jar.getInputStream(entry));
            OutputStream out =
                    new BufferedOutputStream(new FileOutputStream(efile));
            byte[] buffer = new byte[2048];
            for (;;)  {
                int nBytes = in.read(buffer);
                if (nBytes <= 0) break;
                out.write(buffer, 0, nBytes);
            }
            out.flush();
            out.close();
            in.close();
        } catch(Exception e) {
            logger.error(e.getMessage(), e);
        }
    }
}
