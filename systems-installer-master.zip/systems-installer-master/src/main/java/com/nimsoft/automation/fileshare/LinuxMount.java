package com.nimsoft.automation.fileshare;

import com.nimsoft.automation.utils.OS;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteException;
import org.omg.SendingContext.RunTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

/**
 * Created by william on 8/3/2015.
 */
public class LinuxMount {
    static Logger logger = LoggerFactory.getLogger(LinuxMount.class);

    private final String FILESHARE = "fileshare.dev.fco";

    private String networkPath = FILESHARE + ":/mnt/vg_main/vol01/QA/NimBUS-install/";
    private String localPath = "/mnt/installer";
    DefaultExecutor executor = new DefaultExecutor();

    /**
     * @Author - sean williams
     * use default settings which are:
     * networkPath = fileshare.dev.fco:/mnt/vg_main/vol01/QA/NimBUS-install/"
     * localPath = "/mnt"
     */
    public LinuxMount(){
        executor.setExitValue(0);
        makeDir();
    }

    /**takes in netowrk path, and local path
     *
     * @Author - sean williams
     * @param networkPath
     * @param localPath
     */
    public LinuxMount(String networkPath, String localPath){
        this.networkPath = networkPath;
        this.localPath = localPath;
        executor.setExitValue(0);
        makeDir();
    }

    public void makeDir(){
        logger.info("Creating directory "+localPath);
        if (!new File(localPath).exists()){
            new File(localPath).mkdir();
        }
    }

    public int mount(){
        if (OS.isUnix()) {
            String[] cmdLine = new String[]{"mount", "-t", "nfs", networkPath, localPath};
            CommandLine mount = buildCommandLine(cmdLine);
            return executeCmd(mount);
        }
        else {
            String[] cmdLine = new String[]{"mount", "-F", "nfs", networkPath, localPath};
            CommandLine mount = buildCommandLine(cmdLine);
            return executeCmd(mount);
        }
    }

    public int umount() {
        if (OS.isUnix()) {
            String[] command = new String[]{"umount", "-l", localPath};
            CommandLine unmount = buildCommandLine(command);
            return executeCmd(unmount);
        }
        else {
            String[] command = new String[]{"umount",  localPath};
            CommandLine unmount = buildCommandLine(command);
            return executeCmd(unmount);
        }
    }


    public CommandLine buildCommandLine(String[] cmdArray) {
        CommandLine cmdLine;
        cmdLine = new CommandLine(cmdArray[0]);
        int maxLength = cmdArray.length;
        int count = 1;
        while (count != maxLength) {
            cmdLine.addArgument(cmdArray[count]);
            count++;
        }

        return cmdLine;
    }
    public int executeCmd(CommandLine cmdLine) {
        int exitValue = -1;
        DefaultExecutor executor = new DefaultExecutor();
        executor.setExitValue(0);
        logger.info("Attempting to run command [" + cmdLine.toString() + "]");
        try {
            exitValue = executor.execute(cmdLine);
            return exitValue;
        } catch (ExecuteException e) {
            logger.error(e.getMessage(), e);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
        return exitValue;
    }

    public void removeDir(){
        logger.info("Removing Directory " +localPath);
        if (new File(localPath).exists()){
            new File(localPath).delete();
        }
    }

    public String getLocalPath() {
        return localPath;
    }

    public String getNetworkPath() {
        return networkPath;
    }
}
