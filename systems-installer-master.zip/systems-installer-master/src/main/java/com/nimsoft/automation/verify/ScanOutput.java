package com.nimsoft.automation.verify;

import com.nimsoft.automation.installer.InstallPaths;
import com.nimsoft.automation.utils.OS;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

/**
 * Created by schja33 on 2/10/14.
 * Class for greping the iaoutput file for errors/failures/etc
 */
public class ScanOutput {
    private static final String IAoutputFileUNIX = "/tmp/ia/iaoutput.txt";
    private static final String IAoutputFileWIN= "C:\\tmp\\ia\\iaoutput.txt";
    private static final String UMPLOGUNIX = "/tmp/ia/ump.log";
    private static final String UMPLOGWIN= "C:\\tmp\\ia\\ump.log";

    //UIM v2 installer log paths
    private static final String IAoutputFileUNIXPost82 = "/tmp/ca_uim/uimserver_ia_install.log";
    private static final String IAoutputFileWINPost82= "C:\\tmp\\ca_uim\\uimserver_ia_install.log";

    public String outputFile;
    public String installType;
    public String version;

    public ScanOutput(String installType, String version) {
        this.installType = installType;
        this.version = version;
        setOuputfile();
    }

    public String getOutputFile() {
        return outputFile;
    }

    public String setOuputfile() {
        boolean is_windows = OS.isWindows(), is_82_or_higher = isPostVersion(8, 1);

        if(is_windows) {
            if(is_82_or_higher && installType.equals("nms")) outputFile = IAoutputFileWINPost82;
            else if(!is_82_or_higher && installType.equals("nms")) outputFile = IAoutputFileWIN;
            else outputFile = UMPLOGWIN;
        } else {
            if(is_82_or_higher && installType.equals("nms")) outputFile = IAoutputFileUNIXPost82;
            else if(!is_82_or_higher && installType.equals("nms")) outputFile = IAoutputFileUNIX;
            else outputFile = UMPLOGUNIX;
        }

        return outputFile;
    }

    public void setOutputfile(String location){
       outputFile = location;
    }

    public List<String> scanForText(String[] SearchText) throws FileNotFoundException {
        File file = new File(outputFile);
        ArrayList<String> rc = new ArrayList<String>();
        Scanner scanner = new Scanner(file);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            System.out.println(lineFromFile);
            for(int i = 0; i < SearchText.length; i++) {
                String item =  SearchText[i];
                if(lineFromFile.contains(item)) {
                    // a match!
                    rc.add(item + " : " + lineFromFile);
                    //System.out.println("I found " + item + " in file " + outputFile);
                }
            }
        }
        scanner.close();
        if (installType.equals("nms"))
            return scanForTextExceptionNMS(rc);
        else if (installType.equals("ump"))
            return scanForTextExceptionUMP(rc);
        else
            throw new FileNotFoundException("Cannot process because of incorrect install type");
    }


    public List<String> scanForTextExceptionUMP(List<String> returnList) {
        String[] listSearchStringsException = {"Error retrieving registry key: java.lang.NullPointerException"};
        return scanForTextException(listSearchStringsException, returnList);
    }


    public List<String> scanForTextExceptionNMS(List<String> returnList) {
        String[] listSearchStringsException = {"nametoip failed", "sec_verify_failed=0", "sec_login_failed=0", "sec_login_failed=Element", "sec_verify_failed"};
        return scanForTextException(listSearchStringsException, returnList);
    }


    public List<String> scanForTextException(String[] listSearchStringsException, List<String> returnList) {
        List<String> rc = new ArrayList<String>();
        boolean accept = false;
        for (String line : returnList) {
            for (String exception : listSearchStringsException) {
                if (line.contains(exception)) {
                    accept = true;
                }
            }
            if (!accept) {
                rc.add(line);
            } else
                System.out.println("Skipping line because it is listed in exception list for NMS installer: " + line);
            accept = false;
        }
        return rc;
    }

    public String summaryInstall(String properties, List<String> rc, boolean is_v2_installer) throws IOException {
        String summaryFile;
        if (OS.isWindows()) {
            summaryFile = "C:\\tmp\\ia\\summary_iaoutput.txt";
        } else {
            summaryFile = "/tmp/ia/summary_iaoutput.txt";
        }
        PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(summaryFile, true)));
        out.println("Summary of Installer Properties from the properties file ");
        out.println("###########################################################");
        File propFile = new File(properties);
        Scanner scanner = new Scanner(propFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            //System.out.println(lineFromFile);
            out.println(lineFromFile);
        }
        List<String> probeSummary;
        probeSummary = retrieveProbeSummary();
        out.println();
        out.println("Probe Summary");
        out.println("###########################################################");
        out.println();
        for (String line : probeSummary) {
            out.println(line);
        }
        out.println();
        out.println("Summary of Failed and Error messages found in the installer output file");
        out.println("###########################################################");
        out.println();

        if(!rc.isEmpty()) {
            for (String line : rc) {
                out.println(line);
            }
        }
        out.println("###########################################################");
        out.close();
        return summaryFile;
    }

    public List retrieveProbeSummary() throws FileNotFoundException {
        String probeStatusStart = "Final Probe Status Summary";
        String probeStatusStop = "JumpAction:";
        String probeStatusStop2 = "Successfully Completed Probe Startup!";
        List rc = new ArrayList<String>();
        File file = new File(outputFile);
        Scanner scanner = new Scanner(file);
        boolean inCond = false;
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            System.out.println(lineFromFile);
            if(lineFromFile.contains(probeStatusStart)) {
                rc.add(lineFromFile);
                inCond = true;
            }

            else if(lineFromFile.contains(probeStatusStop)) {
                rc.add(lineFromFile);
                break;
            } else if (lineFromFile.contains(probeStatusStop2)) {
                rc.add(lineFromFile);
                break;
            } else if (inCond) {
                rc.add(lineFromFile);
            }
        }
        scanner.close();

        return rc;
    }

    private boolean isPostVersion(int major_version, int minor_version) {
        String[] version_parts = version.split("\\.");
        int major = Integer.parseInt(version_parts[0]);
        int minor = Integer.parseInt(version_parts[1]);
        if(minor >= 10) minor = minor / 10;
        return major >= major_version && minor > minor_version;
    }

}