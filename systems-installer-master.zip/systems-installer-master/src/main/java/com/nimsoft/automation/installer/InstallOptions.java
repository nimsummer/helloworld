package com.nimsoft.automation.installer;

import org.apache.commons.cli.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by dustinlish on 1/12/14.
 * Modified by hajbr03 on 1/5/2015 - refactoring and code cleanup
 */
public class InstallOptions {
    static Logger logger = LoggerFactory.getLogger(InstallOptions.class);

    private Options opts;
    private CommandLine cli;

    private final List<String> NMS_REQUIRED_ARGS = Arrays.asList("install", "version", "db_type", "ip");
    private final List<String> UMP_REQUIRED_ARGS = Arrays.asList("install", "version", "ip", "domain", "hub", "robot", "user", "password");
    private final List<String> ROBOT_REQUIRED_ARGS = Arrays.asList("install", "ip", "domain", "hub", "robot");
    private final List<String> HUB_REQUIRED_ARGS = Arrays.asList("install", "ip", "domain", "hub", "robot", "hubversion", "targets");

    public InstallOptions(String[] args) throws ParseException {
        CommandLineParser parser = new GnuParser();
        opts = initOptions();

        try {
            cli = parser.parse(opts, args);
            validateArgs(cli);
        } catch (ParseException e) {
            help(opts);
            throw e;
        } catch (NullPointerException e) {
            help(opts);
        }
    }

    private void validateArgs(CommandLine cli) throws ParseException {
        String install_type = cli.getOptionValue("install").toLowerCase();
        if (install_type.equals("nms")) {
            validateRequiredArgs(NMS_REQUIRED_ARGS, install_type);

            if (!checkVersion(cli.getOptionValue("install"), cli.getOptionValue("version"))) {
                throw new ParseException("Version parameter contains unrecognized version: " + cli.getOptionValue("build")
                        + "\nValid formats are: NMS: 0.00 - UMP: 0.0.0\n");
            }
            if (!checkDbType(cli.getOptionValue("db_type"))) {
                throw new ParseException("db_type parameter contains unrecognized database: " + cli.getOptionValue("db_type")
                        + "\nValid dbs are: mssql|mysql|oracle\n");
            } else if((!"mssql".equalsIgnoreCase(cli.getOptionValue("db_type"))) && cli.getOptionValue("db_auth") != null) {
                throw new ParseException("db_auth parameter can only be specified when using the MSSQL db_type\n");
            }
            if (!checkIp(cli.getOptionValue("ip"))) {
                throw new ParseException("IP parameter contains invalid IP address: " + cli.getOptionValue("ip"));
            }
        } else if (install_type.equals("ump")) validateRequiredArgs(UMP_REQUIRED_ARGS, install_type);
        else if (install_type.equals("robot")) validateRequiredArgs(ROBOT_REQUIRED_ARGS, install_type);
        else if (install_type.equals("hub")) validateRequiredArgs(HUB_REQUIRED_ARGS, install_type);
        else throw new ParseException("Unknown install type passed");
    }

    private void validateRequiredArgs(List<String> arg_list, String install_type) throws ParseException {
        for (String arg : arg_list) {
            if (!cli.hasOption(arg)) {
                throw new ParseException("Missing required option for " + install_type + " installs: " + arg + "\nPlease specify and try again");
            }
        }
    }

    private Options initOptions() {
        Options opts = new Options();

        opts.addOption("help", false, "Display usage");

        /**
         * Common installer options
         */
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("install")
                       .withType(String.class)
                       .withDescription("NMS|UMP|ROBOT|HUB")
                       .create("install")
                      );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("version")
                       .withType(String.class)
                       .withDescription("Version to install")
                       .create("version")
                      );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("build")
                       .withType(String.class)
                       .withDescription("(optional) build date to install:\n"
                                        + "\tNMS: YYYY_MM_DD-mm_ss\n"
                                        + "\tUMP: YYYY-MM-DD\n")
                       .create("build")
                      );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("USER_INSTALL_DIR")
                       .withType(String.class)
                       .withDescription("(optional) custom Nimsoft install location")
                       .create("user_install_dir")
                      );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("ip")
                       .withType(String.class)
                       .withDescription("IP address of system installing to")
                       .create("ip")
                      );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("properties")
                       .withType(String.class)
                       .withDescription("(optional) custom properties file, will fill properties contained in this file")
                       .create("properties")
                      );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("local_installer")
                       .withType(String.class)
                       .withDescription("(optional) full path location of the installer to be used")
                       .create("local_installer")
                      );
        opts.addOption(OptionBuilder
                        .hasArg()
                        .withArgName("custom_path")
                        .withType(String.class)
                        .withDescription("(optional) full path from fileshare to the location of the installer to be used, starting a fileshare\\QA\\")
                        .create("custom_path")
        );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("NMSDOMAIN")
                       .withType(String.class)
                       .withDescription("Nimsoft domain name\n"
                                        + "\tNMS: (optional)\n"
                                        + "\tUMP: (required)\n")
                       .create("domain")
                      );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("NMSHUB")
                       .withType(String.class)
                       .withDescription("Nimsoft hub name\n"
                                        + "\tNMS: (optional)\n"
                                        + "\tUMP: (required)\n")
                       .create("hub")
                      );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("NMSROBOT")
                       .withType(String.class)
                       .withDescription("Nimsoft robot name\n"
                                        + "\tNMS: (optional)\n"
                                        + "\tUMP: (required)\n")
                       .create("robot")
                      );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("INSTALL_ROBOT")
                       .withType(String.class)
                       .withDescription("Remote installation of a robot option\n"
                                        + "\tNMS: (optional)\n"
                                        + "\tUMP: (optional)\n")
                       .create("install_robot")
                      );
        opts.addOption(OptionBuilder
                       .withArgName("bnpp")
                       .withDescription("(optional) Uses bnpp installers")
                       .create("bnpp")
                      );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("NIMBUS_PASSWORD")
                       .withType(String.class)
                       .withDescription("Nimsoft password\n"
                               + "\tNMS: (optional)\n"
                               + "\tUMP: (required)\n")
                       .create("password")
                      );
        opts.addOption(OptionBuilder
                        .withArgName("bitsonly")
                        .withType(String.class)
                        .withDescription("(optional) stages bits but does not start the installation")
                        .create("bitsonly")
        );
        opts.addOption(OptionBuilder
                .hasArg()
                .withArgName("DB_ORACLE_INSTANTCLIENT_DIR")
                .withType(String.class)
                .withDescription("Path to the Oracle instant client directory")
                .create("instantclient_dir")
        );

        /**
         * NMS related options
         */
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("db_type")
                       .withType(String.class)
                       .withDescription("MSSQL|MySQL|ORACLE")
                       .create("db_type")
                      );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("NIMDBNAME")
                       .withType(String.class)
                       .withDescription("(optional) Nimsoft database name")
                       .create("db_name")
                      );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("DB_SERVER")
                       .withType(String.class)
                       .withDescription("(optional) Database server")
                       .create("db_server")
                      );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("DB_PORT")
                       .withType(String.class)
                       .withDescription("(optional) Database port")
                       .create("db_port")
                      );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("DB_ADMIN_USER")
                       .withType(String.class)
                       .withDescription("(optional) Database username for MSSQL||MYSQL")
                       .create("db_user")
                      );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("DB_ADMIN_PASSWORD")
                       .withType(String.class)
                       .withDescription("(optional) Database password for MSSQL||MYSQL")
                       .create("db_pass")
                      );
        opts.addOption(OptionBuilder
                        .hasArg()
                        .withArgName("DB_AUTH_MODE")
                        .withType(String.class)
                        .withDescription("(optional) Specify MSSQL authentication mode (sqlserver_dbauthmode_sqlserver|sqlserver_dbauthmode_windows)")
                        .create("db_auth"));
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("ORASID")
                       .withType(String.class)
                       .withDescription("(optional) Oracle SID or service name or pdbName")
                       .create("orasid")
                      );
        opts.addOption(OptionBuilder
                        .hasArg()
                        .withArgName("DB_VERSION")
                        .withType(String.class)
                        .withDescription("Oracle Version (oracle_12)")
                        .create("db_version")
        );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("NIMDB_USER")
                       .withType(String.class)
                       .withDescription("(optional) Oracle database user")
                       .create("nimdb_user")
                      );
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("NIMDB_PASS")
                       .withType(String.class)
                       .withDescription("(optional) Oracle database password")
                       .create("nimdb_pass")
                      );
        opts.addOption(OptionBuilder
                       .hasOptionalArg()
                       .withArgName("drop")
                       .withDescription("(optional) Drop database if it exists NOTE: Will drop default 'ip_auto' db if not specified on command line")
                       .create("drop")
                      );


        /**
         * UMP related options
         */
        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("NIMBUS_USERNAME")
                       .withType(String.class)
                       .withDescription("Nimsoft username (REQUIRED for UMP installs)")
                       .create("user")
                      );

        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("UMP_ROBOT")
                       .withType(String.class)
                       .withDescription("Remote robot name to deploy UMP to (OPTIONAL)")
                       .create("robot_name")
                      );

        opts.addOption(OptionBuilder
                       .hasArg()
                       .withArgName("UMP_ROBOT_IP")
                       .withType(String.class)
                       .withDescription("Remote robot ip (REQUIRED if -robot_name option used)")
                       .create("robot_ip")
                      );

        /**
         * Multi-UMP related options
         */

        opts.addOption(OptionBuilder
                        .hasArg()
                        .withArgName("SECONDARY_ROBOTS")
                        .withType(String.class)
                        .withDescription("Comma-separated list of robot names for multi UMP install.")
                        .create("secondary_robots")
        );

        /**
         * Robot related options
         */
        opts.addOption(OptionBuilder
                        .hasArg()
                        .withArgName("TARGETS")
                        .withType(String.class)
                        .withDescription("Comma-separated list of robot names for ADE installation")
                        .create("targets")
        );

        opts.addOption(OptionBuilder
                        .hasArg()
                        .withArgName("XML")
                        .withType(String.class)
                        .withDescription("Path to user-defined host-profiles.xml")
                        .create("xml")
        );

        opts.addOption(OptionBuilder
                        .hasArg()
                        .withArgName("HUBROBOTNAME")
                        .withType(String.class)
                        .withDescription("Name of the robot containing the hub for the installed robot to connect to")
                        .create("hubrobotname")
        );

        /**
         * Hub related options
         */
        opts.addOption(OptionBuilder.hasArg()
                        .withArgName("HUBVERSION")
                        .withType(String.class)
                        .withDescription("Version of the hub to deploy")
                        .create("hubversion")
        );

        return opts;
    }

    public Map<String, String> getOptionsMap() {
        // Get specific property based command line args
        Map<String, String> argMap = new HashMap<String, String>();
        for (Option opt : cli.getOptions()) {
            if (opt.getArgName() != null)
                argMap.put(opt.getArgName(), opt.getValue());
            else
                argMap.put("install", opt.getValue()); // Hack to work around bug in commons-cli setting first option arg_name to null...
        }

        return argMap;
    }

    /*public Map<String, String> getV2OptionsMap() {
        // Get specific property based command line args
        Map<String, String> argMap = new HashMap<String, String>();
        for (Option opt : cli.getOptions()) {
            if (opt.getArgName() != null)
                argMap.put(v1_to_v2_opts.get(opt.getArgName()), opt.getValue());
            else
                argMap.put("install", opt.getValue()); // Hack to work around bug in commons-cli setting first option arg_name to null...
        }

        return argMap;
    }*/

    public void help(final Options options) {
        final HelpFormatter formatter = new HelpFormatter();
        formatter.printHelp("Installer", options);
    }

    private boolean checkIp(String ip) {
        String[] octets = ip.split("\\.");
        if(ip.toLowerCase().contains("auto")) return true;
        return octets.length == 4 && isValidOctet(octets[0]) && isValidOctet(octets[1]) && isValidOctet(octets[2]) && isValidOctet(octets[3]);
    }

    private boolean isValidOctet(String s) {
        try {
            int octet = Integer.parseInt(s);
            return octet >= 0 && octet <= 255;
        } catch (NumberFormatException e) { return false; }
    }

    private boolean checkDbType(String db) {
        //if (db == null) return false;
        return db != null && (db.equalsIgnoreCase("mssql") || db.equalsIgnoreCase("mysql") || db.equalsIgnoreCase("oracle"));
    }

    /*private boolean checkBuild(String install, String build) {
        if (install == null || build == null) return false;

        if (install.toLowerCase().equals("nms")) {
            String regex = "\\d\\d\\d\\d_\\d\\d_\\d\\d-\\d\\d_\\d\\d";
            return build.matches(regex);
        } else {
            String regex = "\\d\\d\\d\\d-\\d\\d-\\d\\d";
            return build.matches(regex);
        }
    }*/

    private boolean checkVersion(String install, String version) {
        String nms_regex = "\\d.\\d\\d", other_regex = "\\d.\\d.\\d";

        if (install == null || version == null) return false;
        else return (install.toLowerCase().equals("nms") && version.matches(nms_regex)) || version.matches(other_regex);
    }

    public Options getOpts() { return opts; }

    public CommandLine getCli() { return cli; }
}
