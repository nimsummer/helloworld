package com.nimsoft.automation.utils;

import com.nimsoft.automation.installer.Install;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.*;

/**
 * Created by dustinlish on 1/11/14.
 *
 */
public class Props {
    static Logger logger = LoggerFactory.getLogger(Props.class);

    // NMS Properties
    private final InputStream NMS_MSSQL_PROPERTIES = getClass().getClassLoader().getResourceAsStream("DB/mssql.properties");
    private final InputStream NMS_MYSQL_PROPERTIES = getClass().getClassLoader().getResourceAsStream("DB/mysql.properties");
    private final InputStream NMS_ORACLE_PROPERTIES = getClass().getClassLoader().getResourceAsStream("DB/oracle.properties");
    private final InputStream NMS_ORACLE12_PROPERTIES = getClass().getClassLoader().getResourceAsStream("DB/oracle12.properties");

    // Default properties file generated
    private final String INSTALLER_PROPERTIES = "installer.properties";

    private final List<String> INSTALL_TYPES = Arrays.asList("nms", "ump", "multi_ump","ur");
    private final List<String> DB_TYPES = Arrays.asList("mssql", "mysql", "oracle");

    private Properties prop;
    private String install;
    private String db;
    private String ip;
    private double version;

    private Map<String, String> v1_to_v2_props;
    private boolean v2_installer = false;

    // NMS constructor
    public Props(String install, String ip, String db, String version) {
        v1_to_v2_props = createV1ToV2Map();
        if(version != null) {
            String[] version_parts = version.split("\\.");
            int major_version = Integer.parseInt(version_parts[0]), minor_version = Integer.parseInt(version_parts[1]);
            // this cuases issues for releases like 8.31, it will get paired down to 8.3....
            if(minor_version >= 10 && (minor_version %10 == 0)) minor_version = minor_version / 10;
            this.version = Double.parseDouble(major_version+"."+minor_version);
            logger.info("Major Version: " + major_version + ", Minor Version: " + minor_version);
            v2_installer = install.equalsIgnoreCase("nms") && (major_version > 8 || (major_version == 8 && minor_version > 1));
            logger.info("V2 Installer?: " + Boolean.toString(v2_installer));
        } else {
            v2_installer = false;
        }

        if ( (INSTALL_TYPES.contains(install.toLowerCase()) && DB_TYPES.contains(db.toLowerCase())) && ip != null ) {
            this.install = install;
            this.db = db;
            this.ip = ip;
        } else {
            throw new IllegalArgumentException("Invalid argument specified to Props("+install+","+ip+","+db+") constructor\n" +
                "Valid options for install types: " + INSTALL_TYPES.toString() + "\n Valid options for db types: " + DB_TYPES.toString());
        }

        initProps(install);
    }

    // UMP
    public Props(String install, String ip) {
        if ( (INSTALL_TYPES.contains(install.toLowerCase()) && ip != null) ) {
            this.install = install;
            this.ip = ip;
        } else {
            throw new IllegalArgumentException("Invalid argument specified to Props("+install+","+ip+") constructor\n" +
                                               "Valid options for install types: " + INSTALL_TYPES.toString());
        }

        initProps(install);
    }

    private Map<String, String> createV1ToV2Map() {
        Map<String, String> mapper = new HashMap<String, String>();
        mapper.put("USER_INSTALL_DIR","USER_INSTALL_DIR");
        mapper.put("NIMDBTYPE","DB_NORMALIZED_PROVIDER_NAME");
        mapper.put("NIMDBCREATE","DB_CREATE_MODE");
        mapper.put("DB_SERVER","DB_SERVER");
        mapper.put("DB_PORT","DB_PORT");
        mapper.put("NIMDBNAME","DB_NAME");
        mapper.put("DB_ADMIN_USER","DB_ADMIN_USERNAME");
        mapper.put("DB_ADMIN_PASSWORD","DB_ADMIN_PASSWD");
        mapper.put("MSSQLAUTHTYPE","DB_AUTH_MODE");
        mapper.put("ORASID","DB_SERVICENAME");
        mapper.put("NIMDB_USER","DB_TABLESPACENAME");
        mapper.put("NIMDB_PASS","DB_SYS_PASSWD");
        mapper.put("NIMBUS_PASSWORD","NM_ADMIN_PASSWD");
        mapper.put("NMSDOMAIN","NMS_DOMAIN");
        mapper.put("NMSHUB","NMS_PRIMARY_HUB_NAME");
        mapper.put("NMSROBOT","NMS_PRIMARY_ROBOT_NAME");
        mapper.put("NMS_PROBE_PORT","NMS_FIRST_PROBE_PORT");
        mapper.put("NMSNETWORKIP","NMS_PRIMARY_HUB_IP");
        mapper.put("DB_ORACLE_INSTANTCLIENT_DIR","DB_ORACLE_INSTANTCLIENT_DIR");
        return mapper;
    }

    /*
     * Loads installer.all.properties with all possible keys for specified installer
     */
    private void initProps(String install) {
        this.prop = new Properties();
        InputStream properties;

        properties = (v2_installer) ?
                getClass().getClassLoader().getResourceAsStream("UIM_V2/installer.all.properties") :
                getClass().getClassLoader().getResourceAsStream(install.toUpperCase() + "/installer.all.properties");

        try {
            loadProps(properties);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }

        saveProps();
    }

    /*
     * Loads default database properties for specified db_type
     */
    public void loadDBProperties(String db) {
        if (db == null)
            throw new IllegalArgumentException("can't load null parameter");

        InputStream dbPropsStream;
        if (db.toLowerCase().equals("mssql"))
            dbPropsStream = NMS_MSSQL_PROPERTIES;
        else if (db.toLowerCase().equals("mysql"))
            dbPropsStream = NMS_MYSQL_PROPERTIES;
        else if(db.toLowerCase().equals("oracle"))
            dbPropsStream = NMS_ORACLE_PROPERTIES;
        else if(db.toLowerCase().equals("oracle_12"))
            dbPropsStream = NMS_ORACLE12_PROPERTIES;
        else
            throw new IllegalArgumentException("can't load unknown DB Type");

        try {
            loadProps(dbPropsStream);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }

        saveProps();
    }


    /*
     * Loads/Overrides any existing properties with user defined properties
     */
    public void loadCustomProperties(String customProperties) throws FileNotFoundException {
        if (!Utils.fileExists(customProperties))
            throw new FileNotFoundException("Could not find: '" + customProperties + "' please verify file exists and try again");

        // load properties from file
        InputStream in;
        try {
            in = new FileInputStream(new File(customProperties));
            loadProps(in);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }

        saveProps();
    }

    public void loadCustomPropertiesFromMap(Map<String, String> props) {
        if (props == null)
            throw new IllegalArgumentException("cannot process null parameter");

        for(String key : props.keySet()) {
            String value = props.get(key);
            if (prop.containsKey(key)) prop.put(key, value);
            else if(v2_installer && v1_to_v2_props.containsKey(key)) prop.put(v1_to_v2_props.get(key), value);
        }

        saveProps();
    }

    private void loadProps(InputStream in) throws IOException {
        if (in == null)
            throw new IllegalArgumentException("cannot process null parameter");

        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        String line;

        while ((line = reader.readLine()) != null) {
            if (line.isEmpty() || line.charAt(0) == '#') continue;

            String[] property = line.split("=");
            if (property.length == 2)
                prop.put(property[0], property[1]);
            else if (!prop.containsKey(property[0]))
                prop.put(property[0], "");
        }
        reader.close();
    }

    public void searchAndReplaceProp(String search, String replace) {
        for (Map.Entry entry : prop.entrySet()) {
            if (entry.getValue().toString().toLowerCase().contains(search.toLowerCase())) {
                prop.put(entry.getKey(), entry.getValue().toString().replace(search, replace));
                logger.info(entry.getKey() + " Needs to be changed: " + entry.getValue());
            }
        }
        saveProps();
    }

    public void saveProps() {
        FileOutputStream os = null;
        if(v2_installer) convertV2Props();
        try {
            os = new FileOutputStream(INSTALLER_PROPERTIES);
            //save properties to project root folder
            prop.store(os, null);
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (os != null) {
                try {
                    os.close();
                } catch (IOException e) {
                    logger.error(e.getMessage(), e);
                }
            }
        }
    }

    private void convertV2Props() {
        for(String key : prop.stringPropertyNames()) {
            if(v1_to_v2_props.containsKey(key)) {
                String value = prop.getProperty(key);
                prop.remove(key);

                value = checkDbChanges(key, value);
                prop.put(v1_to_v2_props.get(key), value);
            }
        }
    }

    // Hacks to convert values that aren't used anymore into values that are.
    private String checkDbChanges(String key, String value) {
        if(key.equalsIgnoreCase("NIMDBCREATE"))
            return value.equalsIgnoreCase("true") ? "create" : "use existing";
        else if(key.equalsIgnoreCase("NIMDBTYPE") && value.equalsIgnoreCase("mssql"))
            return "sqlserver";
        else if(key.equalsIgnoreCase("MSSQLAUTHTYPE") && value.equalsIgnoreCase("sql"))
            return "sqlserver_dbauthmode_sqlserver";
        else if(key.equalsIgnoreCase("MSSQLAUTHTYPE") && value.equalsIgnoreCase("windows"))
            return "sqlserver_dbauthmode_windows";
        else
            return value;
    }

    public boolean cleanUp() {
        File file = new File(INSTALLER_PROPERTIES);
        return file.delete();
    }

    public void setUserDir() {
        if (OS.isWindows())
            prop.put("USER_INSTALL_DIR", "C:\\Program Files (x86)\\Nimsoft");
        else
            prop.put("USER_INSTALL_DIR", "/opt/nimsoft");
    }

    public void listProps() {
        try
        {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            PrintStream ps = new PrintStream(baos);
            prop.list(ps);
            String content = baos.toString("UTF-8");
            logger.info(content);
        } catch (Exception e) {
            Install.printStackTraceAndExit(e);
        }
    }

    public Properties getProp() {
        return prop;
    }

    public String getProp(String key) { return prop.containsKey(key) ? prop.get(key).toString() : null; }

    public void setProp(String key, String value) {
        prop.put(key, value);
        saveProps();
    }

    public String getPropertiesFile() {
        return INSTALLER_PROPERTIES;
    }

    public String getInstall() {
        return install;
    }

    public boolean isV2Installer() { return v2_installer; }

    public String getDb() {
        return db;
    }

    public String getIp() {
        return ip;
    }

    public Double getVersion(){
       return version;
    }
}
