package com.nimsoft.automation.utils;

import com.jcraft.jsch.*;
import com.nimsoft.automation.nimbus.NimAddress;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.nimbus.NimRequest;
import com.nimsoft.nimbus.NimSecurity;
import com.nimsoft.nimbus.PDS;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Created by dustinlish on 1/20/14.
 *
 */
public class Utils {

    static Logger logger = LoggerFactory.getLogger(Utils.class);
    private static final String discovery_salt = "øæå_@£$_åæø";
    private static final String data_engine_salt = "_sla_data_engine_";

    private Utils() {}

    @SuppressWarnings("deprecation")
    public static String encryptDiscoveryPassword(String decrypted) {
        if (decrypted == null || decrypted.length() == 0) return "";
        try {
            NimSecurity nso = new NimSecurity();
            return nso.encryptISO(discovery_salt, decrypted);
        } catch (NimException e) {
            logger.error("Cannot encrypt password, unable to initialize NimSecurity");
            return "";
        }
    }

    @SuppressWarnings("deprecation")
    public static String decryptDiscoveryPassword(String encrypted) {
        if (encrypted == null || encrypted.length() == 0) return "";

        try {
            NimSecurity nso = new NimSecurity();
            return nso.decryptISO(discovery_salt, encrypted);
        } catch (NimException e) {
            logger.error("Cannot decrypt password, unable to initialize NimSecurity");
            return "";
        }
    }

    public static String encryptDEPassword(String decrypted) {
        if (decrypted == null || decrypted.length() == 0) return "";
        NimSecurity nso = new NimSecurity();
        return nso.encryptUTF8(data_engine_salt, decrypted);
    }

    public static String decryptDEPassword(String encrypted) {
        if (encrypted == null || encrypted.length() == 0) return "";

        try {
            NimSecurity nso = new NimSecurity();
            return nso.decryptUTF8(data_engine_salt, encrypted);
        } catch (NimException e) {
            logger.error("Cannot decrypt password, unable to initialize NimSecurity");
            return "";
        }
    }

    public static boolean fileExists(String file) {
        File f = new File(file);
        return f.exists();
    }

    public static void copyFile(File source, File dest) throws IOException {
        FileUtils.copyFile(source, dest);
    }

    public static PDS executeCallback(NimAddress robot_addr, String sid, String probe, String callback_name, String... pds_args) throws NimException {
        Map<String, String> params = getCallbackArgs(robot_addr, sid, probe, callback_name);
        PDS args = new PDS();
        int index = 0;

        if(params.size() < pds_args.length) throw new IllegalArgumentException("Error, callback must have no more than " + params.size() + " arguments.");

        for(String key : params.keySet()) {
            if(index < pds_args.length) {
                if (params.get(key).equals("int"))
                    args.putInt(key, Integer.parseInt(pds_args[index]));
                else
                    args.putString(key, pds_args[index]);
            }
            index++;
        }

        NimRequest cb = new NimRequest(robot_addr.toString() + "/" + probe, callback_name, args);
        return cb.sendImpersonate(sid);
    }

    public static PDS executeCallback(String ip, int port, String sid, String callback_name, String... pds_args) throws NimException {
        Map<String, String> params = getCallbackArgs(ip, port, sid, callback_name);
        PDS args = new PDS();
        int index = 0;

        if(params.size() < pds_args.length) throw new IllegalArgumentException("Error, callback must have no more than " + params.size() + " arguments.");

        for(String key : params.keySet()) {
            if(index < pds_args.length) {
                if (params.get(key).equals("int"))
                    args.putInt(key, Integer.parseInt(pds_args[index]));
                else
                    args.putString(key, pds_args[index]);
            }
            index++;
        }

        NimRequest cb = new NimRequest(ip, port, callback_name, args);
        return cb.sendImpersonate(sid);
    }

    public static Map<String, String> getCallbackArgs(NimAddress robot_addr, String sid, String probe, String callback_name) throws NimException
    {
        Map<String, String> params = new LinkedHashMap<String, String>();
        NimRequest cb = new NimRequest(robot_addr.toString() + "/" + probe, "_command", null);
        PDS result = cb.sendImpersonate(sid);
        String[] callback_params = result.getString(callback_name).split(",");

        for (String param : callback_params) {
            if (param.contains("%d"))
                params.put(param.substring(0, param.length() - 2), "int");
            else
                params.put(param, "string");
        }

        return params;
    }

    public static Map<String, String> getCallbackArgs(String ip, int port, String sid, String callback_name) throws NimException {
        Map<String, String> params = new LinkedHashMap<String, String>();
        NimRequest cb = new NimRequest(ip, port, "_command", null);
        PDS result = cb.sendImpersonate(sid);
        String[] callback_params = result.getString(callback_name).split(",");

        for (String param : callback_params) {
            if (param.contains("%d"))
                params.put(param.substring(0, param.length() - 2), "int");
            else
                params.put(param, "string");
        }

        return params;
    }

    public static NimAddress getAddressFromIP(String ip, String sid) throws NimException {
        PDS result = executeCallback(ip, 48000, sid, "get_info");
        String domain = result.getString("domain");
        String hub = result.getString("hubname");
        String robot = result.getString("robotname");
        return new NimAddress(domain, hub, robot);
    }

    public static boolean activateProbes(NimAddress robot_address, String sid, String... probes) {
        try {
            for (String probe : probes) executeCallback(robot_address, sid, "controller", "probe_activate", probe);
            return true;
        } catch(Exception e) {
            logger.error(e.getMessage(), e);
            return false;
        }
    }

    public static boolean deactivateProbes(NimAddress robot_address, String sid, String... probes) {
        try {
            for (String probe : probes) executeCallback(robot_address, sid, "controller", "probe_deactivate", probe);
            return true;
        } catch(Exception e) {
            logger.error(e.getMessage(), e);
            return false;
        }
    }

    public static boolean waitForProbeStart(NimAddress robot_address, String sid, String probe, int timeout) {
        logger.info("Waiting for " + robot_address + "/" + probe + " to start (" + timeout + " seconds)");
        PDS result;

        while(timeout > 0) {
           try {
               result = executeCallback(robot_address, sid, probe, "_status");
               if (result != null) return true;
               timeout--;
               Thread.sleep(1000);
           } catch(NimException e) {
                //do nothing and keep waiting...
           } catch(InterruptedException e) {
               logger.error("Probe start thread interrupted");
           }
        }

        return false;
    }

    public static void cycleProbes(NimAddress robot_address, String sid, String... probes) {
        try {
            for(String probe : probes) {
                logger.info("Cycling " + probe + " probe");
                deactivateProbes(robot_address, sid, probe);
                Thread.sleep(10000);
                activateProbes(robot_address, sid, probe);
                waitForProbeStart(robot_address, sid, probe, 30000);
            }
        } catch(InterruptedException e) {
            logger.error("Thread interrupted during probe cycle operation");
        }
    }

    public static InputStream executeProcess(String... args) throws IOException {
        return new ProcessBuilder(args).start().getInputStream();
    }

    public static String executeSSHCommand(String command, String host, String user, String pass) throws JSchException, IOException {
        final String EoL = System.getProperty("line.separator");
        StringBuilder sb = new StringBuilder();
        JSch js = new JSch();
        Session s = js.getSession(user, host, 22);
        s.setPassword(pass);
        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        s.setConfig(config);
        s.connect();

        Channel c = s.openChannel("exec");
        ChannelExec ce = (ChannelExec) c;

        ce.setCommand(command);
        ce.setErrStream(System.err);
        ce.connect();


        BufferedReader reader = new BufferedReader(new InputStreamReader(ce.getInputStream()));
        String line;
        while ((line = reader.readLine()) != null) sb.append(line).append(EoL);

        ce.disconnect();
        s.disconnect();

        return sb.toString();
    }

    public static void printProgBar(int percent) {
        StringBuilder bar = new StringBuilder("[");

        for(int i = 0; i < 50; i++) {
            if( i < (percent/2)) { bar.append("="); }
            else if( i == (percent/2)) { bar.append(">"); }
            else { bar.append(" "); }
        }

        bar.append("]   " + percent + "%     ");
        logger.info("\r" + bar.toString());
    }
}
