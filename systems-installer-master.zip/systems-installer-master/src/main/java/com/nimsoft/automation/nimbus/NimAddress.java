package com.nimsoft.automation.nimbus;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by cullen on 4/23/14.
 *
 */
public class NimAddress {
    static Logger logger = LoggerFactory.getLogger(NimAddress.class);

    public String domain, hub, robot;

    public NimAddress(String fullAddress) {
        setAddress(fullAddress);
    }

    public NimAddress(String domain, String hub, String robot) {
        this.domain = domain;
        this.hub = hub;
        this.robot = robot;
    }

    public void setAddress(String fullAddress) {
        String[] sections = fullAddress.split("/");
        if (sections.length != 4 || sections[0].length() != 0)
            throw new RuntimeException("Invalid Nimsoft Address: " +fullAddress);
        domain = sections[1];
        hub = sections[2];
        robot = sections[3];
    }

    @Override
    public String toString() {
        return "/" +domain + "/" + hub + "/" + robot;
    }
}
