package com.nimsoft.automation.installer;

import com.nimsoft.automation.utils.Props;

import java.io.FileNotFoundException;
import java.net.UnknownHostException;
import java.util.Map;

/**
 * Created by dustinlish on 2/3/14.
 */
public interface NimsoftInstall {

    public void loadProps(Map<String, String> opts, String properties) throws FileNotFoundException, UnknownHostException;

    public String getPropertiesFile();

    public void listProps();

    public String getProp(String key);

    public Props getProp();

}
