package com.nimsoft.automation.installer;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.nimsoft.automation.fileshare.LinuxMount;
import com.nimsoft.automation.fileshare.Sftp;
import com.nimsoft.automation.utils.OS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.commons.io.FileUtils;

import java.io.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.concurrent.TimeUnit;

/**
 * Created by lisdu02 on 1/23/14.
 * Edited by schja33 on 7/8/14 for 8.0 release changes
 * Edited again by hajbr03 on 12/17/14 - Refactoring to clean up logic and make the code more readable.
 * Edited again by wilse03 on 7/6/15 for 8.31. installer is not picking up last digit for version.
 * Edited once again 7/29/15 to clean up logic, and enable multi version installs.
 */
public class InstallPaths {

    static Logger logger = LoggerFactory.getLogger(InstallPaths.class);

    private final String[] DRIVELETTERS     = {"i","q","b","r","x","w","e"};
    private final String LATESTVERSION      = "8.31";
    private final String LATESTUMPVERSION   =  LATESTVERSION.substring(0, 3) + "." + LATESTVERSION.substring(3);
    private final String windowsFileShare   = "//fileshare.dev.fco/QA/NimBUS-install/";
    private final String linuxFileShare     = "/mnt/vg_main/vol01/QA/NimBUS-install";
    private final String UIMSERVER          = "uimserver";
    private final String packageZip         = "uimserverpackages.zip";

    private String installer;
    private String installName;
    private String installType;
    private String version;
    private String build;
    private String drive;
    private String bnpp;
    private String customPath;
    private String buildFileDir;
    private String localInstaller;
    private boolean packages = false;
    public String fullDir;

    public InstallPaths(String localInstaller) {
        this.localInstaller = localInstaller;
        initLocal();
    }

    public InstallPaths(String installType, String version, String customPath, Map<String, String> optsMap) throws FileNotFoundException {
        this.customPath = customPath;
        this.installType = installType;
        this.version = version;
        initCustom();
    }

    public InstallPaths(String installType, String version) throws FileNotFoundException {
        this.installType = installType;
        this.version = version;
        this.build = "";
        this.bnpp = "";
        init();
    }

    public InstallPaths(String installType, String version, String build) throws FileNotFoundException {
        this.installType = installType;
        this.version = version;
        this.build = build;
        this.bnpp = "";
        init();
    }

    public InstallPaths(String installType, String version, String build, String bnpp) throws FileNotFoundException {
        this.installType = installType;
        this.version = version;
        this.build = build;
        this.bnpp = bnpp;
        init();
    }

//    private void init() throws FileNotFoundException {
//        setBuildFileDir();
//        setInstallName();
//        setDrive();
//        buildPathByType();
//
//        //getInstallType();
//    }


    private void initCustom() throws FileNotFoundException {
        this.build = "";
        this.bnpp = "";
        setDrive();
        File fullPath = new File(drive + customPath).getAbsoluteFile();
        logger.info("Full Path = " + fullPath.toString());
        fullDir = fullPath.toString();
        installer = fullPath.toString();
        //getInstallType();
    }

    private void initLocal() {
        installName = localInstaller;
        File fullPath = new File(installName);
        logger.info("Full Path = " + fullPath.toString());
        installer = fullPath.toString();
    }

    /**
     * @Author - sean williams
     * actually kicks off and does the work
     */
    protected void init() throws FileNotFoundException {
        LinuxMount lmount = new LinuxMount();
        String mountDir = lmount.getLocalPath();
        setInstallName();
        setDrive();
        try {
            if (!OS.isWindows()) {
                lmount.mount();
                drive = mountDir +"/";
            }
            this.buildFileDir = buildProductTypeFolder();
            this.version = formatVersion(version);
            fullDir = builldPath();

        } finally {
            if (!OS.isWindows()) {
                lmount.umount();
                lmount.removeDir();
                //I know this is gross, ugly, wrong, and bad... but because of how we use this later
                // on we need to replace the string :(
                installer = fullDir.replace(drive, linuxFileShare+"/");
                //because fo some reason we use fulldir and installer interchangeably all over the code base
                fullDir = installer;
            }
            else {
                //I know this is gross, ugly, wrong, and bad... but because of how we use this later
                // on we need to replace the string :(
                installer = fullDir.replace("//fileshare.dev.fco/QA/", drive + "/");
                installer = installer.replace("/","\\");
                //because fo some reason we use fulldir and installer interchangeably all over the code base
                fullDir = installer;
            }
            logger.info("FileShare path to installer is " +fullDir);
        }

    }


    /**
     * @Author - sean williams
     * build the path to grab the installer based on insall type
     * @return location of the build.
     */
    protected String builldPath() throws FileNotFoundException{
        String latestFolder = latestIntaller(getMount() + this.buildFileDir + "/" + version + "/");
        logger.info("Latest Folder: " + latestFolder);
        logger.info("building " + buildFileDir + " path to grab correct version");
        if (isNmsInstall()) {
            installer = latestFolder + "/" + getOSPath() + getSubPath() + installName;
            packages = checkPackages(latestFolder + "/" + getOSPath() + getSubPath());
        }
        else {
            String umpSubFolder = getUmpSubFolder(latestFolder);
            installer = umpSubFolder + "/" + installName;
        }
        logger.info("Grbbing the installer using path: " + installer);
        return installer;
    }

    /**
     * allows us to build the sub path for an NMS install after we have gotten the correct folder
     * for the version
     * @return string that is either VM or NoVM based on internal logic
     */
    public String getSubPath(){
        String subPath = "/NoVM/";
        if (!isPre80Version())
            subPath = "/VM/";

        if (OS.isWindows())
            if (!(version.contains("7.0") || version.contains("7.1") || version.contains("7.5")) || bnpp.equals("bnpp"))
                subPath = "/VM/";

        return subPath;
    }

    public String getOSPath() throws FileNotFoundException {
        String osPath;
        String architecture = System.getProperty("os.arch");
        if (!isPre80Version()) {
            if (OS.isWindows()) osPath = "windows_x64";
            else if (OS.isSolaris() && !architecture.contains("sparc")) osPath = "solaris_x64";
            else if (OS.isSolaris() && architecture.contains("sparc")) osPath = "solaris_sparc64";
            else if (OS.isUnix()) osPath = "linux_x64";
            else throw new FileNotFoundException("Could not determine what OS you were on for os specific installer location");
        }
        else
            osPath = OS.getOs();
        return osPath;
    }

    /**@Author - sean williams
     * Because the UMP team is odd and really wants to add another sub directory.  we have to check
     * if it is a current directory, if not we have to check for a sub directory. subfolder name contains version and "-<letter>"
     * @param latestFolder
     * @return
     */
    public String getUmpSubFolder(String latestFolder){
        File umpSubFiles = new File(latestFolder);
        String[] folders = umpSubFiles.list();
        String selectedFolder ="";
        for (String name : folders){
            String folderDir = latestFolder+"/"+name;
            //If the name of the sub folder contains the version it is probable one we want.
            //E.G for an 8.31 install look for a sub folder with 8.3.1-b
            if (name.contains(version) && new File(folderDir).isDirectory()){
                if (selectedFolder.equals("")) {
                    selectedFolder = folderDir;
                }
                else {
                    //If there are multiple subfolders that contain the version choose the newer
                    selectedFolder = chooseNewerFolder(selectedFolder, folderDir);
                }
            }

        }
        //if there is none, assume the installers are in the base directory
        if(selectedFolder.equals("")) selectedFolder =latestFolder;

        return selectedFolder;
    }


    /**
     * sets the installer filename depending on the install type.
     * cleaned up but not rewritten by Sean Williams
     * @return void
     */
    public void setInstallName() {
        if (OS.isWindows()){
            if (isPre80Version()){
                if (isBnpp() && isNmsInstall() ) installName = "install" + installType.toUpperCase() + "_bnpp.exe";
                else installName = "install" + installType.toUpperCase() + ".exe";
            }
            else {
                if (isNmsInstall()) installName = "setupCAUIMServer.exe";
                else installName = "install" + installType.toUpperCase() + ".exe";
            }
        }
        else {
            if (isPre80Version() && isNmsInstall()){
                if (isBnpp()) installName = "installNMS_bnpp.bin";
                else installName = "installNMS.bin";
            }
            else if (isNmsInstall()) installName = "setupCAUIMServer.bin";
            else {
                if (isSparcInstall()) installName = "install" + installType.toUpperCase() + "_solaris_sparc.bin";
                else installName = "install" + installType.toUpperCase() + "_" + OS.getOs().toLowerCase() + ".bin";

            }
        }
        logger.info("Getting bits for " + installType + " " + version + " - Installer = " + installName);
    }

    public boolean isPre80Version() { return (version.startsWith("7.") || version.startsWith("6.")); }

    public boolean isPostVersion(int major_version, int minor_version) {
        String[] version_parts = version.split("\\.");
        int major = Integer.parseInt(version_parts[0]);
        int minor = Integer.parseInt(version_parts[1]);
        if(minor >= 10) minor = minor / 10;
        return major >= major_version && minor > minor_version;
    }


    public void setDrive() throws FileNotFoundException {
        if (OS.isWindows()) setWinDrive();
        else drive = "/mnt/vg_main/vol01/QA";
        logger.info("Drive to use = " + drive);
    }

    public String setWinDrive() throws FileNotFoundException {
        int i = 0;
        String endLetter = DRIVELETTERS[DRIVELETTERS.length-1];
        File f = new File(DRIVELETTERS[i]+":");
        while (f.exists()) {
            if(endLetter.equals(DRIVELETTERS[i])) {
                throw new FileNotFoundException("All drives are busy");
            } else {
                logger.info("Current letter is in use " + DRIVELETTERS[i]);
                i++;
                f = new File(DRIVELETTERS[i]+":");
            }
        }
        drive = DRIVELETTERS[i]+":";
        return drive;
    }

    /**
     * returns the product type we are going to install ("nms", "UMP", etc), used to help build the path.
     * @Author - sean williams & Bruce Hadju
     * @return
     */
    protected String buildProductTypeFolder(){
        if (isNmsInstall()){
            if (isPre80Version()){
                return "NMS";
            }
            else {
                return "uimserver";
            }
        }
        else if (isUmpInstall()) {
            return "UMP";
        }
        else {
            return "UR";
        }

    }

    /**
     * returns: the directory filepath to the bits we should use.
     * @param dirPath: Path of the directory we want to search for items tagged as GA, CR, CURRENT
     * @Author - sean williams
     * @return
     */
    protected String latestIntaller(String dirPath){
        /*  open up the directory and get a list of all files/folders. Go through all checking for a
            folder name containing GA, CR, or current.  priority order is GA, CR, Current.
        */
        if(build.length() > 0) {
            logger.info("Using build folder: " + build);
            return dirPath + build;
        }

        logger.info("looking for latest installer in folder: " +dirPath);
        File file = new File(dirPath);
        try {
            //If the file does not exist throw a FNF Exception to break us out of here.
            //If we don't throw the exception we get null pointer exceptions.
            if (!file.exists()){
                logger.error("Folder for " +dirPath+" not found. please check fileshare if the folder exists");
                throw new FileNotFoundException();
            }
            //Get a list of the items in the folder, check if they are directories. If yes check if
            //their name conatins ga, cr, or current. Send collection of selected folders to the
            //choose installer method to....... choose the installer we want.
            String[] folderNames = file.list();
            HashMap<String, String> foundFolders = new HashMap<String, String>();
            for (String name : folderNames) {
                name = dirPath + name;
                if (new File(name).isDirectory()) {
                    String lowerName = new File(name).getName().toLowerCase();
                    if (lowerName.contains("ga")) foundFolders.put(name, "ga");
                    else if (lowerName.contains("cr")) foundFolders.put(name, "cr");
                    else if (lowerName.contains("current")) foundFolders.put(name, "current");
                }
            }
            //If we dont find any folders that contain our keywords assume there is a current.txt
            //file. Read from the file to get the directory we want.
            if (foundFolders.isEmpty()) {
                String current_build = FileUtils.readLines(new File(dirPath + "current.txt")).get(0);
                logger.info("Using latest folder found: " + current_build + " from current file");
                //return the current folder listed in the file attached to the directory path.
                return dirPath + current_build;
            }
            //return the chosen installer
            return chooseInstaller(foundFolders);
        } catch (IOException e) {
            logger.error("Exception caught while trying to find latest folder.");
            e.printStackTrace();
        }

        //returning null is fine, if we return null we want to die.
        return null;

    }

    /**@Author - sean williams
     * Chooses the installer we want to grab and use to..... install. will choose GA > CR > Current
     * @param foundFolders
     * @return string of file determined to be correct. may be GA, CR, or current.
     */
    private String chooseInstaller(HashMap<String, String> foundFolders){
        String selectedFolder ="";
        String selectedType ="";
        //Iterate through each key,value pair in the hash, and choose
        for (Map.Entry<String, String> entry : foundFolders.entrySet()) {
            String folderName = entry.getKey();
            String folderType = entry.getValue();
            if (selectedFolder.equals("")){
                selectedFolder = folderName;
                selectedType = folderType;
            }
            else {
                //If there is a folder with GA, choose it. If there are multiple, choose the newer
                if (folderType.equals("ga")){
                    if (!selectedType.equals("qa")){
                        selectedFolder = folderName;
                        selectedType = folderType;
                    }
                    else {
                        selectedFolder = chooseNewerFolder(selectedFolder, folderName);
                    }
                }
                else if (folderType.equals("cr")){
                    // if selected type is ga, do nothing
                    if (selectedType.equals("current")){
                        selectedFolder = folderName;
                        selectedType = folderType;
                    }
                    //If there are multiple folders with CR in the name, choose the newer.
                    else if (selectedType.equals("cr")){
                        selectedFolder = chooseNewerFolder(selectedFolder, folderName);
                    }
                }
                // if selected type is ga or cr, do nothing. Should never be multiple currents, but
                // if there is, choose the newer.
                else if (folderType.equals("current")){
                    if (selectedType.equals("current")){
                        selectedFolder = chooseNewerFolder(selectedFolder, folderName);
                    }
                }
            }
        }
        logger.info("Selected directory: " +selectedFolder +" as best directory to use for install");
        return selectedFolder;
    }

    /**
     * takes in two folders and will return the newer folder in a string format.
     * @param folder1
     * @param folder2
     * @return
     * @Author - sean williams
     */
    protected String chooseNewerFolder(String folder1, String folder2){
        File file1 = new File(folder1);
        File file2 = new File(folder2);
        Path path1 = file1.toPath();
        Path path2 = file2.toPath();
        BasicFileAttributes bfa1 = null;
        BasicFileAttributes bfa2 = null;

        try {
            //check the creation time of the folder, choose the one with the larger milisecond
            //timestamp
            bfa1 = Files.readAttributes(path1, BasicFileAttributes.class);
            bfa2 = Files.readAttributes(path2, BasicFileAttributes.class);
            long milli1 = bfa1.creationTime().to(TimeUnit.MILLISECONDS);
            long milli2 = bfa2.creationTime().to(TimeUnit.MILLISECONDS);

            if (milli1 > milli2) return folder1;
            else return folder2;
        } catch (IOException e){
            e.printStackTrace();
            //If we run into a problem, return an empty string.
            return "";
        }
    }


    /** transform the version given to us by the installer args to a format we can use to find the
     *  installers on fileshare.
     * @return: string
     * @Author - sean williams
     */
    protected String formatVersion( String version){
        // count the number of "."'s in the version string.
        int dotCount = version.length() - version.replace(".", "").length();

        //NMS needs the format in x.x or x.xx
        if(isNmsInstall()) {
            if(dotCount >1){
                //check if there are more than one '.' if yes find and remove the last one.
                int i = version.lastIndexOf(".0");
                version = new StringBuilder(version).replace(i , i+1,"").toString();
            }
            if (version.endsWith("0")) {
                version = version.substring(0, 3);
            }
            logger.info("\nformat version is: " + version);
            return version;
        }
        //UMP/UR needs the format to be x.x.x
        else {
            if (dotCount < 2){
                if (version.length() <4){
                    version = version.substring(0, 3) + ".0";
                }
                else version = version.substring(0, 3) + "." + version.substring(3);
            }
            logger.info("\nformat version is: " + version);
            return version;
        }

    }

    /**
     * checks to see if this is a BNPP install, if yes return true.
     * @return boolean
     * @Author - sean williams
     */
    private boolean isBnpp(){
        return this.bnpp.equals("bnpp");
    }

    /**
     * checks to see if this is an NMS install, if yes return true.
     * @return: boolean
     * @Author - sean williams
     */
    private boolean isNmsInstall(){
        return installType.toLowerCase().equals("nms");
    }

    /**
     * checks to see if this is an UMP install, if yes return true.
     * @return:  boolean
     * @Author - sean williams
     */
    private boolean isUmpInstall(){
        return installType.toLowerCase().equals("ump");
    }

    /**
     * checks to see if this is an UR install, if yes return true.
     * @return: boolean
     * @Author - sean williams
     */
    private boolean isUrInstall(){
        return installType.toLowerCase().equals("ur");
    }

    private boolean isSparcInstall(){
        return System.getProperty("os.arch").contains("sparc");
    }

    public String getFullDir() { return fullDir; }

    public String getInstaller() { return installer; }

    public String getInstallName() { return installName; }

    public String getInstallType() {
        return installType;
    }

    private String getFileShare() {
        if (OS.isWindows()) return windowsFileShare;
        else return linuxFileShare;
    }

    private String getMount() {
        if (OS.isWindows()) return windowsFileShare;
        else return drive;
    }

    public void setInstaller(String installer) { this.installer = installer; }

    /**@Author - sean williams
     * returns the filepath to the current.txt file.
     * Assumptions:
     *      - class variable: *FileShare is set correctly
     *      - class variable: buildFileDir is set correctly
     *      - class variable: version is set correctly.
     * @return: current.txt file path
     */
    @Deprecated
    private String getCurrent(){
        if (OS.isWindows()) return new File(windowsFileShare + buildFileDir + "/" + version + "/current.txt").getAbsolutePath();
        else return new File(linuxFileShare + buildFileDir + "/" + version + "/current.txt").getAbsolutePath();
    }

    @Deprecated
    public String setBuildFileDir(){
        if (this.bnpp.equals("bnpp") && installType.toLowerCase().equals("nms"))
            this.buildFileDir = "nmserver_bnpp";
        else if (!isPre80Version())
            this.buildFileDir = "uimserver";
        else if (isNmsInstall())
            this.buildFileDir = "NMS";
        return this.buildFileDir;
    }

    @Deprecated
    public void buildPathByType() throws FileNotFoundException {
        //version = version.substring(0,3) + ".0";

        if (installType.toLowerCase().equals("nms")) {
            //convert 8.30 to 8.3 because on fileshare the directory is 8.3 for nms
            if (version.endsWith("0")) {
                version = version.substring(0, 3);
                logger.info("\nbuildPathByType version is: " + version);
            }
            installer = buildNMSPath();
        }
        else if (installType.toLowerCase().equals("ump") || (installType.toLowerCase().equals("ur")) ) {
            int count = version.length() - version.replace(".", "").length();
            if(count == 1 ) {
                version = version.substring(0, 3) + "." + version.substring(3);
            }
            installer = buildUMPPath();
        }
        else
            throw new NullPointerException("Build date: " + build + " incorrectly formatted for your install type " + installType );
    }

    @Deprecated
    private String buildNMSPath() throws FileNotFoundException {
        setBuild();
        String majorDir = buildNMSMajorDir();
        logger.info("VERSION: " + version + " LATESTVERSION: " + LATESTVERSION);
        File fullPath = new File(drive + "/NimBUS-install/" + this.buildFileDir + "/" + version + "/" + majorDir + "/" + getOSPath() + getSubPath() + installName).getAbsoluteFile();
        fullDir = fullPath.toString();
        logger.info("NMS Full Path = " + fullDir);
        return fullDir;
    }

    @Deprecated
    private String buildNMSMajorDir() {
        String result;
        String prefix = isPre80Version() ? "nm" : "uim";
        if (!LATESTVERSION.equals(version) && !bnpp.equals("bnpp"))
            if(!version.equals("8.3")) result = prefix + "server_" + version.substring(0, 3) + "-GA";
            else result = prefix + "server_8.3-CR";
        else if (build.length() != 0) return build;
        else result = "current";

        return result;
    }

    @Deprecated
    private String buildUMPPath() {
        String majorDir = buildUMPMajorDir();
        logger.info("VERSION: " + version + " LATESTVERSION: " + LATESTUMPVERSION);
        String secondDir = (isPostVersion(8, 0)) ? version + "-A" : version + "-B";
        String path_prefix = drive + "/NimBUS-install/" + installType.toUpperCase() + "/" + version + "/" + majorDir + "/";
        String path_suffix = LATESTUMPVERSION.equals(version) ? installName : secondDir + "/" + installName;
        logger.info("UMP FULL PATH = " + path_prefix + path_suffix);

        fullDir = new File(path_prefix + path_suffix).getAbsolutePath();
        return fullDir;
    }

    @Deprecated
    private String buildUMPMajorDir() {
        if(!LATESTUMPVERSION.equals(version)) return "GA";
        else if(build.length() != 0) return build;
        else return "current";
    }

    @Deprecated
    private void setBuild() {
        String current_build = null;

        if(build.length() == 0 && (LATESTVERSION.equals(version) || LATESTUMPVERSION.equals(version))) {
            try {
                File version_file = getBuildFile();
                logger.info("Reading current dir from: " + version_file.getAbsolutePath());
                current_build = FileUtils.readLines(version_file).get(0);
                logger.info(current_build);
            } catch(IOException e) {
                logger.info("Cannot read from file: ", e);
                build = "";
            }

            build = (current_build != null) ? current_build : "";
        }
    }

    @Deprecated
    private File getBuildFile() {
        final String windows_path = new File("//fileshare.dev.fco/QA/NimBUS-install/" + buildFileDir + "/" + version + "/current.txt").getAbsolutePath();
        final String linux_solaris_path = new File("/mnt/vg_main/vol01/QA/NimBUS-install/" + buildFileDir + "/" + version + "/current.txt").getAbsolutePath();

        if(LATESTVERSION.equals(version)) {
            if(OS.isWindows()) {
                logger.info("Getting file: " + linux_solaris_path);
                return new File(windows_path);
            }
            else {
                try {
                    logger.info("Getting file: " + linux_solaris_path);
                    Sftp sftp = new Sftp(Install.getFileshare(), Install.getUser(), Install.getPassword());
                    sftp.connect();
                    sftp.sftpCmd(linux_solaris_path, "/tmp/current.txt");
                    return new File("/tmp/current.txt");
                } catch (JSchException e) {
                    logger.error("JSchException:", e);
                } catch (SftpException e) {
                    logger.info("SftpException: ", e);
                }
            }
        }
        return null;
    }

    protected boolean checkPackages(String folderPath){
        return new File(folderPath+packageZip).exists();
    }

    public boolean packagesExist(){
        return packages;
    }

    public String getPackageZip() {
        return packageZip;
    }

    public String installerDir(){
        return fullDir.replace(installName, "");
    }

    public String packagesPath(){
        return installerDir()+packageZip;
    }

    @Override
    public String toString() {
        return "InstallPaths{" +"\n" +
                "DRIVELETTERS=" + Arrays.toString(DRIVELETTERS) +"\n" +
                "LATESTVERSION='" + LATESTVERSION + '\'' + "\n" +
                "installer='" + installer + '\'' +"\n" +
                "installName='" + installName + '\'' +"\n" +
                "installType='" + installType + '\'' +"\n" +
                "version='" + version + '\'' +"\n" +
                "build='" + build + '\'' +"\n" +
                "drive='" + drive + '\'' +"\n" +
                "bnpp='" + bnpp + '\'' +"\n" +
                "customPath='" + customPath + '\'' +"\n" +
                "buildFileDir='" + buildFileDir + '\'' +"\n" +
                "localInstaller='" + localInstaller + '\'' +"\n" +
                "fullDir='" + fullDir + '\'' +"\n" +
                '}';
    }
}
