package com.nimsoft.automation.robot;

import com.nimsoft.automation.installer.Install;
import com.nimsoft.automation.nimbus.Discovery;
import com.nimsoft.automation.nimbus.DiscoveryAuthentication;
import com.nimsoft.automation.utils.Utils;
import com.nimsoft.automation.nimbus.NimAddress;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.nimbus.PDS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by hajbr03 on 11/17/14.
 *
 */

public class RobotDeploy
{
    static Logger logger = LoggerFactory.getLogger(RobotDeploy.class);

    private static final long DISCOVERY_WAIT_BASE = 10000;          // How long to wait for discovery to finish adding device no matter how many there are
    private static final long DISCOVERY_WAIT_MULTIPLIER = 1000;     // How many extra milliseconds to wait for each device being discovered
    private static final long DISCOVERY_WAIT_FREQUENCY = 2000;      // How many milliseconds to wait between failed queries to the database

    public RobotDeploy() { }

    /**
     * Discovers the specified targets and then deploys robots to them.
     *
     * @param nmsAddress  The Nimbus address of the primary hub.
     * @param hubAddress  Thie Nimbus address of the hub to deploy to
     * @param targets     The array of IP addresses to deploy robots to.
     * @param disAuth     The list of credentials to be used in discovery.
     * @param dbPassword The database password for the primary NMS installation
     * @return True if all of the targets had robots deployed to them successfully.
     * @throws NimException
     * @throws SQLException
     * @throws ClassNotFoundException
     * @throws IOException
     * @throws InterruptedException
     */
    public static boolean deploy(String nmsAddress, String hubAddress, String[] targets, ArrayList<DiscoveryAuthentication> disAuth,
                                 String dbPassword, String sid) throws NimException, InterruptedException, IOException, ClassNotFoundException, SQLException
    {
        // setup main variables
        NimAddress discoveryServerAddress = new NimAddress(nmsAddress);
        NimAddress discoveryAgentAddress = new NimAddress(nmsAddress);
        NimAddress nmsAdeAddress = new NimAddress(nmsAddress);
        NimAddress hubAdeAddress = new NimAddress(hubAddress);
        String hubIp = getIp(new NimAddress(hubAddress), sid);

        // configure discovery
        logger.info("Configuring Discovery");
        Discovery dis = new Discovery(discoveryServerAddress, discoveryAgentAddress, discoveryServerAddress, dbPassword, sid);

        for (String ip : targets) dis.addRange(ip);
        for (DiscoveryAuthentication auth : disAuth) dis.addCredentials(auth);

        // run discovery and wait for finish
        logger.info("Running Discovery");
        long startTime = System.currentTimeMillis();
        dis.beginDiscovery();
        dis.waitForFinish();

        // configure deployment
        logger.info("Configuring Deployment");
        AdeJob adeJob = new AdeJob(nmsAdeAddress, sid);
        adeJob.addRobotInfo("hub", hubIp, hubAdeAddress);
        boolean totalSuccess = addTargets(adeJob, dis, targets, startTime, "hub");

        // deploy and show results
        logger.info("Deploying Robots");
        adeJob.submit();
        adeJob.waitForFinish();
        if (adeJob.reportResults() && totalSuccess)
            logger.info("Deployment Finished Successfully");
        else {
            logger.warn("Deployment Finished with Errors");
            logger.warn("    ADE Job ID: " + adeJob.getId());
        }

        dis.cleanupScopesAndCreds();
        return adeJob.reportResults() && totalSuccess;
    }

    public static void deployHubs(NimAddress primary_hub, String sid, String[] targets, String version) {
        logger.info("Deploying Hubs");
        String jobId;

        for(String target : targets) {
            try {
                logger.info("Deploying Hub to " + target);
                NimAddress hub_addr = Utils.getAddressFromIP(target, sid);
                addStaticHub(primary_hub, hub_addr, target, sid);
                Utils.waitForProbeStart(hub_addr, sid, "controller", 120);

                PDS result = Utils.executeCallback(primary_hub, sid, "automated_deployment_engine", "deploy_probe", "hub", version,
                        hub_addr.toString(), null, null, "Hub Auto Install", "Automated install of hub " + version);
                jobId = result.getString("JobID");
                waitForFinish(primary_hub, jobId, sid);
                Utils.executeCallback(primary_hub, sid, "hub", "removerobot", hub_addr.robot);
            } catch(Exception e) {
                logger.error("Caught exception deploying hub: ", e);
            }
        }
    }

    private static void addStaticHub(NimAddress primary_hub, NimAddress hub_addr, String target, String sid) {
        try {
            String robotname = hub_addr.robot;
            String domain = primary_hub.domain;
            String hubname = hub_addr.robot;
            String hubip = target;

            Map<String, String> args = new LinkedHashMap<String, String>();
            args.put("active", "yes");
            args.put("name", hubname);
            args.put("ip", hubip);
            args.put("domain", domain);
            args.put("robotname", robotname);
            args.put("sync", "yes");

            for (String key : args.keySet())
                Utils.executeCallback(primary_hub, sid, "controller", "probe_config_set", "hub", "hublist/" + hub_addr.robot, key, args.get(key));

        } catch(Exception e) {
            Install.printStackTraceAndExit(e);
        }
    }

    private static boolean waitForFinish(NimAddress ade_address, String jobId, String sid) {
        while(true) {
            try {
                Thread.sleep(1000);
                PDS result = Utils.executeCallback(ade_address, sid, "automated_deployment_engine", "get_status", jobId);
                String status = result.getString("JobStatus").toLowerCase();
                if (!status.equals("running") && !status.equals("pending") && !status.equals("queued"))
                    return status.equals("Success");
            } catch(Exception e) {
                logger.error(e.getMessage(), e);
                return false;
            }
        }
    }

    /**
     * Adds all of the specified targets to the AdeJob using the Discovery class to acquire the data.
     *
     * @param adeJob      The AdeJob to add target specifications to.
     * @param dis         The Discovery class to use to query the database.
     * @param targets     The list of IP addresses of targets.
     * @param minTime     The data and time after which the systems should have been updated in the database.
     * @param robotInfoId The id of the hub information that should be used for the specified hosts.
     * @return True if all of the targets wer found in the database and added successfully.
     * @throws SQLException
     * @throws ClassNotFoundException
     * @throws InterruptedException
     */
    private static boolean addTargets(AdeJob adeJob, Discovery dis, String[] targets, long minTime, String robotInfoId) throws IOException, SQLException, ClassNotFoundException, InterruptedException
    {
        HashMap<Integer, HashMap<String, String>> maps = null;
        long endTime = System.currentTimeMillis() + targets.length * DISCOVERY_WAIT_MULTIPLIER + DISCOVERY_WAIT_BASE;
        while (System.currentTimeMillis() <= endTime)
        {
            maps = dis.getDeviceInfo(targets, minTime);
            if (maps.size() >= targets.length)
                break;
            Thread.sleep(DISCOVERY_WAIT_FREQUENCY);
            if(System.currentTimeMillis() > endTime)
                logger.error("Error, query timeout, returning null set");
        }
        boolean succeeded = true;
        if (maps == null || maps.keySet().size() < 1)
            throw new RuntimeException("Could not acquire any device information from database");
        for (int i = 0; i < targets.length; ++i)
        {
            HashMap<String, String> device = maps.get(i);
            logger.trace("Working on device: " + device.toString());

            // handle profile
            if (device.get("os_type") == null)
            {
                logger.error("    Could not retrieve os_type for host: " + device.get("ip"));
                succeeded = false;
                continue;
            }
            String profile = device.get("os_type");
            if (profile.equalsIgnoreCase("UNIX"))
                profile = device.get("os_name");
            if (profile.equalsIgnoreCase("Linux"))
                profile = device.get("linux_dist_name");

            // handle authentication
            String credId = null;
            if (device.get("shell_profile") != null)
            {
                credId = "shell" + device.get("shell_profile");
                HashMap<String, String> creds = dis.getCredentials(DiscoveryAuthentication.Type.shell, Integer.parseInt(device.get("shell_profile")));
                if (creds == null)
                {
                    logger.error("    Could not match authentication profile for host: " + device.get("ip"));
                    succeeded = false;
                    continue;
                }
                adeJob.addAuthentication(creds.get("user_name"), creds.get("password"), credId, true);
            }
            if (device.get("wmi_profile") != null)
            {
                credId = "wmi" + device.get("wmi_profile");
                HashMap<String, String> creds = dis.getCredentials(DiscoveryAuthentication.Type.wmi, Integer.parseInt(device.get("wmi_profile")));
                if (creds == null)
                {
                    logger.error("    Could not match authentication profile for host: " + device.get("ip"));
                    succeeded = false;
                    continue;
                }
                adeJob.addAuthentication(creds.get("user_name"), creds.get("password"), credId, true);
            }
            if (credId == null)
            {
                logger.error("    Could not match authentication profile for host: " + device.get("ip"));
                succeeded = false;
                continue;
            }

            // add the host
            adeJob.addHostProfile(profile, device.get("processor_type").substring(4), device.get("dns_name"), device.get("ip"), credId, robotInfoId);
        }
        return succeeded;
    }

    /**
     * Gets the IP address of the specified Nimbus address.
     *
     * @param address The Nimbus address.
     * @return The IP address.
     * @throws NimException
     */
    private static String getIp(NimAddress address, String sid) {
        try {
            return Utils.executeCallback(address, sid, "controller", "get_info").getString("robotip");
        } catch(Exception e) {
            logger.error(e.getMessage(), e);
            return "";
        }
    }
}

