package com.nimsoft.automation.database;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import java.util.Date;

/**
 * Created by lisdu02 on 1/30/14.
 *
 */
public class DBOperations {
    static Logger logger = LoggerFactory.getLogger(DBOperations.class);

    public void dropDb(DBConnection connection) throws SQLException, InterruptedException {
        if (connection == null)
            throw new IllegalArgumentException("connection cannot be null!");

        Statement statement = connection.getConnection().createStatement();
        if (connection.getDbInfo().getDbType().toLowerCase().equals("oracle")) {
            System.out.println("dropping oracle");
            logger.info("Closing all sessions for user before dropping tablespace and/or user");
            closeConnections(connection, connection.getDbName());
            Thread.sleep(10000);

            String databaseUser = connection.getDbInfo().getDbUsername();
            String databaseName = connection.getDbInfo().getDbName();

            //broke up the Oracle drop into two try catch blocks to protect against a sql exception
            //from either missing when the other is not.
            try{
                statement.executeUpdate("DROP TABLESPACE " + databaseName + " INCLUDING CONTENTS AND DATAFILES");
            } catch (SQLException e){
                logger.error("Could not drop tablespace: " + databaseName + " Does it exist?");
                logger.error(e.getMessage());
            }
            try{
                statement.executeUpdate("DROP USER " + databaseUser + " CASCADE");
            } catch (SQLException e){
                logger.error("Could not drop user: " + databaseUser +" Does it exist?");
                logger.error(e.getMessage());
            }
        } else if (connection.getDbInfo().getDbType().toLowerCase().equals("mssql")) {
            statement.executeUpdate("USE master");
            statement.executeUpdate("ALTER DATABASE " + connection.getDbInfo().getDbName() + " SET SINGLE_USER WITH ROLLBACK IMMEDIATE");
            statement.executeUpdate("DROP DATABASE " + connection.getDbInfo().getDbName());
        } else {
            statement.executeUpdate("DROP DATABASE " + connection.getDbInfo().getDbName());
        }

        statement.close();
    }

    public ResultSet insert(DBConnection connection, String table, Map<String,String> values) throws SQLException, IOException {
        return insert(connection, table, values, null);
    }

    public ResultSet insert(DBConnection connection, String table, Map<String,String> values, String[] resultColumns) throws SQLException, IOException {
        Map<String, String> columnType;
        StringBuilder sqlStatement = new StringBuilder("");
        int numCol = 0;

        if (connection == null)
            throw new IllegalArgumentException("connection cannot be null!");

        Statement statement = connection.getConnection().createStatement();
        //Calling to see what is the correct columns and types

        columnType = getTableColumnInfo(connection, table);

        //building a string array that is dynamic based on the values array passed in for the use in the prepare statement
        sqlStatement.append("INSERT INTO ");
        if (connection.getDbInfo().getDbType().toLowerCase().equals("oracle") || connection.getDbInfo().getDbType().toLowerCase().equals("mysql")) {
            sqlStatement.append(connection.getDbName());
            sqlStatement.append(".");
        }
        sqlStatement.append(table);
        sqlStatement.append(" ( ");
        Iterator ittr = values.entrySet().iterator();
        while(ittr.hasNext ()) {
            Map.Entry pairs = (Map.Entry)ittr.next();
            sqlStatement.append(pairs.getKey());
            if(ittr.hasNext())
                sqlStatement.append(", ");
            numCol++;
        }
        sqlStatement.append(" ) VALUES ( ");
        int x = 0;
        while (x < numCol) {
            //if last dont append ,
            x++;
            if (x == numCol) {
                sqlStatement.append("?");
            } else {
                sqlStatement.append("?, ");
            }
        }
        sqlStatement.append(" )");
        logger.trace("Insert prepared statement command: " + sqlStatement.toString());

        //now creating array with appropriate types casted for string values passed in
        PreparedStatement preparedStatement;
        if (resultColumns == null || resultColumns.length < 1)
            preparedStatement = connection.getConnection().prepareStatement(sqlStatement.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
        else
            preparedStatement = connection.getConnection().prepareStatement(sqlStatement.toString(), resultColumns);
        int colPosition = 0;
        for (String key : values.keySet()) {
            colPosition++;
            for (String colKey: columnType.keySet()) {
                if (key.toLowerCase().equals(colKey.toLowerCase())) {
                    if (columnType.get(colKey).toLowerCase().contains("int") || columnType.get(colKey).toLowerCase().contains("number") || columnType.get(colKey).toLowerCase().contains("bit")) {
                        logger.trace("INT Col:" + colPosition);
                        //its a number add to prepare statement
                        preparedStatement.setInt(colPosition, Integer.parseInt(values.get(key)));
                    } else if (columnType.get(colKey).toLowerCase().contains("varchar")) {
                        logger.trace("VAR Col:" + colPosition);
                        //its a string add to prepare statement
                        preparedStatement.setString(colPosition,values.get(key));
                    } else if (columnType.get(colKey).toLowerCase().contains("time") || columnType.get(colKey).toLowerCase().contains("date")) {
                        //its a date time stamp add to prepare statement
                        logger.trace("DATE Col:" + colPosition);
                        Date date = new Date();
                        preparedStatement.setTimestamp(colPosition, new Timestamp(date.getTime()));
                    } else {
                        //dont currently have a correct datatype, throwing error
                        throw new IOException("There is no data type currently coded, cannot continue to insert data");
                    }
                }
            }
        }
        logger.trace("Prepared Statement for insert command: " + preparedStatement);
        //oracle insert

        if (connection.getDbInfo().getDbType().toLowerCase().equals("mssql"))
            statement.executeUpdate("USE " + connection.getDbName());

        preparedStatement.executeUpdate();
        ResultSet rs = preparedStatement.getGeneratedKeys();

        statement.close();
        return rs;
    }

    /**
     * Gets a map of column names and data types
     * @param connection - current database connection
     * @param table - tablename to get column info from
     * @return - Map<column_name, column_data_type>
     */
    public Map<String, String> getTableColumnInfo(DBConnection connection, String table) throws SQLException {
        ResultSet rs;
        Map<String, String> columnType = new HashMap<String, String>();
        if (connection == null)
            throw new IllegalArgumentException("connection cannot be null!");

        Statement statement = connection.getConnection().createStatement();

        if (connection.getDbInfo().getDbType().toLowerCase().equals("oracle")) {
            logger.trace("select COLUMN_NAME, DATA_TYPE from all_tab_columns where table_name = '" + table.toUpperCase() + "'");
            rs = statement.executeQuery("select COLUMN_NAME, DATA_TYPE from all_tab_columns where table_name = '" + table.toUpperCase() + "'");
        }
        else if (connection.getDbInfo().getDbType().toLowerCase().equals("mssql")) {
            // MSSQL get data types
            statement.execute("USE " + connection.getDbName());
            rs = statement.executeQuery("SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '" + table + "';");
        } else {
            // MySql
            rs = statement.executeQuery("SHOW COLUMNS FROM " + connection.getDbName() + "." + table + ";");
        }
        //creating a map of the first to column name and type into a map to be returned to called
        while (rs.next()) {
            columnType.put(rs.getString(1), rs.getString(2));
        }

        statement.close();
        return columnType;
    }


    public ResultSet selectStatement(DBConnection connection, ArrayList<String> selectColumns, String table) throws SQLException {
        //usage pass in selectColumns for all you want to query ie col1, col2, col66 or just pass * if you want it all
        // where clause is currently not implemented
        String db_type = connection.getDbInfo().getDbType().toLowerCase();
        StringBuilder sqlStatement = new StringBuilder("");
        if (connection == null)
            throw new IllegalArgumentException("connection cannot be null!");

        Statement statement = connection.getConnection().createStatement();
        //building the select command
        sqlStatement.append("SELECT ");
        for (String col: selectColumns) {
            sqlStatement.append(col);
            if(db_type.equals("oracle")) sqlStatement.append(" as \"" + col.toLowerCase() + "\"");
            if (!col.equals(selectColumns.get(selectColumns.size() -1))) {
                sqlStatement.append(", ");
            }
        }
        sqlStatement.append(" FROM ");
        if (db_type.equals("oracle") || db_type.equals("mysql")) {
            sqlStatement.append(connection.getDbName());
            sqlStatement.append(".");
        }
        sqlStatement.append(table);

        if (db_type.equals("mssql")) {
            logger.trace("Using database: " + connection.getDbName());
            statement.execute("USE " + connection.getDbName());
        }

        return statement.executeQuery(sqlStatement.toString());
    }

    public boolean dbExists(DBConnection connection) throws SQLException {
        if (connection == null)
            throw new IllegalArgumentException("connection cannot be null!");

        ResultSet resultSet;
        if (connection.getDbInfo().getDbType().toLowerCase().equals("oracle")) {
            Statement statement = connection.getConnection().createStatement();
            resultSet = statement.executeQuery("SELECT TABLESPACE_NAME FROM dba_tablespaces");
            while (resultSet.next()) {
                String name = resultSet.getString("TABLESPACE_NAME");
                if (name != null && name.toLowerCase().equals(connection.getDbName().toLowerCase())) {
                    resultSet.close();
                    return true;
                }
            }
            if (checkIfOracleUserExists(connection)) {
                return true;
            }
        } else {
            resultSet = connection.getConnection().getMetaData().getCatalogs();
            while (resultSet.next()) {
                if (connection.getDbName().toLowerCase().equals(resultSet.getString(1).toLowerCase())) {
                    resultSet.close();
                    return true;
                }
            }
        }

        resultSet.close();
        return false;
    }

    public boolean checkIfOracleUserExists(DBConnection connection) throws SQLException {
        Statement statement = connection.getConnection().createStatement();
        ResultSet resultSet1 = statement.executeQuery("select distinct username from dba_users");
        while (resultSet1.next()){
            String user = resultSet1.getString(1);
            if (user != null && user.toLowerCase().equals(connection.getDbUser().toLowerCase())){
                resultSet1.close();
                return true;
            }
        }
        return false;
    }

    public void closeOracleSessions(DBConnection connection) throws SQLException, InterruptedException {

        String databaseUser = connection.getDbInfo().getDbUsername();

        String dropQuery =
            "begin for x in (select Sid, Serial#, machine, program from v$session where username = upper('"+databaseUser+"')) \n" +
            "    loop \n" +
            "        execute immediate 'Alter System Kill Session '''|| x.Sid || ',' || x.Serial# || ''' IMMEDIATE'; \n" +
            "    end loop;\n" +
            "end;\n";

        try{
            logger.info("Beginning drop of sessions for Oracle user " + databaseUser);
            CallableStatement statement = connection.getConnection().prepareCall(dropQuery);
            statement.execute();
            statement.close();
            logger.info("Finished dropping sessions for " + databaseUser);
        } catch (SQLException e){
            logger.error(e.getMessage());
        }
    }

    public void closeConnectionOracle(DBConnection connection) throws SQLException, InterruptedException {
        int retries = 3;
        while(checkIfOracleUserExists(connection) && retries > 0) {
            closeOracleSessions(connection);
            retries --;
        }
    }

    // Right now only being used to close oracle and sql server connections before dropping
    public void closeConnections(DBConnection connection, String dbName) throws SQLException, InterruptedException {
        if (connection == null || dbName == null)
            throw new IllegalArgumentException("connection cannot be null!");

        if (connection.getDbInfo().getDbType().toLowerCase().equals("mssql")) {
            Statement statement = connection.getConnection().createStatement();
            ResultSet result = statement.executeQuery("EXEC sp_who2");
            while (result.next()) {
                String currDb = result.getString("DBName");
                String spid = result.getString("SPID");
                if (currDb != null && currDb.toLowerCase().equals(dbName.toLowerCase())) {
                    logger.info("dbName="+dbName + "spid="+spid);
                    statement.executeUpdate("KILL " + spid);
                }
            }
            result.close();
        }
        else if (connection.getDbInfo().getDbType().toLowerCase().equals("oracle")){
            closeConnectionOracle(connection);
        }
    }
}
