package com.nimsoft.automation.utils;

/**
 * Created by dustinlish on 1/19/14.
 *
 */
public class OS {

    private static String OS = System.getProperty("os.name").toLowerCase();

    private OS() {}

    public static String getOs() throws UnsupportedOSException {
        if (isWindows())
            return "Windows";
        else if (isUnix())
            return "Linux";
        else if (isSolaris())
            return "Solaris";
        else if (isMac())
            return "Mac";
        else
            throw new UnsupportedOSException("OS is not supported");
    }

    public static boolean isWindows() {
        return (OS.contains("win"));
    }

    public static boolean isUnix() {
        return (OS.contains("nix") || OS.contains("nux") || OS.indexOf("aix") > 0 );
    }

    public static boolean isSolaris() {
        return (OS.contains("sunos"));
    }

    // Added for mac development only
    // Test should fail if running against mac because mac is not supported
    public static boolean isMac() {
        return (OS.contains("mac"));
    }

}
