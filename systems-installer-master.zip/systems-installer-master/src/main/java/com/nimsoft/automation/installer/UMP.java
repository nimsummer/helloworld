package com.nimsoft.automation.installer;

import com.nimsoft.automation.utils.Props;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileNotFoundException;
import java.net.Inet4Address;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Created by dustinlish on 2/2/14.
 */
public class UMP implements NimsoftInstall {

    private static final Pattern DOTS = Pattern.compile("\\.");
    static Logger logger = LoggerFactory.getLogger(NMS.class);

    private Props prop;

    public UMP(String install, String ip) {
        this.prop = new Props(install, ip);
    }

    public void loadProps(Map<String, String> opts, String properties) throws FileNotFoundException, UnknownHostException {
        if (opts == null)
            throw new IllegalArgumentException("Cannot pass null parameter");
        if (properties == null || properties.isEmpty())
            logger.info("No custom properties passed");

        String nimbusAddress = "/" + opts.get("NMSDOMAIN") + "/" + opts.get("NMSHUB") + "/" + opts.get("NMSROBOT");
        Map<String, String> umpOpts = new HashMap<String, String>();
        umpOpts.put("NIMBUS_USERNAME", opts.get("NIMBUS_USERNAME"));
        umpOpts.put("NIMBUS_PASSWORD", opts.get("NIMBUS_PASSWORD"));
        umpOpts.put("HUB_ROBOT_IP",    opts.get("ip"));
        umpOpts.put("UMP_ROBOT_IP",    opts.get("ip"));

        prop.setUserDir();
        prop.loadCustomPropertiesFromMap(umpOpts);
        prop.loadCustomPropertiesFromMap(opts);
        prop.searchAndReplaceProp("<NIMBUS_ADDRESS>", nimbusAddress);

        if (opts.containsKey("UMP_ROBOT")) {
            prop.setProp("UMP_ROBOT_IP", opts.get("UMP_ROBOT_IP"));
            prop.setProp("UMP_ROBOT", "/" + opts.get("NMSDOMAIN") + "/" + opts.get("NMSHUB") + "/" + opts.get("UMP_ROBOT"));
        }

        String ip;
        if(prop.getIp().toLowerCase().contains("auto")) {
            ip = Inet4Address.getLocalHost().getHostAddress();
            umpOpts.put("HUB_ROBOT_IP", ip);
            umpOpts.put("UMP_ROBOT_IP", ip);
        }

        if (properties != null && !properties.isEmpty())
            prop.loadCustomProperties(opts.get("properties"));
    }

    public String getPropertiesFile() {
        return prop.getPropertiesFile();
    }

    public void listProps() {
        prop.listProps();
    }

    public String getProp(String key) {
        if (prop.getProp().containsKey(key))
            return prop.getProp().get(key).toString();
        else
            return null;
    }

    public Props getProp() {
        return prop;
    }
}
