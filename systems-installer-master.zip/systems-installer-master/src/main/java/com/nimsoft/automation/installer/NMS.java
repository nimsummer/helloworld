package com.nimsoft.automation.installer;

import com.nimsoft.automation.utils.OS;
import com.nimsoft.automation.utils.Props;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by dustinlish on 2/2/14.
 *
 */
public class NMS implements NimsoftInstall {

    private static final Pattern DOTS = Pattern.compile("\\.");
    static Logger logger = LoggerFactory.getLogger(NMS.class);

    private final Props prop;
    private final String install;

    public NMS(String install, String ip, String db_type, String version) {
        this.install = install;
        this.prop = new Props(install, ip, db_type, version);
    }

    public void loadProps(Map<String, String> opts, String properties) throws FileNotFoundException, UnknownHostException {
        if (opts == null)
            throw new IllegalArgumentException("Cannot pass null parameter");
        if (properties == null || properties.isEmpty())
            logger.info("No custom properties passed");

        Map<String, String> defaults = new HashMap<String, String>();
        String ip = (prop.getIp().equals("auto")) ? findIP() : prop.getIp();
        String network_ip = ip;
        ip = DOTS.matcher(ip).replaceAll("_");

        // Generate default properties first for required properties
        defaults.put("NMSDOMAIN", ip + "_domain");
        defaults.put("NMSHUB", ip + "_hub");
        defaults.put("NMSNETWORKIP", network_ip);
        defaults.put("NIMDBNAME", "auto_" + ip);
        if (prop.getDb().toLowerCase().equals("oracle")) {
            if(prop.getVersion() >=8.3 && !(opts.containsKey("DB_VERSION"))){
                prop.setProp("DB_VERSION", "oracle_11");
            }
            defaults.put("NIMDB_USER", "auto_" + ip);
            defaults.put("DB_ADMIN_USER", "auto_" + ip);
        }
        defaults.put("DB_ORACLE_INSTANTCLIENT_DIR", findOracleInstantClientDir());

        // Set user directory property based on OS type
        // Next load default db properties
        // Load the default values
        prop.setUserDir();
        if(opts.containsKey("DB_VERSION")){
            if(opts.get("DB_VERSION").toLowerCase().equals("oracle_12")) {
                prop.loadDBProperties("oracle_12");
            }
        }else prop.loadDBProperties(prop.getDb());
        prop.loadCustomPropertiesFromMap(defaults);


        // Hack - didn't want to have two options for password, so keeping UMP property
        //        name but need to translate to NMS property name if specified
        if (opts.containsKey("NIMBUS_PASSWORD"))
            opts.put("NMS_PASSWORD", opts.get("NIMBUS_PASSWORD"));

        // Load any user specified properties from the command line
        prop.loadCustomPropertiesFromMap(opts);

        // Finally, load anything from a user specified properties file
        if (properties != null && !properties.isEmpty())
            prop.loadCustomProperties(opts.get("properties"));

        prop.saveProps();
    }

    private String findOracleInstantClientDir() {
        String ora11_win = "C:\\oracle\\instantclient_11_2";
        String ora12_win = "C:\\oracle\\instantclient_12_1";
        String ora11_lin  = "/opt/oracle/instantclient_11_2";
        String ora12_lin = "/opt/oracle/instantclient_12_1";
        File ora11;

        if(OS.isWindows()) {
            ora11 = new File(ora11_win + "\\oci.dll");
            return ora11.exists() ? ora11_win : ora12_win;
        } else {
            ora11 = new File(ora11_lin + "/libociei.so");
            return ora11.exists() ? ora11_lin : ora12_lin;
        }
    }

    public String getPropertiesFile() {
        return prop.getPropertiesFile();
    }

    public void listProps() {
        prop.listProps();
    }

    public String getProp(String key) {
        if (prop.getProp().containsKey(key))
            return prop.getProp().get(key).toString();
        else
            return null;
    }

    public Props getProp() {
        return prop;
    }

    public String getInstall() {
        return install;
    }

    /**
     *
     * @return string a non loopback ipadress.
     */
    protected String findIP(){
        try {
            //Get list of network interfaces
            Enumeration e = NetworkInterface.getNetworkInterfaces();
            while(e.hasMoreElements()){
                NetworkInterface n = (NetworkInterface) e.nextElement();
                Enumeration ee = n.getInetAddresses();
                //for each network interface find the ip's associated with it
                while (ee.hasMoreElements()){
                    InetAddress i = (InetAddress) ee.nextElement();
                    // If it is an IPv4 and not a loopback, use it.
                    if( i instanceof Inet4Address && !i.isLoopbackAddress()){
                        return i.getHostAddress();
                    }
                }
            }
        } catch (Exception e){
            logger.error("Could not find ip for system");
            e.printStackTrace();
            return "";
        }
        return "";
    }

}
