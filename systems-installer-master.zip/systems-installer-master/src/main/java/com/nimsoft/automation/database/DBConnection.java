package com.nimsoft.automation.database;

import com.nimsoft.automation.utils.LibraryModule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Created by lisdu02 on 1/30/14.
 *
 */
public class DBConnection {

    static Logger logger = LoggerFactory.getLogger(DBConnection.class);

    private final DBConnectionInfo connectionInfo;
    private Connection connection;

    public DBConnection(DBConnectionInfo connectionInfo) {
        this.connectionInfo = connectionInfo;
    }

    public void connect() throws ClassNotFoundException, SQLException, IOException {
        if(connectionInfo.isWindowsAuthentication()) {
            LibraryModule.MSSQL_WIN_AUTH.loadLibrary();
        }
        Class.forName(connectionInfo.getDatabaseDriverClass());
        String user_name = getDbType().toLowerCase().equals("oracle") ? "SYS AS SYSDBA" :  connectionInfo.getDbUsername();

        //I feel really dirty implementing oracle 12 this way, but dam this code does not make it easy.
        // If Oracle try connecting with a SID first. if that fails try connecting with service name
        if(getDbType().toLowerCase().equals("oracle")){
            try{
                connection = DriverManager.getConnection(connectionInfo.getConnectionURL(), user_name, connectionInfo.getDbPassword());
            }catch(SQLException e){
                try {

                    logger.info("Connecting with SID style connection string Failed, trying again with service name style");
                    connectionInfo.setOracle12(true);
                    connection = DriverManager.getConnection(connectionInfo.getConnectionURL(), user_name, connectionInfo.getDbPassword());
                    logger.info("Connecting with service name style connection string succeeded");
                }catch(SQLException x){
                    throw x;
                }
            }

        }
        else connection = DriverManager.getConnection(connectionInfo.getConnectionURL(), user_name, connectionInfo.getDbPassword());
    }

    public void disconnect() throws SQLException { connection.close(); }

    public Connection getConnection() {
        return connection;
    }

    public String getDbName() {
        return connectionInfo.getDbName();
    }

    public DBConnectionInfo getDbInfo() {
        return connectionInfo;
    }

    public String getDbUser() {
        return connectionInfo.getDbUsername();
    }

    public String getDbType() {
        return connectionInfo.getDbType();
    }

    public String getConnectionUrl() throws IOException {
        return connectionInfo.getConnectionURL();
    }

    public void setDbUserOnly() {
        connectionInfo.setDbUserOnly(true);
    }

    public boolean getDbUserOnly() {
        return connectionInfo.getDbUserOnly();
    }

}
