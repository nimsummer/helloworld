package com.nimsoft.automation.nimbus;

import com.nimsoft.automation.utils.OS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Created by dustinlish on 2/3/14.
 *
 */
public class NimInfo {
    static Logger logger = LoggerFactory.getLogger(NimInfo.class);

    private static String nimDir = null;
    private static String probeUtility = null;
    private static final String[] DEFAULT_NIM_DIRECTORIES = {
        "c:/Program Files/Nimsoft",
        "c:/Program Files (x86)/Nimsoft",
        "/opt/nimsoft"
    };

    // get desktop path
    public static String getDesktopPath() {
        if (OS.isWindows())
            return "c:\\Users\\Administrator\\Desktop";
        else
            return "/root/Desktop";
    }

    public static String getNimDir() throws FileNotFoundException {
        if (nimDir == null)
            setNimDir();
        return nimDir;
    }

    public static String getProbeUtility() throws FileNotFoundException {
        if (probeUtility == null)
            setProbeUtility();
        return probeUtility;
    }

    private static void setNimDir() throws FileNotFoundException {
        for (String dir : DEFAULT_NIM_DIRECTORIES) {
            File f = new File(dir);
            if (f.exists()) {
                nimDir = dir;
                break;
            }
        }

        if (nimDir.isEmpty()) {
            throw new FileNotFoundException("Could not find nimsoft directory");
        }
    }

    // find probe utility
    private static void setProbeUtility() throws FileNotFoundException {
        String pu;
        if (OS.isWindows())
            pu = getNimDir() + "/bin/pu.exe";
        else
            pu = getNimDir() + "/bin/pu";
        logger.info("PU=["+pu+"]");

        File f = new File(pu);
        if (f.getAbsoluteFile().exists()) {
            logger.info("Probe Utility Exists");
            probeUtility=pu;
        } else {
            logger.info("PROBEUTIL= [" + probeUtility +"]");
            throw new FileNotFoundException("Could not find probe utility");
        }
    }
}
