package com.nimsoft.automation.nimbus;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by cullen on 5/7/14.
 *
 */
public class DiscoveryAuthentication {

    static Logger logger = LoggerFactory.getLogger(DiscoveryAuthentication.class);

    /**
     * The different kinds of authentication.
     */
    public enum Type {
        shell("shell"),
        snmp("snmp"),
        wmi("wmi");

        public final String name;
        Type(String name) {
            this.name = name;
        }
        public String toString() {
            return name;
        }
    };

    public final Type type;
    public final String user, password;
    public int id;

    public DiscoveryAuthentication(Type credType, String user, String password) {
        this.type = credType;
        this.user = user;
        this.password = password;
        id = -1;
    }
}
