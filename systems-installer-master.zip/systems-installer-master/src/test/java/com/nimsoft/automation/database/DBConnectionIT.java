package com.nimsoft.automation.database;

import org.junit.After;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import static org.junit.Assert.*;

/**
 * Created by lisdu02 on 1/30/14.
 */
@RunWith(Enclosed.class)
public class DBConnectionIT {

    private static final String TEST_USER = "TESTUSER";
    private static final String TEST_DATA_FILE = "installer_test_dl.dbf";

    public static void createDb(DBConnectionInfo info) {
        String connectionUrl;
        Statement statement;
        Connection conn;
        try {
            if (info.getDbType().toLowerCase().equals("oracle")) {
                connectionUrl = info.getJdbcUrl() + info.getDbServer() + ":" + info.getDbPort() + ":" + info.getOracleSID();
                conn = DriverManager.getConnection(connectionUrl, "SYS AS SYSDBA", info.getDbPassword());
                statement = conn.createStatement();

                statement.executeUpdate("CREATE TABLESPACE " + info.getDbName() + " DATAFILE '" + info.getDbName()+".dbf" + "' size 100m autoextend on next 100m maxsize 1000m");
                statement.executeUpdate("CREATE USER " + TEST_USER + " IDENTIFIED BY t3sti9 DEFAULT TABLESPACE " + info.getDbName());
                statement.executeUpdate("grant all privileges to " + TEST_USER);
            } else {
                connectionUrl = info.getJdbcUrl() + info.getDbServer() + ":" + info.getDbPort();
                conn = DriverManager.getConnection(connectionUrl, info.getDbUsername(), info.getDbPassword());
                statement = conn.createStatement();
                statement.executeUpdate("CREATE DATABASE " + info.getDbName());
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void dropDb(DBConnectionInfo info) {
        String connectionUrl;
        Statement statement;
        Connection conn;
        try {
            if (info.getDbType().toLowerCase().equals("oracle")) {
                connectionUrl = info.getJdbcUrl() + info.getDbServer() + ":" + info.getDbPort() + ":" + info.getOracleSID();
                conn = DriverManager.getConnection(connectionUrl, "SYS AS SYSDBA", info.getDbPassword());
                statement = conn.createStatement();

                statement.executeUpdate("DROP TABLESPACE " + info.getDbName() + " INCLUDING CONTENTS AND DATAFILES");
                statement.executeUpdate("DROP USER " + TEST_USER + " CASCADE");
            } else {
                connectionUrl = info.getJdbcUrl() + info.getDbServer() + ":" + info.getDbPort();
                conn = DriverManager.getConnection(connectionUrl, info.getDbUsername(), info.getDbPassword());
                statement = conn.createStatement();
                statement.executeUpdate("DROP DATABASE " + info.getDbName());
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static class Connect_To_Db {
        private DBConnection connection;
        private DBConnection connection2;
        private DBConnectionInfo connectionInfo;

        private String dbType;
        private String dbUsername;
        private String dbPassword;
        private String dbServer;
        private String dbName;
        private String dbPort;

        @Rule
        public ExpectedException expectedException = ExpectedException.none();

        @After
        public void tearDown() throws SQLException {
            //if (connection.getConnection() != null)
            //    connection.disconnect();
        }

        @Test
        public void mysql_connection_should_connect() throws IOException {
            dbType = "mysql";
            dbServer = "10.238.3.61";
            dbName = "InstallerTestDb";
            dbUsername = "root";
            dbPassword = "t3sti9";
            dbPort = "3306";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            createDb(connectionInfo);

            try {
                connection.connect();
                assertTrue("Connection to MySQL database should succeed with params: " + connectionInfo.toString(), true);
            } catch (Exception e) {
                e.printStackTrace();
                assertTrue("Connection to MySQL database should succeed with params: " + connectionInfo.toString() + "\nURL: " + connectionInfo.getConnectionURL(), false);
            }

            dropDb(connectionInfo);
        }

        @Test
        public void mssql_connection_should_connect() throws IOException {
            dbType = "mssql";
            dbServer = "10.238.0.180";
            dbName = "InstallerTestDb";
            dbUsername = "sa";
            dbPassword = "t3sti9";
            dbPort = "1433";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            createDb(connectionInfo);

            try {
                connection.connect();
                assertTrue("Connection to MySQL database should succeed with params: " + connectionInfo.toString(), true);
            } catch (Exception e) {
                e.printStackTrace();
                assertTrue("Connection to MySQL database should succeed with params: " + connectionInfo.toString() + "\nURL: " + connectionInfo.getConnectionURL(), false);
            }


            dropDb(connectionInfo);
        }

        @Test
        public void oracle_drop_db_bad() throws SQLException, ClassNotFoundException, IOException {
            dbType = "oracle";
            dbServer = "10.238.3.60";
            dbName = "AUTO_10_238_2_TEST";
            dbUsername = "SYS AS SYSDBA";
            dbPassword = "t3sti9";
            dbPort = "1521";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connectionInfo.setOracleSID("ORCLAUTO");
            connection = new DBConnection(connectionInfo);
            connection.connect();
            connection2 = new DBConnection(connectionInfo);
            connection2.connect();
            createDb(connectionInfo);
            dropDb(connectionInfo);

            try {
                connection.connect();
                assertTrue("Connection to Oracle database should succeed with params: " + connectionInfo.toString(), true);
            } catch (Exception e) {
                e.printStackTrace();
                assertTrue("Connection to Oracle database should succeed with params: " + connectionInfo.toString() + "\nURL: " + connectionInfo.getConnectionURL(), false);
            }
        }


        @Test
        public void oracle_connection_should_connect() throws IOException {
            dbType = "oracle";
            dbServer = "10.238.3.60";
            dbName = "InstallerTestDb";
            dbUsername = "SYS AS SYSDBA";
            dbPassword = "t3sti9";
            dbPort = "1521";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connectionInfo.setOracleSID("ORCLAUTO");
            connection = new DBConnection(connectionInfo);

            try {
                connection.connect();
                assertTrue("Connection to Oracle database should succeed with params: " + connectionInfo.toString(), true);
            } catch (Exception e) {
                e.printStackTrace();
                assertTrue("Connection to Oracle database should succeed with params: " + connectionInfo.toString() + "\nURL: " + connectionInfo.getConnectionURL(), false);
            }
        }

        @Test
        public void oracle_connection_sid_test() throws SQLException, IOException {
            dbType = "oracle";
            dbServer = "10.238.3.60";
            dbName = "InstallerTestDb";
            dbUsername = "SYS AS SYSDBA";
            dbPassword = "t3sti9";
            dbPort = "1521";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connectionInfo.setOracleSID("ORCLAUTO");
            DBConnection conn = new DBConnection(connectionInfo);

            try {
                conn.connect();
                System.out.println(conn.getConnectionUrl());
                assertTrue("Connection to Oracle database should succeed with params: " + connectionInfo.toString(), true);
            } catch (Exception e) {
                e.printStackTrace();
                assertTrue("Connection to Oracle database should succeed with params: " + connectionInfo.toString() + "\nURL: " + connectionInfo.getConnectionURL(), false);
            }
        }
    }

    public static class Invalid_Credentials {
        private DBConnection connection;
        private DBConnectionInfo connectionInfo;

        private String dbType;
        private String dbUsername;
        private String dbPassword;
        private String dbServer;
        private String dbName;
        private String dbPort;

        @Rule
        public ExpectedException expectedException = ExpectedException.none();

        @After
        public void tearDown() throws SQLException {
            if (connection.getConnection() != null)
                connection.disconnect();
        }

        @Test
        public void mysql_bad_username_should_throw_SqlException() throws SQLException, ClassNotFoundException, IOException {
            dbType = "mysql";
            dbServer = "138.42.136.41";
            dbName = "InstallerTestDb";
            dbUsername = "BadUser123";
            dbPassword = "t3sti9";
            dbPort = "3306";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            expectedException.expect(SQLException.class);

            connection.connect();
        }

        @Test
        public void mysql_bad_password_should_throw_SqlException() throws SQLException, ClassNotFoundException, IOException {
            dbType = "mysql";
            dbServer = "138.42.136.41";
            dbUsername = "root";
            dbPassword = "badpassword123";
            dbPort = "3306";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            expectedException.expect(SQLException.class);

            connection.connect();
        }

        @Test
        public void mssql_bad_username_should_throw_SqlException() throws SQLException, ClassNotFoundException, IOException {
            dbType = "mssql";
            dbServer = "138.42.136.44";
            dbUsername = "baduser123";
            dbPassword = "t3sti9";
            dbPort = "1433";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            expectedException.expect(SQLException.class);

            connection.connect();
        }

        @Test
        public void mssql_bad_password_should_throw_SqlException() throws SQLException, ClassNotFoundException, IOException {
            dbType = "mssql";
            dbServer = "138.42.136.44";
            dbUsername = "sa";
            dbPassword = "badpassword123";
            dbPort = "1433";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            expectedException.expect(SQLException.class);

            connection.connect();
        }
    }
}
