package com.nimsoft.automation.fileshare;

import com.nimsoft.automation.installer.InstallPaths;
import com.nimsoft.automation.utils.OS;
import org.apache.commons.exec.CommandLine;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

import java.io.FileNotFoundException;

import static org.junit.Assert.assertEquals;

/**
 * Created by schja33 on 1/21/14.
 */
@RunWith(Enclosed.class)
public class CopyBitsTest {
    public static class Windows_Setup {


        private CopyBits copyBits;
        private CopyBits copyBits80;
        private CopyBits copyBitsUmp;
        private CopyBits copyBitsBnpp;
        private CopyBits copyBits81;
        private InstallPaths installPaths;
        private InstallPaths installPathsUmp;
        private InstallPaths installPaths80;
        private InstallPaths installPathsBnpp;
        private InstallPaths installPaths81;
        private String postfixInstaller;


        private CommandLine cL;
        private String[] cLA;
        @Before
        public void arrange() throws FileNotFoundException {
            cL = new CommandLine("hostname");
            if (OS.isWindows()) {
                postfixInstaller = ".exe";
                cLA = new String[]{"rm", "-rf", "c:\\Temp"};
            }
            else {
                postfixInstaller = ".bin";
                cLA = new String[]{"rm", "-rf", "/tmp/foo"};
            }
            installPaths = new InstallPaths("nms", "7.60");
            installPaths80 = new InstallPaths("nms", "8.00");
            installPathsUmp = new InstallPaths("ump", "8.00");
            installPathsBnpp = new InstallPaths("nms", "7.50", "", "bnpp");
            installPaths81  = new InstallPaths("nms", "8.10");
            act(installPaths, installPaths80, installPaths81, installPathsUmp, installPathsBnpp);
        }

        private void act(InstallPaths installPaths, InstallPaths installPaths80, InstallPaths installPaths81, InstallPaths installPathsUmp, InstallPaths installPathsBnpp) {
            copyBits = new CopyBits(installPaths);
            copyBits80 = new CopyBits(installPaths80);
            copyBits81 = new CopyBits(installPaths81);
            copyBitsUmp = new CopyBits(installPathsUmp);
            copyBitsBnpp = new CopyBits(installPathsBnpp);
        }

        //Generic testing methods
        @Test
        public void valid_checkBaseDir() {
            //arrange
            assertEquals("Directory baseDir already exists check, should be there", "BaseDir already Exists", copyBits.checkBaseDir());
        }

        @Test
        public void valid_setInstaller() {
            assertEquals("Install file doesnt exist check", "installNMS" + postfixInstaller, copyBits.setInstaller());
        }

        @Test
        public void valid_80nms_setInstaller(){
            assertEquals("8.0 installer new name should be pulled correctly, different than 7.6 and before", "setupCAUIMServer" + postfixInstaller, copyBits80.setInstaller());
        }

        @Test
        public void valid_81nms_setInstaller(){
            assertEquals("8.1 installer same as 8.0", "setupCAUIMServer" + postfixInstaller, copyBits81.setInstaller());
        }

        @Test
        public void valid_80ump_setInstaller(){
            if (OS.isWindows())
                assertEquals("8.0 installer new name should be pulled correctly,same as 7.6 and before", "installUMP" + postfixInstaller, copyBitsUmp.setInstaller());
            else
                assertEquals("8.0 installer new name should be pulled correctly,same as 7.6 and before", "installUMP_linux" + postfixInstaller, copyBitsUmp.setInstaller());
        }

        @Test
        public void valid_75ump_setInstaller() throws FileNotFoundException {
            installPaths = new InstallPaths("ump", "7.5.0");
            copyBits = new CopyBits(installPaths);
            if (OS.isWindows())
                assertEquals("7.5.0 installer new name should be pulled correctly", "installUMP" + postfixInstaller, copyBits.setInstaller());
            else
                assertEquals("7.5.0 installer new name should be pulled correctly", "installUMP_linux" + postfixInstaller, copyBits.setInstaller());
        }

        @Test
        public void valid_75nmsBNPP_setInstaller(){
            assertEquals("7.5 installer new name should be pulled correctly for bnpp ", "installNMS_bnpp" + postfixInstaller, copyBitsBnpp.setInstaller());
        }


        @Test
        public void valid_executeCmd() {
            assertEquals("Should execute a command and return 0",0, copyBits.executeCmd(cL));
        }


        @Test
        public void valid_multi_executeCmd() {
            //arrange
            cL = new CommandLine("ping");
            cL.addArgument("10.137.236.27");
            //   assertEquals("Should execute a command and return 0",0, copyBits.executeCmd(cL));
        }


        @Test
        public void valid_buildCommandLine() {
            if (OS.isWindows())
                assertEquals("Should return valid command line string from array", "rm -rf c:\\Temp", copyBits.buildCommandLine(cLA).toString());
            else
                assertEquals("Should return valid command line string from array", "rm -rf /tmp/foo", copyBits.buildCommandLine(cLA).toString());
        }


    }

}
