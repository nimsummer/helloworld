package com.nimsoft.automation.installer;

import com.nimsoft.automation.verify.ScanOutput;
import com.nimsoft.automation.installer.Install;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;

/**
 * Created by dustinlish on 1/15/14.
 */
@RunWith(Enclosed.class)
public class InstallTest {
    public static class failedVerify{
        Install install = new Install();

        @Test
        public void valid_printFailedLogFile() throws FileNotFoundException {
            ArrayList rc = new ArrayList();
            rc.add("the installer failed");
            rc.add("sorry try again");
            rc.add("booo");

            ScanOutput scanOutput = new ScanOutput("nms", "8.10");
            File location = new File(this.getClass().getClassLoader().getResource("iaoutput.txt").getFile());
            if (!location.exists())
                throw new FileNotFoundException(location.getAbsolutePath());
            System.out.println(location);
            scanOutput.setOutputfile(location.getAbsolutePath());
            System.out.println(location.getAbsolutePath());
            assertEquals("Output of resource file should be the same and printed", rc, install.printFailedLogFile(scanOutput));
        }
    }
}
