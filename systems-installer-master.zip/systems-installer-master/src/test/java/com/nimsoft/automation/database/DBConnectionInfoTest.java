package com.nimsoft.automation.database;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;

import java.io.*;
import java.util.HashMap;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;

/**
 * Created by lisdu02 on 1/30/14.
 */
@RunWith(Enclosed.class)
public class DBConnectionInfoTest {

    public static HashMap getMapFromReader(String prop) throws IOException {
        InputStream in = new FileInputStream(new File(prop));
        String line;
        HashMap<String, String> hm = new HashMap<String, String>();
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        while ((line = reader.readLine()) != null) {
            if (line.isEmpty()) // ignore blank lines
                continue;
            else if (line.charAt(0) == '#') // ignore comments
                continue;

            String[] pairs = line.split("=");
            if (pairs.length == 2)
                hm.put(pairs[0], pairs[1]);
            else
                hm.put(pairs[0], "");
        }
        reader.close();

        return hm;
    }

    public static class DBConnectionInfo_Constructor_Params {
        private DBConnectionInfo dbConnectionInfo;
        private String dbType;
        private String dbUsername;
        private String dbPassword;
        private String dbServer;
        private String dbName;
        private String dbPort;

        @Rule
        public ExpectedException expectedException = ExpectedException.none();

        @Before
        public void arrange() {
            dbUsername = "user";
            dbPassword = "password";
            dbServer = "138.42.136.44";
            dbName = "NimsoftSLM";
            dbPort = "3600";
        }

        @Test
        public void given_unsupported_dbType_should_throw_IllegalArgumentException() {
            dbType = "postgre";

            expectedException.expect(IllegalArgumentException.class);

            expectedException.expect(IllegalArgumentException.class);
            dbConnectionInfo = new DBConnectionInfo(dbType,  dbServer, dbName, dbUsername, dbPassword, dbPort);
        }

        @Test
        public void lowercase_dbType_should_not_throw_exception() {
            dbType = "mysql";

            try {
                dbConnectionInfo = new DBConnectionInfo(dbType,  dbServer, dbName, dbUsername, dbPassword, dbPort);
            } catch (IllegalArgumentException ex) {
                assertTrue("Lowercase dbType should not throw exception", false);
            }
        }

        @Test
        public void mixedcase_dbType_should_not_throw_exception() {
            dbType = "mYsQl";

            try {
                dbConnectionInfo = new DBConnectionInfo(dbType,  dbServer, dbName, dbUsername, dbPassword, dbPort);
            } catch (IllegalArgumentException ex) {
                assertTrue("Mixedcase dbType should not throw exception", false);
            }
        }

        @Test
        public void uppercase_dbType_should_not_throw_exception() {
            dbType = "MYSQL";

            try {
                dbConnectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            } catch (IllegalArgumentException ex) {
                assertTrue("Uppercase dbType should not throw exception", false);
            }
        }
    }

    public static class DBConnectionInfo_Check_Info_Is_Valid {
        private DBConnectionInfo connectionInfo;

        private String dbType;
        private String dbUsername;
        private String dbPassword;
        private String dbServer;
        private String dbName;
        private String dbPort;

        @Before
        public void arrange() {
            dbUsername = "user";
            dbPassword = "t3sti9";
        }

        @Test
        public void mysql_url_with_dbName_should_match_getConnectionURL() throws IOException {
            dbType = "mysql";
            dbServer = "10.238.3.61";
            dbName = "NimsoftSlm";
            dbPort = "1234";
            String url = "jdbc:mysql://" + dbServer + ":" + dbPort;

            connectionInfo = new DBConnectionInfo(dbType,  dbServer, dbName, dbUsername, dbPassword, dbPort);

            assertEquals("getConnectionUrl should match: " + url, url, connectionInfo.getConnectionURL());
        }

        @Test
        public void mysql_url_without_dbName_should_match_getConnectionURL() throws IOException {
            dbType = "mysql";
            dbServer = "10.238.3.61";
            dbPort = "1234";
            String url = "jdbc:mysql://" + dbServer + ":" + dbPort;

            connectionInfo = new DBConnectionInfo(dbType,  dbServer, dbUsername, dbPassword, dbPort);

            assertEquals("getConnectionUrl should match: " + url, url, connectionInfo.getConnectionURL());
        }

        @Test
        public void oracle_url_with_no_SID_should_match_getConnectionURL() throws IOException {
            dbType = "oracle";
            dbServer = "10.238.3.60";
            dbName = "NimsoftSlm";
            dbPort = "1234";
            String oracleSid = "ORCLAUTO";
            String url = "jdbc:oracle:thin:@" + dbServer + ":" + dbPort + ":" + oracleSid;

            connectionInfo = new DBConnectionInfo(dbType,  dbServer, dbName, dbUsername, dbPassword, dbPort);

            assertEquals("getConnectionUrl should match: " + url, url, connectionInfo.getConnectionURL());
        }

        @Test
        public void oracle_url_with_SID_should_match_getConnectionURL() throws IOException {
            dbType = "oracle";
            dbServer = "10.238.3.60";
            dbPort = "1234";
            String oracleSid = "SID";
            String url = "jdbc:oracle:thin:@" + dbServer + ":" + dbPort + ":" + oracleSid;

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbUsername, dbPassword, dbPort);
            connectionInfo.setOracleSID(oracleSid);

            assertEquals("getConnectionUrl should match: " + url, url, connectionInfo.getConnectionURL());
        }

        @Test
        public void oracle12_url_with_pluggable_should_match_getConnectionURL() throws IOException {
            dbType = "oracle";
            dbServer = "10.238.3.60";
            dbPort = "1521";
            String serviceName = "pdborcl";
            String url = "jdbc:oracle:thin:@" + dbServer + ":" + dbPort + "/" + serviceName;

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbUsername, dbPassword, dbPort);
            connectionInfo.setOracleSID(serviceName);
            connectionInfo.setOracle12(true);

            assertEquals("getConnectionUrl should match: " + url, url, connectionInfo.getConnectionURL());
        }


    }
}
