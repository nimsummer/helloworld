package com.nimsoft.automation.verify;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;


import java.io.*;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;

/**
 * Created by schja33 on 2/10/14.
 */
@RunWith(Enclosed.class)
public class ScanOutputIT {


    public static class verifyIaoutputWindows {
        public String fullDir = "C:\\tmp\\ia\\iaoutput.txt";
        public File f = new File(fullDir);


        public ScanOutput scanOutput;

        @Before
        public void arrange() throws IOException {
            FileUtils.touch(f);
            act();
        }
        private void act() throws IOException {
            scanOutput = new ScanOutput("nms", "8.10");
            PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(fullDir, true)));
            out.println("FAIL HERE");
            out.println("NOT BAD HERE");
            out.println("Running nms installer with the following properties");
            out.println("-- listing properties --\n" +
                        "WMI_PASS=\n" +
                        "TABLE_SPACE_LOC=\n" +
                        "DROP_COLUMNS=\n" +
                        "SSH_PASS=\n" +
                        "DISCOVERY_NET_2=\n" +
                        "DISCOVERY_NET_1=\n" +
                        "DB_PORT=1521\n" +
                        "NIMDBCREATE=true\n" +
                        "NMSNETWORKIP=10.238.0.180\n\n");
            out.println();
            out.println("fail again");
            out.println("blah blah nametoip failed blah exception skipped");
            out.println("error again");
            out.println("Final Probe Status Summary");
            out.println(" ace 3.10 (PID:       Port:      ) : UNRESPONSIVE");
            out.println("alarm_enrichment 4.20 (PID: 2114  Port: 48013) : ACTIVATED");
            out.println("Install finished");
            out.close();
        }

        // @Test
        public void verifyFailNotThere() throws FileNotFoundException {
            ArrayList rc  = new ArrayList();
            String[] text = {"fail"};
            rc.add("fail : fail again");
            rc.add("error : error again");
            assertEquals("Should return nothing", rc, scanOutput.scanForText(text));
        }

        //@Test
        public void verifyFailErrorNotThere() throws FileNotFoundException {
            ArrayList rc  = new ArrayList();
            String[] text = {"fail","error"};
            rc.add("fail");
            rc.add("error");
            assertEquals("Should return nothing", rc, scanOutput.scanForText(text));
        }

        @Ignore
        public void verifyRetrieveProbeSummaryEmpty() throws FileNotFoundException {
            ArrayList rc  = new ArrayList();

            assertEquals("Should return nothing", rc, scanOutput.retrieveProbeSummary());
        }

        @Test
        public void verifyRetrieveProbeSummaryExample() throws IOException {
            ArrayList rc  = new ArrayList();
            rc.add("Final Probe Status Summary");
            rc.add(" ace 3.10 (PID:       Port:      ) : UNRESPONSIVE");
            rc.add("alarm_enrichment 4.20 (PID: 2114  Port: 48013) : ACTIVATED");
            rc.add("Install finished");
            //assertEquals("Should return nothing", rc, scanOutput.retrieveProbeSummary());
        }

        //@Test
        public void verifyRetrievePropertiesSummaryExample() throws IOException {
            ArrayList rc  = new ArrayList();
            String properties = "/tmp/foo.properties";
            rc.add("Running nms installer with the following propertiese");
            assertEquals("Should return a short list", rc, scanOutput.summaryInstall(properties, rc, false));
        }

        @After
        public void clean() {
            System.out.println("Deleteing file");

            f.delete();

        }

    }
}
