package com.nimsoft.automation.fileshare;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;

import java.io.FileNotFoundException;

import static org.junit.Assert.*;

/**
 * Created by lisdu02 on 1/22/14.
 */
@RunWith(Enclosed.class)
public class SftpIT {

    public static class Sftp_Cmd_Tests {
        private String user;
        private String pass;
        private String host;

        private Sftp sftp;
        private static final String TEST_FILE = ClassLoader.getSystemResource("test.file").getFile();

        @Rule
        public ExpectedException expectedException = ExpectedException.none();

        @Before
        public void arrange() {
            user = "qateam";
            pass = "t3sti9";
            host = "138.42.229.66";

            act();
        }

        private void act() {
            sftp = new Sftp(host, user, pass);
            try {
                sftp.connect();
            } catch (JSchException e) {
                e.printStackTrace();
            }
        }

        @Test
        public void Sftp_cmd_should_pass() throws JSchException, SftpException, FileNotFoundException {
            String cmd = "Sftp -f ";
            String remoteTestFile = "/mnt/vg_main/vol01/QA/CHO/test/integration_test.txt";
            String localTestFile = TEST_FILE;

            assertTrue("S", sftp.sftpCmd(remoteTestFile, localTestFile));
        }

        @Test
        public void Sftp_unknwown_remote_file_should_throw_SftpException() throws JSchException, SftpException {
            String cmd = "Sftp -f ";
            String badRemoteFile = "sdflksajsdfasdf.txt";
            String localFileName = TEST_FILE;

            expectedException.expect(SftpException.class);

            sftp.sftpCmd(badRemoteFile, localFileName);
        }

    }

    public static class Sftp_Connection_Tests {
        private String user;
        private String pass;
        private String host;

        @Rule
        public ExpectedException expectedException = ExpectedException.none();

        @Test
        public void given_valid_credentials_should_connect() throws JSchException {
            user = "qateam";
            pass = "t3sti9";
            host = "138.42.229.66";

            Sftp sftp = new Sftp(host, user, pass);

            assertTrue("Sftp object should connect", sftp.connect());
        }

        @Test
        public void given_bad_username_should_throw_JSchException() throws JSchException {
            user = "bad_user";
            pass = "t3sti9";
            host = "138.42.229.66";

            Sftp sftp = new Sftp(host, user, pass);
            expectedException.expect(JSchException.class);

            sftp.connect();
        }

        @Test
        public void given_bad_password_should_throw_JSchException() throws JSchException {
            user = "bad_user";
            pass = "badpassword";
            host = "138.42.229.66";

            Sftp sftp = new Sftp(host, user, pass);
            expectedException.expect(JSchException.class);

            sftp.connect();
        }

        @Test
        public void given_bad_host_should_throw_JSchException() throws JSchException {
            user = "qateam";
            pass = "t3sti9";
            host = "10.9.8.7";

            Sftp sftp = new Sftp(host, user, pass);
            sftp.setTimeout(3000);
            expectedException.expect(JSchException.class);

            sftp.connect();
        }
    }

}
