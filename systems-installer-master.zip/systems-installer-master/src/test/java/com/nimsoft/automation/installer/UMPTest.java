package com.nimsoft.automation.installer;

import com.nimsoft.automation.utils.Props;
import org.apache.commons.cli.ParseException;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

import java.io.FileNotFoundException;
import java.net.UnknownHostException;
import java.util.Map;

import static org.junit.Assert.assertEquals;

/**
 * Created by lisdu02 on 3/11/14.
 */
@RunWith(Enclosed.class)
public class UMPTest {

    public static class Generate_Properties_Files {
        private UMP umpInstall;

        private void cleanUp(Props prop) {
            prop.cleanUp();
        }

        @Test
        public void given_ump_generate_default_props() throws ParseException, FileNotFoundException, UnknownHostException {
            // UMP Defaults
            String DOMAIN = "DustinsDom";
            String HUB = "DustinsHub";
            String ROBOT = "DustinsRobot";
            String IP = "10.238.0.97";
            String NIMBUS_ADDRESS = "/" + DOMAIN + "/" + HUB + "/" + ROBOT;

            String NIMBUS_USERNAME = "administrator";
            String NIMBUS_PASSWORD = "t3sti9";
            String HUB_ROBOT = NIMBUS_ADDRESS;
            String HUB_ROBOT_IP = IP;
            String UMP_ROBOT = NIMBUS_ADDRESS;
            String UMP_ROBOT_IP = IP;
            String UMP_HTTP_PORT = "80";
            String UMP_AJP_PORT = "8009";
            String OVERWRITE_DYNAMIC_VIEWS = "true";
            String WEBSERVICE_DASHBOARD_API = "true";
            String SHORTCUT_DESKTOP = "true";
            String WEBSERVICE_MOBILE = "true";
            String SHORTCUT_STARTMENU = "true";
            String ACE_PROBE = NIMBUS_ADDRESS + "/ace";
            String ADE_PROBE = NIMBUS_ADDRESS + "/automated_deployment_engine";
            String DATA_ENGINE_PROBE = NIMBUS_ADDRESS + "/data_engine";
            String DISCOVERY_SERVER_PROBE = NIMBUS_ADDRESS + "/discovery_server";
            String MPSE_PROBE = NIMBUS_ADDRESS + "/mpse";
            String MAINTENANCE_MODE_PROBE = NIMBUS_ADDRESS + "/maintenance_mode";
            String NAS_PROBE = NIMBUS_ADDRESS + "/nas";
            String NIS_SERVER_PROBE = NIMBUS_ADDRESS + "/nis_server";
            String RELATIONSHIP_SERVICES_PROBE = NIMBUS_ADDRESS + "/relationship_services";
            String SERVICE_HOST_PROBE = NIMBUS_ADDRESS + "/service_host";
            String SLA_ENGINE_PROBE = NIMBUS_ADDRESS + "/sla_engine";

            String[] args = {
                "-install", "ump",
                "-version", "7.10",
                "-ip",      IP,
                "-domain",  DOMAIN,
                "-hub",     HUB,
                "-robot",   ROBOT,
                "-user",    "administrator",
                "-password","t3sti9"
            };
            InstallOptions opts = new InstallOptions(args);
            Map<String, String> optsMap = opts.getOptionsMap();
            umpInstall = new UMP(optsMap.get("install"), optsMap.get("ip"));

            // Act
            umpInstall.loadProps(optsMap, null);

            // Assert
            // NMS Defaults
            assertEquals("Default NIMBUS_USERNAME should be " + NIMBUS_USERNAME, NIMBUS_USERNAME, umpInstall.getProp("NIMBUS_USERNAME"));
            assertEquals("Default NIMBUS_PASSWORD should be " + NIMBUS_PASSWORD, NIMBUS_PASSWORD, umpInstall.getProp("NIMBUS_PASSWORD"));
            assertEquals("Default HUB_ROBOT should be " + HUB_ROBOT, HUB_ROBOT, umpInstall.getProp("HUB_ROBOT"));
            assertEquals("Default HUB_ROBOT_IP should be " + HUB_ROBOT_IP, HUB_ROBOT_IP, umpInstall.getProp("HUB_ROBOT_IP"));
            assertEquals("Default UMP_ROBOT should be " + UMP_ROBOT, UMP_ROBOT, umpInstall.getProp("UMP_ROBOT"));
            assertEquals("Default UMP_ROBOT_IP should be " + UMP_ROBOT_IP, UMP_ROBOT_IP, umpInstall.getProp("UMP_ROBOT_IP"));
            assertEquals("Default UMP_HTTP_PORT should be " + UMP_HTTP_PORT, UMP_HTTP_PORT, umpInstall.getProp("UMP_HTTP_PORT"));

            assertEquals("Default UMP_AJP_PORT should be " + UMP_AJP_PORT, UMP_AJP_PORT, umpInstall.getProp("UMP_AJP_PORT"));
            assertEquals("Default SHORTCUT_DESKTOP should be " + SHORTCUT_DESKTOP, SHORTCUT_DESKTOP, umpInstall.getProp("SHORTCUT_DESKTOP"));
            assertEquals("Default WEBSERVICE_MOBILE should be " + WEBSERVICE_MOBILE, WEBSERVICE_MOBILE, umpInstall.getProp("WEBSERVICE_MOBILE"));
            assertEquals("Default SHORTCUT_STARTMENU should be " + SHORTCUT_STARTMENU, SHORTCUT_STARTMENU, umpInstall.getProp("SHORTCUT_STARTMENU"));
            assertEquals("Default OVERWRITE_DYNAMIC_VIEWS should be " + OVERWRITE_DYNAMIC_VIEWS, OVERWRITE_DYNAMIC_VIEWS, umpInstall.getProp("OVERWRITE_DYNAMIC_VIEWS"));
            assertEquals("Default WEBSERVICE_DASHBOARD_API should be " + WEBSERVICE_DASHBOARD_API, WEBSERVICE_DASHBOARD_API, umpInstall.getProp("WEBSERVICE_DASHBOARD_API"));


            assertEquals("Default ACE_PROBE should be " + ACE_PROBE, ACE_PROBE, umpInstall.getProp("ACE_PROBE"));
            assertEquals("Default ADE_PROBE should be " + ADE_PROBE, ADE_PROBE, umpInstall.getProp("ADE_PROBE"));
            assertEquals("Default DATA_ENGINE_PROBE should be " + DATA_ENGINE_PROBE, DATA_ENGINE_PROBE, umpInstall.getProp("DATA_ENGINE_PROBE"));
            assertEquals("Default DISCOVERY_SERVER_PROBE should be " + DISCOVERY_SERVER_PROBE, DISCOVERY_SERVER_PROBE, umpInstall.getProp("DISCOVERY_SERVER_PROBE"));
            assertEquals("Default MPSE_PROBE should be " + MPSE_PROBE, MPSE_PROBE, umpInstall.getProp("MPSE_PROBE"));
            assertEquals("Default MAINTENANCE_MODE_PROBE should be " + MAINTENANCE_MODE_PROBE, MAINTENANCE_MODE_PROBE, umpInstall.getProp("MAINTENANCE_MODE_PROBE"));
            assertEquals("Default NAS_PROBE should be " + NAS_PROBE, NAS_PROBE, umpInstall.getProp("NAS_PROBE"));
            assertEquals("Default NIS_SERVER_PROBE should be " + NIS_SERVER_PROBE, NIS_SERVER_PROBE, umpInstall.getProp("NIS_SERVER_PROBE"));
            assertEquals("Default RELATIONSHIP_SERVICES_PROBE should be " + RELATIONSHIP_SERVICES_PROBE, RELATIONSHIP_SERVICES_PROBE, umpInstall.getProp("RELATIONSHIP_SERVICES_PROBE"));
            assertEquals("Default SERVICE_HOST_PROBE should be " + SERVICE_HOST_PROBE, SERVICE_HOST_PROBE, umpInstall.getProp("SERVICE_HOST_PROBE"));
            assertEquals("Default SLA_ENGINE_PROBE should be " + SLA_ENGINE_PROBE, SLA_ENGINE_PROBE, umpInstall.getProp("SLA_ENGINE_PROBE"));

            cleanUp(umpInstall.getProp());
        }

        @Test
        public void ump_remote_robot() throws ParseException, FileNotFoundException, UnknownHostException {
            // UMP Defaults
            String DOMAIN = "DustinsDom";
            String HUB = "DustinsHub";
            String ROBOT = "DustinsRobot";
            String IP = "10.238.0.97";
            String UMP_ROBOT = "/" + DOMAIN + "/" + HUB + "/" + "test_ump_robot";
            String UMP_ROBOT_IP = "10.238.0.123";
            String NIMBUS_ADDRESS = "/" + DOMAIN + "/" + HUB + "/" + ROBOT;

            String NIMBUS_USERNAME = "administrator";
            String NIMBUS_PASSWORD = "t3sti9";
            String HUB_ROBOT = NIMBUS_ADDRESS;
            String HUB_ROBOT_IP = IP;

            String UMP_HTTP_PORT = "80";
            String UMP_AJP_PORT = "8009";
            String OVERWRITE_DYNAMIC_VIEWS = "true";
            String WEBSERVICE_DASHBOARD_API = "true";
            String SHORTCUT_DESKTOP = "true";
            String WEBSERVICE_MOBILE = "true";
            String SHORTCUT_STARTMENU = "true";
            String ACE_PROBE = NIMBUS_ADDRESS + "/ace";
            String ADE_PROBE = NIMBUS_ADDRESS + "/automated_deployment_engine";
            String DATA_ENGINE_PROBE = NIMBUS_ADDRESS + "/data_engine";
            String DISCOVERY_SERVER_PROBE = NIMBUS_ADDRESS + "/discovery_server";
            String MAINTENANCE_MODE_PROBE = NIMBUS_ADDRESS + "/maintenance_mode";
            String MPSE_PROBE = NIMBUS_ADDRESS + "/mpse";
            String NAS_PROBE = NIMBUS_ADDRESS + "/nas";
            String NIS_SERVER_PROBE = NIMBUS_ADDRESS + "/nis_server";
            String RELATIONSHIP_SERVICES_PROBE = NIMBUS_ADDRESS + "/relationship_services";
            String SERVICE_HOST_PROBE = NIMBUS_ADDRESS + "/service_host";
            String SLA_ENGINE_PROBE = NIMBUS_ADDRESS + "/sla_engine";

            String[] args = {
                "-install", "ump",
                "-version", "7.10",
                "-ip",      IP,
                "-domain",  DOMAIN,
                "-hub",     HUB,
                "-robot",   ROBOT,
                "-user",    "administrator",
                "-password","t3sti9",
                "-robot_ip", "10.238.0.123",
                "-robot_name", "test_ump_robot"
            };
            InstallOptions opts = new InstallOptions(args);
            Map<String, String> optsMap = opts.getOptionsMap();
            umpInstall = new UMP(optsMap.get("install"), optsMap.get("ip"));

            // Act
            umpInstall.loadProps(optsMap, null);

            // Assert
            // NMS Defaults
            assertEquals("Default NIMBUS_USERNAME should be " + NIMBUS_USERNAME, NIMBUS_USERNAME, umpInstall.getProp("NIMBUS_USERNAME"));
            assertEquals("Default NIMBUS_PASSWORD should be " + NIMBUS_PASSWORD, NIMBUS_PASSWORD, umpInstall.getProp("NIMBUS_PASSWORD"));
            assertEquals("Default HUB_ROBOT should be " + HUB_ROBOT, HUB_ROBOT, umpInstall.getProp("HUB_ROBOT"));
            assertEquals("Default HUB_ROBOT_IP should be " + HUB_ROBOT_IP, HUB_ROBOT_IP, umpInstall.getProp("HUB_ROBOT_IP"));
            assertEquals("Default UMP_ROBOT should be " + UMP_ROBOT, UMP_ROBOT, umpInstall.getProp("UMP_ROBOT"));
            assertEquals("Default UMP_ROBOT_IP should be " + UMP_ROBOT_IP, UMP_ROBOT_IP, umpInstall.getProp("UMP_ROBOT_IP"));
            assertEquals("Default UMP_HTTP_PORT should be " + UMP_HTTP_PORT, UMP_HTTP_PORT, umpInstall.getProp("UMP_HTTP_PORT"));

            assertEquals("Default UMP_AJP_PORT should be " + UMP_AJP_PORT, UMP_AJP_PORT, umpInstall.getProp("UMP_AJP_PORT"));
            assertEquals("Default SHORTCUT_DESKTOP should be " + SHORTCUT_DESKTOP, SHORTCUT_DESKTOP, umpInstall.getProp("SHORTCUT_DESKTOP"));
            assertEquals("Default WEBSERVICE_MOBILE should be " + WEBSERVICE_MOBILE, WEBSERVICE_MOBILE, umpInstall.getProp("WEBSERVICE_MOBILE"));
            assertEquals("Default SHORTCUT_STARTMENU should be " + SHORTCUT_STARTMENU, SHORTCUT_STARTMENU, umpInstall.getProp("SHORTCUT_STARTMENU"));
            assertEquals("Default OVERWRITE_DYNAMIC_VIEWS should be " + OVERWRITE_DYNAMIC_VIEWS, OVERWRITE_DYNAMIC_VIEWS, umpInstall.getProp("OVERWRITE_DYNAMIC_VIEWS"));
            assertEquals("Default WEBSERVICE_DASHBOARD_API should be " + WEBSERVICE_DASHBOARD_API, WEBSERVICE_DASHBOARD_API, umpInstall.getProp("WEBSERVICE_DASHBOARD_API"));


            assertEquals("Default ACE_PROBE should be " + ACE_PROBE, ACE_PROBE, umpInstall.getProp("ACE_PROBE"));
            assertEquals("Default ADE_PROBE should be " + ADE_PROBE, ADE_PROBE, umpInstall.getProp("ADE_PROBE"));
            assertEquals("Default DATA_ENGINE_PROBE should be " + DATA_ENGINE_PROBE, DATA_ENGINE_PROBE, umpInstall.getProp("DATA_ENGINE_PROBE"));
            assertEquals("Default DISCOVERY_SERVER_PROBE should be " + DISCOVERY_SERVER_PROBE, DISCOVERY_SERVER_PROBE, umpInstall.getProp("DISCOVERY_SERVER_PROBE"));
            assertEquals("Default MAINTENANCE_MODE_PROBE should be " + MAINTENANCE_MODE_PROBE, MAINTENANCE_MODE_PROBE, umpInstall.getProp("MAINTENANCE_MODE_PROBE"));
            assertEquals("Default MPSE_PROBE should be " + MPSE_PROBE, MPSE_PROBE, umpInstall.getProp("MPSE_PROBE"));
            assertEquals("Default NAS_PROBE should be " + NAS_PROBE, NAS_PROBE, umpInstall.getProp("NAS_PROBE"));
            assertEquals("Default NIS_SERVER_PROBE should be " + NIS_SERVER_PROBE, NIS_SERVER_PROBE, umpInstall.getProp("NIS_SERVER_PROBE"));
            assertEquals("Default RELATIONSHIP_SERVICES_PROBE should be " + RELATIONSHIP_SERVICES_PROBE, RELATIONSHIP_SERVICES_PROBE, umpInstall.getProp("RELATIONSHIP_SERVICES_PROBE"));
            assertEquals("Default SERVICE_HOST_PROBE should be " + SERVICE_HOST_PROBE, SERVICE_HOST_PROBE, umpInstall.getProp("SERVICE_HOST_PROBE"));
            assertEquals("Default SLA_ENGINE_PROBE should be " + SLA_ENGINE_PROBE, SLA_ENGINE_PROBE, umpInstall.getProp("SLA_ENGINE_PROBE"));

            cleanUp(umpInstall.getProp());
        }

    }
}
