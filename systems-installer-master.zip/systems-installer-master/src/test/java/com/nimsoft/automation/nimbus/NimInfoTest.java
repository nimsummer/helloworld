package com.nimsoft.automation.nimbus;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

import java.io.*;

import static org.junit.Assert.assertEquals;

/**
 * Created by schja33 on 2/12/14.
 */
@RunWith(Enclosed.class)
public class NimInfoTest {

    @Ignore
    public static class verifyIaoutputWindows {
        public String nimDir;
        public String probeUtil;
        public String nimDirS;
        public String probeUtilS;
        public NimInfo nimInfo;
        public File f;
        public File p;

        @Before
        public void arrange() throws IOException {

            act();
        }
        private void act() throws IOException {

        }

        @Test
        public void verifyWinNimDir() throws IOException {
            nimDir = "c:/Program Files (x86)/Nimsoft";
            probeUtil = "c:/Program Files (x86)/Nimsoft/bin/pu.exe";
            f = new File(nimDir);
            p = new File(probeUtil);
            if (!f.exists()) {
                f.mkdir();
            }
            if (!p.exists()) {
                FileUtils.touch(p);
            }
            nimInfo = new NimInfo();
            assertEquals("Should return the same as nimDir", nimDir, nimInfo.getNimDir());
            p.delete();
            f.delete();
        }

        @Test
        public void verifyProbeUtilityExists() throws IOException {
            nimDir = "c:/Program Files (x86)/Nimsoft";
            probeUtil = "c:/Program Files (x86)/Nimsoft/bin/pu.exe";
            f = new File(nimDir);
            p = new File(probeUtil);
            if (!f.exists()) {
                f.mkdir();
            }
            if (!p.exists()) {
                FileUtils.touch(p);
            }
            nimInfo = new NimInfo();
            assertEquals("Should return the same as nimDir", probeUtil, nimInfo.getProbeUtility());
            p.delete();
            f.delete();

        }
        @Test(expected = FileNotFoundException.class)
        public void verifyProbeUtilityDoesntExists() throws IOException {
            nimDir = "c:/Program Files (x86)/Nimsoft";
            probeUtil = "c:/Program Files (x86)/Nimsoft/bin/pu.exe";
            f = new File(nimDir);
            p = new File(probeUtil);
            if (!f.exists()) {
                f.mkdir();
            }
            if (p.exists()) {
                p.delete();
            }
            nimInfo = new NimInfo();
//            nimInfo.setProbeUtility();
            p.delete();
            f.delete();

        }

        @Test(expected = FileNotFoundException.class)
        public void verifyNimDirDoesntExist() throws IOException {
            nimDir = "c:/Program Files/Nimsoft";
            f = new File(nimDir);

            if (!f.exists()) {
                FileUtils.deleteDirectory(f);
            }
            nimInfo = new NimInfo();
//            nimInfo.setNimDir();
            f.delete();
        }

        @Test
        public void verifyNimDirWinSimpleExists() throws IOException {
            nimDir = "c:/Program Files/Nimsoft";
            probeUtil = "c:/Program Files/Nimsoft/bin/pu.exe";
            f = new File(nimDir);
            p = new File(probeUtil);
            if (!f.exists()) {
                f.mkdir();
            }
            if (!p.exists()) {
                FileUtils.touch(p);
            }
            nimInfo = new NimInfo();
            assertEquals("should return simple dir for Windows", nimDir, nimInfo.getNimDir());
            p.delete();
            f.delete();

        }

        @After
        public void clean() throws IOException {
            System.out.println("Deleteing file");
            nimDir = "c:/Program Files (x86)/Nimsoft";
            probeUtil = "c:/Program Files (x86)/Nimsoft/bin/pu.exe";
            nimDirS = "c:/Program Files/Nimsoft";
            probeUtilS = "c:/Program Files/Nimsoft/bin/pu.exe";
            File f1 = new File(nimDir);
            File p1 = new File(probeUtil);
            File f2 = new File(nimDirS);
            File p2 = new File(probeUtilS);
            p1.delete();
            p2.delete();
            FileUtils.deleteDirectory(f1);
            FileUtils.deleteDirectory(f2);


        }

    }


}
