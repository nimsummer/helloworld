package com.nimsoft.automation.robot;

import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

/**
 * Created by hajbr03 on 11/20/2014.
 */
@RunWith(Enclosed.class)
public class AdeJobTest
{
}
