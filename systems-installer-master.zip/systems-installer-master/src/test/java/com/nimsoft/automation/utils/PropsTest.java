package com.nimsoft.automation.utils;

import org.junit.*;
import org.junit.experimental.runners.Enclosed;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Created by dustinlish on 1/15/14.
 */
@RunWith(Enclosed.class)
public class PropsTest {

    public static class Constructor {
        private String install;
        private String ip;
        private String db;
        private String version;

        private Props prop;

        @Before
        public void arrange() {
            install = "nms";
            db = "MSSQL";
            ip = "10.238.0.97";
            version = "8.00";

            act();
        }

        private void act() {
            prop = new Props(install, ip, db, version);
        }

        @After
        public void teardown() {
            prop.cleanUp();
        }

        @Test
        public void given_install_should_getInstall() {
            // Assert
            assertEquals("Should get correct install type", install, prop.getInstall());
        }

        @Test
        public void given_version_should_getDb() {
            // Assert
            assertEquals("Should get correct db type", db, prop.getDb());
        }
    }

    public static class Constructor_Invalid_Params {
        private String install;
        private String ip;
        private String db;
        private String customProps;
        private String version;

        private Props prop;

        @Rule
        public ExpectedException expectedException = ExpectedException.none();

        @Test
        public void invalid_install_type_should_throw_IllegalArgumentException() {
            // Arrange
            install = "bad_install_type";
            ip = "10.238.0.97";
            db = "MSSQL";

            //Act
            expectedException.expect(IllegalArgumentException.class);

            // Assert
            prop = new Props(install, ip, db, version);
            prop.cleanUp();
        }

        @Test
        public void invalid_db_type_should_throw_IllegalArgumentException() {
            // Arrange
            install = "nms";
            ip = "10.238.0.97";
            db = "MSSSQQQQQLLL";

            //Act
            expectedException.expect(IllegalArgumentException.class);

            // Assert
            prop = new Props(install, ip, db, version);
            prop.cleanUp();
        }

        @Test
        public void invalid_custom_properties_file_should_throw_FileNotFoundException() throws FileNotFoundException {
            // Arrange
            install = "nms";
            ip = "10.238.0.97";
            db = "MSSQL";
            customProps = "/path/to/some/file/that/does/not/exist.properties";

            //Act
            expectedException.expect(FileNotFoundException.class);
            prop = new Props(install, ip, db, version);

            // Assert
            prop.loadCustomProperties(customProps);
            prop.cleanUp();
        }

    }

    public static class Props_Method_Tests {
        private Boolean compareExactMatch(String file1, String file2) throws IOException {
            InputStream in1 = new FileInputStream(new File(file1));
            InputStream in2 = new FileInputStream(new File(file2));
            StringBuffer sb1 = getStringBufferFromReader(in1);
            StringBuffer sb2 = getStringBufferFromReader(in2);
            return sb1.length() == sb2.length();
        }

        private Boolean containsAllProperties(String doTheseProperties, String containTheseProperties) throws IOException {
            InputStream in1 = new FileInputStream(new File(doTheseProperties));
            InputStream in2 = new FileInputStream(new File(containTheseProperties));
            HashMap<String, String> hm1 = getMapFromReader(in1);
            HashMap<String, String> hm2 = getMapFromReader(in2);

            for (Map.Entry entry : hm2.entrySet()) {
                if (!hm1.containsKey(entry.getKey()) || !hm1.containsValue(entry.getValue())) {
                    System.out.println("Does current key: " + entry.getKey() + " with value: " + entry.getValue());
                    System.out.println("Exist in " + doTheseProperties
                            + " key: " + hm1.containsKey(entry.getKey())
                            + " : value: " + hm1.containsValue(entry.getValue()) + "\n");
                    return false;
                }
            }
            return true;
        }

        private boolean containsValuesFromMap(String installProps, Map<String,String> argsMap) throws IOException {
            InputStream in1 = new FileInputStream(new File(installProps));
            HashMap<String, String> hm1 = getMapFromReader(in1);

            for (Map.Entry entry : argsMap.entrySet()) {
                if (hm1.containsKey(entry.getKey())) {
                    if (!hm1.containsValue(entry.getValue())) {
                        System.out.println("Does current key: " + entry.getKey() + " with value: " + entry.getValue());
                        System.out.println("Exist in " + installProps
                                + " key: " + hm1.containsKey(entry.getKey())
                                + " : value: " + hm1.containsValue(entry.getValue()) + " - " + hm1.get(entry.getKey()) + "\n");
                        return false;
                    }
                }
            }
            return true;
        }

        private StringBuffer getStringBufferFromReader(InputStream is) throws IOException {
            String line;
            StringBuffer sb = new StringBuffer();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            while ((line = reader.readLine()) != null) {
                if (line.isEmpty()) // ignore blank lines
                    continue;
                else if (line.charAt(0) == '#') // ignore comments
                    continue;
                sb.append(line + "\n");
            }
            reader.close();

            return sb;
        }

        private HashMap getMapFromReader(InputStream is) throws IOException {
            String line;
            HashMap<String, String> hm = new HashMap<String, String>();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            while ((line = reader.readLine()) != null) {
                if (line.isEmpty()) // ignore blank lines
                    continue;
                else if (line.charAt(0) == '#') // ignore comments
                    continue;

                String[] pairs = line.split("=");
                if (pairs.length == 2)
                    hm.put(pairs[0], pairs[1]);
                else
                    hm.put(pairs[0], "");
            }
            reader.close();

            return hm;
        }

        private String getUserDir() {
            if (OS.isWindows())
                return "C\\:\\\\Program Files\\\\Nimsoft";
            else
                return "/opt/nimsoft";
        }

        private final String RESOURCE_PATH = "src/main/resources";
        private final String NMS_INSTALL_ALL_PROPERTIES = RESOURCE_PATH + "/NMS/installer.all.properties";
        private final String UMP_INSTALL_ALL_PROPERTIES = RESOURCE_PATH + "/UMP/installer.all.properties";

        private final String NMS_MSSQL_PROPERTIES = RESOURCE_PATH + "/DB/mssql.properties";
        private final String NMS_MYSQL_PROPERTIES = RESOURCE_PATH + "/DB/mysql.properties";
        private final String NMS_ORACLE_PROPERTIES = RESOURCE_PATH + "/DB/oracle.properties";
        private final String NMS_ORACLE12_PROPERTIES = RESOURCE_PATH + "/DB/oracle12.properties";
        private final String INSTALL_PROPERTIES = "installer.properties";

        private String install;
        private String ip;
        private String db;
        private String version;

        private Props prop;

        @Before
        public void arrange() {
            ip = "10.238.0.97";
            version = "8.00";
        }

        private void cleanUp(Props prop) {
            prop.cleanUp();
        }

        @Test
        public void nms_load_initial_props() throws IOException {
            // Arrange
            install = "nms";
            db = "mssql";

            prop = new Props(install, ip, db, version);

            // Assert
            assertTrue("Constructor should load initial properties from " + NMS_INSTALL_ALL_PROPERTIES, compareExactMatch(prop.getPropertiesFile(), NMS_INSTALL_ALL_PROPERTIES));
            cleanUp(prop);
        }

        @Test
        public void ump_load_initial_props() throws IOException {
            // Arrange
            install = "ump";

            prop = new Props(install, ip);

            // Assert
            assertTrue("Constructor should load initial properties from " + UMP_INSTALL_ALL_PROPERTIES, compareExactMatch(prop.getPropertiesFile(), UMP_INSTALL_ALL_PROPERTIES));
            cleanUp(prop);
        }

        @Test
        public void nms_mssql_loadDbProperties() throws IOException {
            // Arrange
            install = "nms";
            db = "mssql";

            prop = new Props(install, ip, db, version);
            prop.loadDBProperties(db);

            // Assert
            assertTrue("Constructor should load initial properties from " + NMS_MSSQL_PROPERTIES, containsAllProperties(prop.getPropertiesFile(), NMS_MSSQL_PROPERTIES));
            cleanUp(prop);
        }

        @Test
        public void nms_mysql_loadDbProperties() throws IOException {
            // Arrange
            install = "nms";
            db = "mysql";

            prop = new Props(install, ip, db, version);
            prop.loadDBProperties(db);

            // Assert
            assertTrue("Constructor should load initial properties from " + NMS_MYSQL_PROPERTIES, containsAllProperties(prop.getPropertiesFile(), NMS_MYSQL_PROPERTIES));
            cleanUp(prop);
        }

        @Test
        public void nms_oracle_loadDbProperties() throws IOException {
            // Arrange
            install = "nms";
            db = "oracle";

            prop = new Props(install, ip, db, version);
            prop.loadDBProperties(db);

            // Assert
            assertTrue("Constructor should load initial properties from " + NMS_ORACLE_PROPERTIES, containsAllProperties(prop.getPropertiesFile(), NMS_ORACLE_PROPERTIES));
            cleanUp(prop);
        }

        @Test
        public void nms_oracle12_loadDbProperties() throws IOException {
            // Arrange
            install = "nms";
            db = "oracle";

            prop = new Props(install, ip, db, version);
            prop.loadDBProperties("oracle_12");

            // Assert
            assertTrue("Constructor should load initial properties from " + NMS_ORACLE12_PROPERTIES, containsAllProperties(prop.getPropertiesFile(), NMS_ORACLE12_PROPERTIES));
            cleanUp(prop);
        }

        @Test
        public void given_custom_props_generate_props() throws IOException {
            // Arrange
            install = "nms";
            db = "mssql";
            String customProps;
            String installProps;

            // Act
            prop = new Props(install, ip, db, version);
            customProps = "src/main/resources/test.custom.properties";
            installProps = INSTALL_PROPERTIES;
            prop.loadCustomProperties(customProps);

            // Assert
            assertTrue(installProps + " should contain all properties from " + customProps, containsAllProperties(installProps, customProps));
            cleanUp(prop);
        }

        @Test
        public void loadCustomPropertiesFromMap_Test() throws IOException {
            install = "ump";

            String nimbusAddress = "/auto_dom/auto_hub/auto_robot";
            Map<String, String> umpOpts = new HashMap<String, String>();
            umpOpts.put("NIMBUS_USERNAME", "TEST_USER");
            umpOpts.put("NIMBUS_PASSWORD", "TEST_PASSWORD");
            umpOpts.put("HUB_ROBOT_IP",    "10.238.0.97");
            umpOpts.put("UMP_ROBOT_IP",    "10.238.0.97");
            umpOpts.put("HUB_ROBOT",       nimbusAddress);

            prop = new Props(install, ip);
            assertTrue("Verify properties match before searchAndReplace", compareExactMatch(prop.getPropertiesFile(), UMP_INSTALL_ALL_PROPERTIES));

            prop.loadCustomPropertiesFromMap(umpOpts);
            assertFalse("New properties should not match", compareExactMatch(prop.getPropertiesFile(), UMP_INSTALL_ALL_PROPERTIES));
        }


        @Test
        public void searchAndReplace_test() throws IOException {
            install = "ump";

            String nimbusAddress = "/auto_dom/auto_hub/auto_robot";
//            Map<String, String> umpOpts = new HashMap<String, String>();
//            umpOpts.put("NIMBUS_USERNAME", "TEST_USER");
//            umpOpts.put("NIMBUS_PASSWORD", "TEST_PASSWORD");
//            umpOpts.put("HUB_ROBOT_IP",    "10.238.0.97");
//            umpOpts.put("UMP_ROBOT_IP",    "10.238.0.97");
//            umpOpts.put("HUB_ROBOT",       nimbusAddress);

            prop = new Props(install, ip);
            assertTrue("Verify properties match before searchAndReplace", compareExactMatch(prop.getPropertiesFile(), UMP_INSTALL_ALL_PROPERTIES));

//            prop.loadCustomPropertiesFromMap(umpOpts);
            prop.searchAndReplaceProp("<NIMBUS_ADDRESS>", nimbusAddress);

            assertFalse("New properties should not match", compareExactMatch(prop.getPropertiesFile(), UMP_INSTALL_ALL_PROPERTIES));
        }

    }

}
