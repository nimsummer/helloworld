package com.nimsoft.automation.fileshare;

import com.nimsoft.automation.installer.InstallPaths;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

import java.io.FileNotFoundException;

/**
 * Created by schja33 on 1/21/14.
 */
@RunWith(Enclosed.class)
public class CopyBitsIT {
    public static class Valid_Parameters {



        @Test
        public void given_valid_7_5_build_nms_params_getInstaller() throws FileNotFoundException {
            //arrange
            String installType = "NMS";
            String version = "7.5";
            String build = "2014_01_22_12_05"; //should be 2014_01_22-12_05
            InstallPaths installPaths = new InstallPaths("nms", "8.00");

            //act
            CopyBits copyBits = new CopyBits(installPaths);

            //copyBits.getInstaller();

        }


    }

}
