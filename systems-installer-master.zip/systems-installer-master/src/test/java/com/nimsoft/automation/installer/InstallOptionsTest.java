package com.nimsoft.automation.installer;

import org.apache.commons.cli.ParseException;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/**
 * Created by lisdu02 on 1/21/14.
 */
@RunWith(Enclosed.class)
public class InstallOptionsTest {

    public static class Valid_Arguments {
        @Test
        public void uppercase_options() {
            String[] args = {
                "-install", "NMS",
                "-version", "7.10",
                "-db_type", "MSSQL",
                "-ip", "10.238.0.97",
            };

            // Assert
            try {
                InstallOptions opts = new InstallOptions(args);
            } catch (ParseException e) {
                assertTrue("uppercase options should not throw exception", false);
            }
        }

        @Test
        public void lowercase_options() {
            String[] args = {
                "-install", "nms",
                "-version", "7.10",
                "-db_type", "mssql",
                "-ip", "10.238.0.97",
            };
            try {
                InstallOptions opts = new InstallOptions(args);
            } catch (ParseException e) {
                assertTrue("lowercase options should not throw exception", false);
            }
        }

        @Test
        public void mixed_case_options() {
            String[] args = {
                "-install", "NmS",
                "-version", "7.10",
                "-db_type", "MsSqL",
                "-ip", "10.238.0.97",
            };
            try {
                InstallOptions opts = new InstallOptions(args);
            } catch (ParseException e) {
                assertTrue("mixed case options should not throw exception", false);
            }
        }
    }

    public static class Invalid_Arguments {

        @Rule
        public ExpectedException expectedException = ExpectedException.none();

        @Test
        public void missing_required_option_should_throw_ParseException() throws ParseException {
            // Arrange
            String[] args = {
                "-install", "nms"
            };
            // Act
            expectedException.expect(ParseException.class);
            // Assert
            InstallOptions opts = new InstallOptions(args);
        }

        @Test
        public void unrecognized_install_type_should_throw_ParseException() throws ParseException {
            String[] args = {
                "-install", "NMMMMMSSSSSS",
                "-version", "7.10",
                "-db_type", "mssql",
                "-ip", "10.238.0.97",
            };
            // Act
            expectedException.expect(ParseException.class);
            // Assert
            InstallOptions opts = new InstallOptions(args);
        }

        @Test
        public void unrecognized_version_should_throw_ParseException() throws ParseException {
            String[] args = {
                "-install", "nms",
                "-version", "7.1.0.1.1.2.3",
                "-db_type", "mssql",
                "-ip", "10.238.0.97",
            };
            // Act
            expectedException.expect(ParseException.class);
            // Assert
            InstallOptions opts = new InstallOptions(args);
        }

        @Test
        public void unrecognized_db_type_should_throw_ParseException() throws ParseException {
            String[] args = {
                "-install", "nms",
                "-version", "7.10",
                "-db_type", "OracleMyMicrosoftSqlServer",
                "-ip", "10.238.0.97",
            };
            // Act
            expectedException.expect(ParseException.class);
            // Assert
            InstallOptions opts = new InstallOptions(args);
        }

        @Test
        public void badly_formatted_ip_should_throw_ParseException() throws ParseException {
            String[] args = {
                "-install", "nms",
                "-version", "7.10",
                "-db_type", "mssql",
                "-ip", "10",
            };
            // Act
            expectedException.expect(ParseException.class);
            // Assert
            InstallOptions opts = new InstallOptions(args);
        }

    }
}
