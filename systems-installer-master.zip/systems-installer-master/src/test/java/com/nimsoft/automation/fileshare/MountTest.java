package com.nimsoft.automation.fileshare;

import com.nimsoft.automation.utils.OS;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

import java.io.FileNotFoundException;

import static org.junit.Assert.*;

/**
 * Created by schja33 on 1/23/14.
 */
@RunWith(Enclosed.class)
public class MountTest {
    public static class ValidParameters {

            @Test
            public void valid_setDrive () {
                if (OS.isWindows()) {
                    //arrange
                    String fullDir = "i:\\NimBUS-install\\NMS\\7.1\\nmserver_7.1-GA\\windows\\NoVM\\installNMS.exe";
                    //act
                    Mount mount = new Mount(fullDir);
                    //assert

                    assertEquals("Should return i: for the correct drive", "i:", mount.setDrive());
                }

        }
            @Test
            public void valid_unix_setDrive () {
                if (OS.isWindows()) {
                    //arrange
                    String fullDir = "/mnt/vg_main/vol01/QA/NimBUS-install/NMS/7.1/nmserver_7.1-GA/windows/NoVM/installNMS.exe";
                    //act
                    Mount mount = new Mount(fullDir);
                    //assert
                    assertEquals("Should return i: for the correct drive", "/mnt/vg_main/vol01/QA/", mount.setDrive());
                }

        }
            @Test
            public void valid_mountFileshare ()throws FileNotFoundException {
                if (OS.isWindows()) {
                    //arrange
                    String fullDir = "i:\\NimBUS-install\\NMS\\7.1\\nmserver_7.1-GA\\windows\\NoVM\\installNMS.exe";
                    //act
                    Mount mount = new Mount(fullDir);
                    //assert
                    assertEquals("Should return i: for the correct drive", 0, mount.mountFileshare());
                }

        }
            @Test
            public void valid_unmountFileshare ()throws FileNotFoundException {
                if (OS.isWindows()) {
                    //arrange
                    String fullDir = "i:\\NimBUS-install\\NMS\\7.1\\nmserver_7.1-GA\\windows\\NoVM\\installNMS.exe";
                    //act
                    Mount mount = new Mount(fullDir);
                    //assert
                    assertEquals("Should return i: for the correct drive", 0, mount.unmountFileshare());
                }

        }

    }
}
