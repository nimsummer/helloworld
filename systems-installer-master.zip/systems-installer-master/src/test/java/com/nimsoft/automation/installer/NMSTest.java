package com.nimsoft.automation.installer;

import com.nimsoft.automation.utils.Props;

import org.apache.commons.cli.ParseException;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertEquals;

import java.io.*;
import java.net.UnknownHostException;
import java.util.Map;

/**
* Created by dustinlish on 1/19/14.
*/
@RunWith(Enclosed.class)
public class NMSTest {

    public static class Generate_Properties_Files {
        private NimsoftInstall nimInstall;

        @Before
        public void arrange() {
        }

        private void cleanUp(Props prop) {
            prop.cleanUp();
        }

        @Test
        public void given_nms_generate_default_props() throws ParseException, FileNotFoundException, UnknownHostException {
            // Arrange
            // NMS Defaults
            String NMSDOMAIN = "10_238_0_97_domain";
            String NMSHUB = "10_238_0_97_hub";
            String NMSNETWORKIP = "10.238.0.97";
            String NMS_PASSWORD = "t3sti9";
            String NIM_USER = "administrator";
            String NIMDBCREATE = "true";
            String NMS_PROBE_PORT = "48000";

            String[] args = {
                "-install", "nms",
                "-version", "7.10",
                "-db_type", "mssql",
                "-ip", "10.238.0.97",
            };
            InstallOptions opts = new InstallOptions(args);
            Map<String, String> optsMap = opts.getOptionsMap();
            nimInstall = new NMS(optsMap.get("install"), optsMap.get("ip"), optsMap.get("db_type"), optsMap.get("version"));

            // Act
            nimInstall.loadProps(optsMap, null);

            // Assert
            // NMS Defaults
            assertEquals("Default NMSDOMAIN should be " + NMSDOMAIN,           NMSDOMAIN,      nimInstall.getProp("NMSDOMAIN"));
            assertEquals("Default NMSHUB should be " + NMSHUB,                 NMSHUB,         nimInstall.getProp("NMSHUB"));
            assertEquals("Default NMSNETWORKIP should be " + NMSNETWORKIP,     NMSNETWORKIP,   nimInstall.getProp("NMSNETWORKIP"));
            assertEquals("Default NMS_PASSWORD should be " + NMS_PASSWORD,     NMS_PASSWORD,   nimInstall.getProp("NMS_PASSWORD"));
            assertEquals("Default NIM_USER should be " + NIM_USER,             NIM_USER,       nimInstall.getProp("NIM_USER"));
            assertEquals("Default NIMDBCREATE should be " + NIMDBCREATE,       NIMDBCREATE,    nimInstall.getProp("NIMDBCREATE"));
            assertEquals("Default NMS_PROBE_PORT should be " + NMS_PROBE_PORT, NMS_PROBE_PORT, nimInstall.getProp("NMS_PROBE_PORT"));

            cleanUp(nimInstall.getProp());
        }

        @Test
        public void given_nms_password_generate_props() throws ParseException, FileNotFoundException, UnknownHostException {
            // Arrange
            // NMS Defaults
            String NMSDOMAIN = "10_238_0_97_domain";
            String NMSHUB = "10_238_0_97_hub";
            String NMSNETWORKIP = "10.238.0.97";
            String NMS_PASSWORD = "custom_password";
            String NIM_USER = "administrator";
            String NIMDBCREATE = "true";
            String NMS_PROBE_PORT = "48000";

            String[] args = {
                "-install", "nms",
                "-version", "7.10",
                "-db_type", "mssql",
                "-ip",       "10.238.0.97",
                "-password", NMS_PASSWORD,
            };
            InstallOptions opts = new InstallOptions(args);
            Map<String, String> optsMap = opts.getOptionsMap();
            nimInstall = new NMS(optsMap.get("install"), optsMap.get("ip"), optsMap.get("db_type"), optsMap.get("version"));

            // Act
            nimInstall.loadProps(optsMap, null);

            // Assert
            // NMS Defaults
            assertEquals("Default NMSDOMAIN should be " + NMSDOMAIN,           NMSDOMAIN,      nimInstall.getProp("NMSDOMAIN"));
            assertEquals("Default NMSHUB should be " + NMSHUB,                 NMSHUB,         nimInstall.getProp("NMSHUB"));
            assertEquals("Default NMSNETWORKIP should be " + NMSNETWORKIP,     NMSNETWORKIP,   nimInstall.getProp("NMSNETWORKIP"));
            assertEquals("Default NMS_PASSWORD should be " + NMS_PASSWORD,     NMS_PASSWORD,   nimInstall.getProp("NMS_PASSWORD"));
            assertEquals("Default NIM_USER should be " + NIM_USER,             NIM_USER,       nimInstall.getProp("NIM_USER"));
            assertEquals("Default NIMDBCREATE should be " + NIMDBCREATE,       NIMDBCREATE,    nimInstall.getProp("NIMDBCREATE"));
            assertEquals("Default NMS_PROBE_PORT should be " + NMS_PROBE_PORT, NMS_PROBE_PORT, nimInstall.getProp("NMS_PROBE_PORT"));

            cleanUp(nimInstall.getProp());
        }

        @Test
        public void given_nms_mssql_install_generate_default_props() throws IOException, ParseException {
            // Arrange
            // DB Defaults
            String DB_SERVER = "10.238.32.104";
            String DB_ADMIN_PASSWORD = "t3sti9";
            String NIMDBTYPE = "mssql";
            String DB_PORT = "1433";
            String DB_ADMIN_USER = "sa";
            String NIMDBNAME = "auto_10_238_0_97";

            String[] args = {
                "-install", "nms",
                "-version", "7.10",
                "-db_type", "mssql",
                "-ip", "10.238.0.97",
            };
            InstallOptions opts = new InstallOptions(args);
            Map<String, String> optsMap = opts.getOptionsMap();
            nimInstall = new NMS(optsMap.get("install"), optsMap.get("ip"), optsMap.get("db_type"), optsMap.get("version"));

            // Act
            nimInstall.loadProps(optsMap, null);

            // Assert
            // MYSQL Defaults
            assertEquals("Default DB_SERVER should be " + DB_SERVER,                 DB_SERVER,         nimInstall.getProp("DB_SERVER"));
            assertEquals("Default DB_ADMIN_PASSWORD should be " + DB_ADMIN_PASSWORD, DB_ADMIN_PASSWORD, nimInstall.getProp("DB_ADMIN_PASSWORD"));
            assertEquals("Default NIMDBTYPE should be " + NIMDBTYPE,                 NIMDBTYPE,         nimInstall.getProp("NIMDBTYPE"));
            assertEquals("Default DB_PORT should be " + DB_PORT,                     DB_PORT,           nimInstall.getProp("DB_PORT"));
            assertEquals("Default DB_ADMIN_USER should be " + DB_ADMIN_USER,         DB_ADMIN_USER,     nimInstall.getProp("DB_ADMIN_USER"));
            assertEquals("Default NIMDBNAME should be " + NIMDBNAME,                 NIMDBNAME,         nimInstall.getProp("NIMDBNAME"));
            cleanUp(nimInstall.getProp());
        }

        @Test
        public void given_nms_mysql_install_generate_default_props() throws IOException, ParseException {
            // DB Defaults
            String DB_SERVER = "10.238.32.82";
            String DB_ADMIN_PASSWORD = "t3sti9";
            String NIMDBTYPE = "mysql";
            String DB_PORT = "3306";
            String DB_ADMIN_USER = "root";
            String NIMDBNAME = "auto_10_238_0_97";

            String[] args = {
                "-install", "nms",
                "-version", "7.10",
                "-db_type", "mysql",
                "-ip", "10.238.0.97",
            };
            InstallOptions opts = new InstallOptions(args);
            Map<String, String> optsMap = opts.getOptionsMap();
            nimInstall = new NMS(optsMap.get("install"), optsMap.get("ip"), optsMap.get("db_type"), optsMap.get("version"));

            // Act
            nimInstall.loadProps(optsMap, null);

            // Assert
            // MYSQL Defaults
            assertEquals("Default DB_SERVER should be " + DB_SERVER,                 DB_SERVER,         nimInstall.getProp("DB_SERVER"));
            assertEquals("Default DB_ADMIN_PASSWORD should be " + DB_ADMIN_PASSWORD, DB_ADMIN_PASSWORD, nimInstall.getProp("DB_ADMIN_PASSWORD"));
            assertEquals("Default NIMDBTYPE should be " + NIMDBTYPE,                 NIMDBTYPE,         nimInstall.getProp("NIMDBTYPE"));
            assertEquals("Default DB_PORT should be " + DB_PORT,                     DB_PORT,           nimInstall.getProp("DB_PORT"));
            assertEquals("Default DB_ADMIN_USER should be " + DB_ADMIN_USER,         DB_ADMIN_USER,     nimInstall.getProp("DB_ADMIN_USER"));
            assertEquals("Default NIMDBNAME should be " + NIMDBNAME,                 NIMDBNAME,         nimInstall.getProp("NIMDBNAME"));
            cleanUp(nimInstall.getProp());
        }

        @Test
        public void given_nms_oracle_install_generate_default_props() throws IOException, ParseException {
            // Arrange
            // DB Defaults
            String DB_SERVER = "10.238.32.101";
            String DB_ADMIN_PASSWORD = "t3sti9";
            String NIMDBTYPE = "oracle";
            String DB_PORT = "1521";
            String NIMDB_USER = "auto_10_238_0_97";
            String NIMDBNAME = "auto_10_238_0_97";
            String ORASID = "orcl";

            String[] args = {
                "-install", "nms",
                "-version", "7.10",
                "-db_type", "oracle",
                "-ip", "10.238.0.97",
                "-orasid", ORASID
            };

            InstallOptions opts = new InstallOptions(args);
            Map<String, String> optsMap = opts.getOptionsMap();
            nimInstall = new NMS(optsMap.get("install"), optsMap.get("ip"), optsMap.get("db_type"), optsMap.get("version"));

            // Act
            nimInstall.loadProps(optsMap, null);

            // Assert
            // MYSQL Defaults
            assertEquals("Default DB_SERVER should be " + DB_SERVER,                 DB_SERVER,         nimInstall.getProp("DB_SERVER"));
            assertEquals("Default DB_ADMIN_PASSWORD should be " + DB_ADMIN_PASSWORD, DB_ADMIN_PASSWORD, nimInstall.getProp("DB_ADMIN_PASSWORD"));
            assertEquals("Default NIMDBTYPE should be " + NIMDBTYPE,                 NIMDBTYPE,         nimInstall.getProp("NIMDBTYPE"));
            assertEquals("Default DB_PORT should be " + DB_PORT,                     DB_PORT,           nimInstall.getProp("DB_PORT"));
            assertEquals("Default NIMDB_USER should be " + NIMDB_USER,               NIMDB_USER,        nimInstall.getProp("NIMDB_USER"));
            assertEquals("Default NIMDBNAME should be " + NIMDBNAME,                 NIMDBNAME,         nimInstall.getProp("NIMDBNAME"));
            assertEquals("Default ORASID should be " + ORASID,                       ORASID,            nimInstall.getProp("ORASID"));
            cleanUp(nimInstall.getProp());
        }

        @Test
        public void given_nms_oracle12_install_generate_default_props() throws IOException, ParseException {
            // Arrange
            // DB Defaults
            String DB_SERVER = "10.238.32.45";
            String DB_ADMIN_PASSWD = "t3sti9";
            String DB_NORMALIZED_PROVIDER_NAME = "oracle";
            String DB_PORT = "1521";
            String DB_TABLESPACENAME = "auto_10_238_0_97";
            String DB_NAME = "auto_10_238_0_97";
            String DB_SERVICENAME = "pdborcl";

            String[] args = {
                    "-install", "nms",
                    "-version", "8.30",
                    "-db_type", "oracle",
                    "-ip", "10.238.0.97",
                    "-db_version", "oracle_12"
            };
            InstallOptions opts = new InstallOptions(args);
            Map<String, String> optsMap = opts.getOptionsMap();
            nimInstall = new NMS(optsMap.get("install"), optsMap.get("ip"), optsMap.get("db_type"), optsMap.get("version"));

            // Act
            nimInstall.loadProps(optsMap, null);
            // Oracle Defaults
            assertEquals("Default DB_ADMIN_PASSWD should be " +     DB_ADMIN_PASSWD, DB_ADMIN_PASSWD, nimInstall.getProp("DB_ADMIN_PASSWD"));
            assertEquals("Default DB_SERVER should be " +     DB_SERVER, DB_SERVER, nimInstall.getProp("DB_SERVER"));
            assertEquals("Default DB_NORMALIZED_PROVIDER_NAME should be " + DB_NORMALIZED_PROVIDER_NAME,DB_NORMALIZED_PROVIDER_NAME,nimInstall.getProp("DB_NORMALIZED_PROVIDER_NAME"));
            assertEquals("Default DB_PORT should be " +         DB_PORT, DB_PORT,nimInstall.getProp("DB_PORT"));
            assertEquals("Default DB_TABLESPACENAME should be " +   DB_TABLESPACENAME, DB_TABLESPACENAME, nimInstall.getProp("DB_TABLESPACENAME"));
            assertEquals("Default DB_NAME should be " +         DB_NAME, DB_NAME, nimInstall.getProp("DB_NAME"));
            assertEquals("Default DB_SERVICENAME should be " +  DB_SERVICENAME, DB_SERVICENAME, nimInstall.getProp("DB_SERVICENAME"));
            nimInstall.listProps();
            cleanUp(nimInstall.getProp());
        }

        @Test
        public void given_nms_oracle_8_3_install_generate_default_props() throws IOException, ParseException {
            // Arrange
            // DB Defaults
            String DB_SERVER = "10.238.32.101";
            String DB_ADMIN_PASSWD = "t3sti9";
            String DB_NORMALIZED_PROVIDER_NAME = "oracle";
            String DB_PORT = "1521";
            String DB_TABLESPACENAME = "auto_10_238_0_97";
            String DB_NAME = "auto_10_238_0_97";
            String DB_SERVICENAME = "orcl";
            String DB_VERSION = "oracle_11";

            String[] args = {
                    "-install", "nms",
                    "-version", "8.30",
                    "-db_type", "oracle",
                    "-ip", "10.238.0.97",
                    "-orasid", DB_SERVICENAME
            };

            InstallOptions opts = new InstallOptions(args);
            Map<String, String> optsMap = opts.getOptionsMap();
            nimInstall = new NMS(optsMap.get("install"), optsMap.get("ip"), optsMap.get("db_type"), optsMap.get("version"));

            // Act
            nimInstall.loadProps(optsMap, null);
            // Oracle Defaults
            assertEquals("Default DB_ADMIN_PASSWD should be " +     DB_ADMIN_PASSWD, DB_ADMIN_PASSWD,nimInstall.getProp("DB_ADMIN_PASSWD"));
            assertEquals("Default DB_NORMALIZED_PROVIDER_NAME should be " + DB_NORMALIZED_PROVIDER_NAME, DB_NORMALIZED_PROVIDER_NAME, nimInstall.getProp("DB_NORMALIZED_PROVIDER_NAME"));
            assertEquals("Default DB_PORT should be " +         DB_PORT, DB_PORT,  nimInstall.getProp("DB_PORT"));
            assertEquals("Default DB_TABLESPACENAME should be " +   DB_TABLESPACENAME, DB_TABLESPACENAME, nimInstall.getProp("DB_TABLESPACENAME"));
            assertEquals("Default DB_NAME should be " +         DB_NAME, DB_NAME, nimInstall.getProp("DB_NAME"));
            assertEquals("Default DB_SERVICENAME should be " +  DB_SERVICENAME,  DB_SERVICENAME,  nimInstall.getProp("DB_SERVICENAME"));
            assertEquals("Default DB_VERSION should be " + DB_VERSION, DB_VERSION, nimInstall.getProp("DB_VERSION"));
            cleanUp(nimInstall.getProp());
        }



        @Test
        public void given_mssql_command_line_args_set_props() throws ParseException, FileNotFoundException, UnknownHostException {
            // NMS Defaults
            String NMSDOMAIN = "DustinsDom";
            String NMSHUB = "DustinsHub";
            String NMSNETWORKIP = "10.238.0.97";
            String NMS_PASSWORD = "t3sti9";
            String NIM_USER = "administrator";
            String NIMDBCREATE = "true";
            String NMS_PROBE_PORT = "48000";

            // DB Defaults
            String DB_SERVER = "123.321.1.2";
            String DB_ADMIN_PASSWORD = "t3sti9";
            String NIMDBTYPE = "mysql";
            String DB_PORT = "9876";
            String DB_ADMIN_USER = "toor";
            String NIMDBNAME = "DustinsDbName";

            String[] args = {
                "-install",   "nms",
                "-version",   "7.10",
                "-db_type",   NIMDBTYPE,
                "-ip",        NMSNETWORKIP,
                "-hub",       NMSHUB,
                "-domain",    NMSDOMAIN,
                "-db_pass",   DB_ADMIN_PASSWORD,
                "-db_port",   DB_PORT,
                "-db_server", DB_SERVER,
                "-db_user",   DB_ADMIN_USER,
                "-db_name",   NIMDBNAME
            };
            InstallOptions opts = new InstallOptions(args);
            Map<String, String> optsMap = opts.getOptionsMap();
            nimInstall = new NMS(optsMap.get("install"), optsMap.get("ip"), optsMap.get("db_type"), optsMap.get("version"));

            // Act
            nimInstall.loadProps(optsMap, null);

            // Assert
            // NMS Defaults
            assertEquals("Default NMSDOMAIN should be " + NMSDOMAIN,       NMSDOMAIN,    nimInstall.getProp("NMSDOMAIN"));
            assertEquals("Default NMSHUB should be " + NMSHUB,             NMSHUB,       nimInstall.getProp("NMSHUB"));
            assertEquals("Default NMSNETWORKIP should be " + NMSNETWORKIP, NMSNETWORKIP, nimInstall.getProp("NMSNETWORKIP"));
            assertEquals("Default NMS_PASSWORD should be " + NMS_PASSWORD, NMS_PASSWORD, nimInstall.getProp("NMS_PASSWORD"));
            assertEquals("Default NIM_USER should be " + NIM_USER,         NIM_USER,     nimInstall.getProp("NIM_USER"));
            assertEquals("Default NIMDBCREATE should be " + NIMDBCREATE,   NIMDBCREATE,  nimInstall.getProp("NIMDBCREATE"));

            // MYSQL Defaults
            assertEquals("Default DB_SERVER should be " + DB_SERVER,                 DB_SERVER,         nimInstall.getProp("DB_SERVER"));
            assertEquals("Default DB_ADMIN_PASSWORD should be " + DB_ADMIN_PASSWORD, DB_ADMIN_PASSWORD, nimInstall.getProp("DB_ADMIN_PASSWORD"));
            assertEquals("Default NIMDBTYPE should be " + NIMDBTYPE,                 NIMDBTYPE,         nimInstall.getProp("NIMDBTYPE"));
            assertEquals("Default NMS_PROBE_PORT should be " + NMS_PROBE_PORT,       NMS_PROBE_PORT,    nimInstall.getProp("NMS_PROBE_PORT"));
            assertEquals("Default DB_PORT should be " + DB_PORT,                     DB_PORT,           nimInstall.getProp("DB_PORT"));
            assertEquals("Default DB_ADMIN_USER should be " + DB_ADMIN_USER,         DB_ADMIN_USER,     nimInstall.getProp("DB_ADMIN_USER"));
            assertEquals("Default NIMDBNAME should be " + NIMDBNAME,                 NIMDBNAME,         nimInstall.getProp("NIMDBNAME"));
            cleanUp(nimInstall.getProp());
        }

        @Test
        public void findIPTest(){
            NMS nmsTest = new NMS("NMS", "auto", "mssql", "8.4");
            System.out.println(nmsTest.findIP());
        }
    }
}
