package com.nimsoft.automation.database;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Created by lisdu02 on 1/30/14.
 */
@RunWith(Enclosed.class)
public class DBOperationsIT {

    private static final String TEST_USER = "TESTUSER";

    public static void createDb(DBConnectionInfo info) {
        String connectionUrl;
        Statement statement;
        Connection conn;
        try {
            if (info.getDbType().toLowerCase().equals("oracle")) {
                connectionUrl = info.getJdbcUrl() + info.getDbServer() + ":" + info.getDbPort() + ":ORCLAUTO";
                conn = DriverManager.getConnection(connectionUrl, "SYS AS SYSDBA", info.getDbPassword());
                statement = conn.createStatement();

                statement.executeUpdate("CREATE TABLESPACE " + info.getDbName() + " DATAFILE '" + info.getDbName()+".dbf" + "' size 100m autoextend on next 100m maxsize 1000m");
                statement.executeUpdate("CREATE USER " + TEST_USER + " IDENTIFIED BY t3sti9 DEFAULT TABLESPACE " + info.getDbName());
                statement.executeUpdate("grant all privileges to " + TEST_USER);
            }

            else {
                connectionUrl = info.getJdbcUrl() + info.getDbServer() + ":" + info.getDbPort();
                conn = DriverManager.getConnection(connectionUrl, info.getDbUsername(), info.getDbPassword());
                statement = conn.createStatement();
                statement.executeUpdate("CREATE DATABASE " + info.getDbName());
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void createTable(DBConnectionInfo info, String table) {
        String connectionUrl;
        Statement statement;
        Connection conn;
        try {
            if (info.getDbType().toLowerCase().equals("oracle")) {
                connectionUrl = info.getJdbcUrl() + info.getDbServer() + ":" + info.getDbPort() + ":ORCLAUTO";
                conn = DriverManager.getConnection(connectionUrl, "SYS AS SYSDBA", info.getDbPassword());
                statement = conn.createStatement();
                System.out.println("CREATE TABLE " + info.getDbName() + "." + table + " (STRINGCOL VARCHAR(20), INTCOL NUMBER)");
                statement.executeUpdate("CREATE TABLE " + info.getDbName() + "." + table.toUpperCase() + " (STRINGCOL VARCHAR(20), INTCOL NUMBER)");
            } else if (info.getDbType().toLowerCase().equals("mssql")) {
                connectionUrl = info.getJdbcUrl() + info.getDbServer() + ":" + info.getDbPort();
                conn = DriverManager.getConnection(connectionUrl, info.getDbUsername(), info.getDbPassword());
                statement = conn.createStatement();
                statement.executeUpdate("USE " + info.getDbName());
                statement.executeUpdate("CREATE TABLE " + table + " (STRINGCOL   VARCHAR(255), INTCOL    int);");
            } else {
                connectionUrl = info.getJdbcUrl() + info.getDbServer() + ":" + info.getDbPort();
                conn = DriverManager.getConnection(connectionUrl, info.getDbUsername(), info.getDbPassword());
                statement = conn.createStatement();
                statement.executeUpdate("CREATE TABLE " + info.getDbName() + "." + table + " (STRINGCOL   VARCHAR(255), INTCOL    int);" );
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void dropDb(DBConnectionInfo info) {
        String connectionUrl;
        Statement statement;
        Connection conn;
        try {
            if (info.getDbType().toLowerCase().equals("oracle")) {
                connectionUrl = info.getJdbcUrl() + info.getDbServer() + ":" + info.getDbPort() + ":DEORCL";
                conn = DriverManager.getConnection(connectionUrl, "SYS AS SYSDBA", info.getDbPassword());
                statement = conn.createStatement();

                statement.executeUpdate("DROP TABLESPACE " + info.getDbName() + " INCLUDING CONTENTS AND DATAFILES");
                statement.executeUpdate("DROP USER " + TEST_USER + " CASCADE");
            } else {
                connectionUrl = info.getJdbcUrl() + info.getDbServer() + ":" + info.getDbPort();
                conn = DriverManager.getConnection(connectionUrl, info.getDbUsername(), info.getDbPassword());
                statement = conn.createStatement();
                statement.executeUpdate("DROP DATABASE " + info.getDbName());
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static class MSSQL_Tests {
        private DBConnection connection;
        private DBConnectionInfo connectionInfo;
        private DBOperations dbOps;

        private String dbType;
        private String dbUsername;
        private String dbPassword;
        private String dbServer;
        private String dbName;
        private String dbPort;

        @Before
        public void arrange() {
            dbOps = new DBOperations();
            dbType = "mssql";
            dbServer = "10.238.32.104";
            dbUsername = "sa";
            dbPassword = "t3sti9";
            dbPort = "1433";
        }

        @After
        public void tearDown() throws SQLException, InterruptedException {
            if (connection.getConnection() != null) {
                if (dbOps.dbExists(connection))
                    dbOps.dropDb(connection);
                connection.disconnect();
            }
        }

        @Test
        public void mssql_create_dbExists() throws SQLException {
            dbName = "InstallerTestDb";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            createDb(connectionInfo);

            try {
                connection.connect();
                assertTrue("MSSQL database should exist: " + connectionInfo.toString(), dbOps.dbExists(connection));
            } catch (Exception e) {
                e.printStackTrace();
                assertTrue("MSSQL database should exist: " + connectionInfo.toString(), false);
            }

            dropDb(connectionInfo);
        }

        @Test
        public void mssql_insert() throws SQLException, IOException, ClassNotFoundException {
            dbName = "InstallerTestDb";
            Map<String, String> values = new HashMap<String, String>();
            values.put("STRINGCOL", "STRINGVALUE");
            values.put("INTCOL", "1234");
            String table = "newTable";


            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            connection.connect();
            createDb(connectionInfo);
            createTable(connectionInfo, table);

            try {
                dbOps.insert(connection,table, values);
            } catch (SQLException e) {
                e.printStackTrace();
                fail();
            }
            assertTrue("MSSQL insert worked correctly: " + "", true);

        }

        @Test
        public void mssql_selectStatement() throws SQLException, IOException, ClassNotFoundException {
            dbName = "InstallerTestDb";
            Map<String, String> values = new HashMap<String, String>();
            values.put("STRINGCOL", "STRINGVALUE");
            values.put("INTCOL", "1234");

            ArrayList<String> selectColumns = new ArrayList<String>();
            selectColumns.add("*");

            String table = "newTable";


            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            connection.connect();
            createDb(connectionInfo);
            createTable(connectionInfo, table);
            dbOps.insert(connection,table,values);
            try {
                dbOps.selectStatement(connection, selectColumns, table);
            } catch (SQLException e) {
                e.printStackTrace();
                fail();
            }

            assertTrue("MSSQL select worked correctly: " + "", true);

        }

        @Test
        public void mssql_multiSelectStatement() throws SQLException, IOException, ClassNotFoundException {
            dbName = "InstallerTestDb";
            Map<String, String> values = new HashMap<String, String>();
            values.put("STRINGCOL", "STRINGVALUE");
            values.put("INTCOL", "1234");

            ArrayList<String> selectColumns = new ArrayList<String>();
            selectColumns.add("STRINGCOL");
            selectColumns.add("INTCOL");

            String table = "newTable";


            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            connection.connect();
            createDb(connectionInfo);
            createTable(connectionInfo, table);
            dbOps.insert(connection,table,values);
            try {
                dbOps.selectStatement(connection, selectColumns, table);
            } catch (SQLException e) {
                e.printStackTrace();
                fail();
            }

            assertTrue("MSSQL select worked correctly: " + "", true);

        }


        @Test
        public void mssql_dbDrop() throws SQLException, InterruptedException, IOException {
            dbName = "InstallerTestDb";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            createDb(connectionInfo);

            try {
                connection.connect();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            dbOps.dropDb(connection);
            assertFalse("MSSQL should not exist: " + connectionInfo.toString(), dbOps.dbExists(connection));
        }

        @Test
        public void mssql_dbDrop_defaults_dbName() throws SQLException, InterruptedException, IOException {
            dbName = "InstallerTestDb";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            createDb(connectionInfo);

            try {
                connection.connect();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            dbOps.dropDb(connection);
            assertFalse("MSSQL should not exist: " + connectionInfo.toString(), dbOps.dbExists(connection));
        }
    }

    public static class MySQL_Tests {
        private DBConnection connection;
        private DBConnectionInfo connectionInfo;
        private DBOperations dbOps;

        private String dbType;
        private String dbUsername;
        private String dbPassword;
        private String dbServer;
        private String dbName;
        private String dbPort;

        @Before
        public void arrange() {
            dbOps = new DBOperations();
            dbType = "mysql";
            dbServer = "10.238.32.82";
            dbUsername = "root";
            dbPassword = "t3sti9";
            dbPort = "3306";
        }

        @After
        public void tearDown() throws SQLException, InterruptedException {
            if (connection.getConnection() != null) {
                if (dbOps.dbExists(connection))
                    dbOps.dropDb(connection);
                connection.disconnect();
            }
        }

        @Test
        public void mysql_create_dbExists() throws SQLException {
            dbName = "InstallerTestDb";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            createDb(connectionInfo);

            try {
                connection.connect();
                assertTrue("MySQL database should exist: " + connectionInfo.toString(), dbOps.dbExists(connection));
            } catch (Exception e) {
                e.printStackTrace();
                assertTrue("MySQL database should exist: " + connectionInfo.toString(), false);
            }

            dropDb(connectionInfo);
        }

        @Test
        public void mysql_dbDrop() throws SQLException, InterruptedException, IOException {
            dbName = "InstallerTestDb";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            createDb(connectionInfo);

            try {
                connection.connect();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            dbOps.dropDb(connection);
            assertFalse("MySQL DB should not exist: " + connectionInfo.toString(), dbOps.dbExists(connection));
        }

        @Test
        public void mysql_dbDrop_default_dbName() throws SQLException, InterruptedException, IOException {
            dbName = "InstallerTestDb";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            createDb(connectionInfo);

            try {
                connection.connect();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            dbOps.dropDb(connection);
            assertFalse("MySQL DB should not exist: " + connectionInfo.toString(), dbOps.dbExists(connection));
        }

        @Test
        public void mysql_insert() throws SQLException, IOException, ClassNotFoundException {
            dbName = "InstallerTestDb";
            Map<String, String> values = new HashMap<String, String>();
            values.put("STRINGCOL", "STRINGVALUE");
            values.put("INTCOL", "1234");
            String table = "newTable";


            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            connection.connect();
            createDb(connectionInfo);
            createTable(connectionInfo, table);

            try {
                dbOps.insert(connection,table, values);
            } catch (SQLException e) {
                e.printStackTrace();
                fail();
            }
            assertTrue("MYSQL insert worked correctly: " + "", true);

        }

        @Test
        public void mysql_multiSelectStatement() throws SQLException, IOException, ClassNotFoundException {
            dbName = "InstallerTestDb";
            Map<String, String> values = new HashMap<String, String>();
            values.put("STRINGCOL", "STRINGVALUE");
            values.put("INTCOL", "1234");

            ArrayList<String> selectColumns = new ArrayList<String>();
            selectColumns.add("STRINGCOL");
            selectColumns.add("INTCOL");

            String table = "newTable";


            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            connection.connect();
            createDb(connectionInfo);
            createTable(connectionInfo, table);
            dbOps.insert(connection,table,values);
            try {
                dbOps.selectStatement(connection, selectColumns, table);
            } catch (SQLException e) {
                e.printStackTrace();
                fail();
            }

            assertTrue("MYSQL select worked correctly: " + "", true);

        }

        @Test
        public void mysql_selectStatement() throws SQLException, IOException, ClassNotFoundException {
            dbName = "InstallerTestDb";
            Map<String, String> values = new HashMap<String, String>();
            values.put("STRINGCOL", "STRINGVALUE");
            values.put("INTCOL", "1234");

            ArrayList<String> selectColumns = new ArrayList<String>();
            selectColumns.add("*");

            String table = "newTable";


            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            connection.connect();
            createDb(connectionInfo);
            createTable(connectionInfo, table);
            dbOps.insert(connection,table,values);
            try {
                dbOps.selectStatement(connection, selectColumns, table);
            } catch (SQLException e) {
                e.printStackTrace();
                fail();
            }

            assertTrue("MYSQL select worked correctly: " + "", true);

        }

    }

    public static class Oracle_Tests {
        private DBConnection connection;
        private DBConnectionInfo connectionInfo;
        private DBOperations dbOps;

        private String dbType;
        private String dbUsername;
        private String dbPassword;
        private String dbServer;
        private String dbName;
        private String dbPort;

        @Before
        public void arrange() {
            dbOps = new DBOperations();
            dbType = "oracle";
            dbServer = "10.238.32.101";
            dbUsername = TEST_USER;
            dbPassword = "t3sti9";
            dbPort = "1521";
        }

        @After
        public void tearDown() throws SQLException, InterruptedException {
            if (connection.getConnection() != null) {
                if (dbOps.dbExists(connection))
                    dbOps.dropDb(connection);
                connection.disconnect();
            }
        }

        @Test
        public void oracle_create_dbExists() throws SQLException, InterruptedException, IOException {
            dbName = "InstallerTestDb";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connectionInfo.setOracleSID("ORCLAUTO");
            connection = new DBConnection(connectionInfo);
            System.out.println(connectionInfo.getConnectionURL());
            System.out.println(connectionInfo.toString());
            createDb(connectionInfo);

            try {
                connection.connect();
                assertTrue("Oracle database should exist: " + connectionInfo.toString(), dbOps.dbExists(connection));
            } catch (Exception e) {
                e.printStackTrace();
                assertTrue("Oracle database should exist: " + connectionInfo.toString(), false);
            }

            dbOps.dropDb(connection);
        }

        @Test
        public void oracle_dbExists_should_return_false() throws SQLException {
            dbName = "InstallerTestDb_should_not_exist";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connectionInfo.setOracleSID("ORCLAUTO");
            connection = new DBConnection(connectionInfo);

            try {
                connection.connect();
                assertFalse("Oracle database should NOT exist: " + connectionInfo.toString(), dbOps.dbExists(connection));
            } catch (Exception e) {
                e.printStackTrace();
                assertTrue("Oracle database should NOT exist: " + connectionInfo.toString(), false);
            }
        }

        @Test
        public void oracle_dbDrop() throws SQLException, InterruptedException, IOException {
            dbName = "InstallerTestDb";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connectionInfo.setOracleSID("ORCLAUTO");
            connection = new DBConnection(connectionInfo);
            createDb(connectionInfo);

            try {
                connection.connect();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            dbOps.dropDb(connection);
            assertTrue("Oracle DB should not exist: " + connectionInfo.toString(), !dbOps.dbExists(connection));
        }

        @Test
        public void oracle_insert() throws SQLException, IOException, ClassNotFoundException {
            dbName = "TESTUSER";
            Map<String, String> values = new HashMap<String, String>();
            values.put("STRINGCOL", "STRINGVALUE");
            values.put("INTCOL", "1234");
            String table = "newTable";


            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            connection.connect();
            createDb(connectionInfo);
            createTable(connectionInfo, table);

            try {
                dbOps.insert(connection,table, values);
            } catch (SQLException e) {
                e.printStackTrace();
                fail();
            }
            assertTrue("ORACLE insert worked correctly: " + "", true);

        }
        @Test
        public void oracle_selectStatement() throws SQLException, IOException, ClassNotFoundException {
            dbName = "TESTUSER";
            Map<String, String> values = new HashMap<String, String>();
            values.put("STRINGCOL", "STRINGVALUE");
            values.put("INTCOL", "1234");

            ArrayList<String> selectColumns = new ArrayList<String>();
            selectColumns.add("*");

            String table = "newTable";


            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            connection.connect();
            createDb(connectionInfo);
            createTable(connectionInfo, table);
            dbOps.insert(connection, table, values);
            try {
                dbOps.selectStatement(connection, selectColumns, table);
            } catch (SQLException e) {
                e.printStackTrace();
                fail();
            }

            assertTrue("Oracle select worked correctly: " + "", true);

        }

        @Test
        public void oracle_multiSelectStatement() throws SQLException, IOException, ClassNotFoundException {
            dbName = "TESTUSER";
            Map<String, String> values = new HashMap<String, String>();
            values.put("STRINGCOL", "STRINGVALUE");
            values.put("INTCOL", "1234");

            ArrayList<String> selectColumns = new ArrayList<String>();
            selectColumns.add("STRINGCOL");
            selectColumns.add("INTCOL");

            String table = "newTable";


            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connection = new DBConnection(connectionInfo);
            connection.connect();
            createDb(connectionInfo);
            createTable(connectionInfo, table);
            dbOps.insert(connection,table,values);
            try {
                dbOps.selectStatement(connection, selectColumns, table);
            } catch (SQLException e) {
                e.printStackTrace();
                fail();
            }

            assertTrue("Oracle select worked correctly: ", true);

        }

        @Test
        public void oracle_half_dbDrop() throws SQLException, InterruptedException, IOException {
            dbName = "InstallerTestDb";

            connectionInfo = new DBConnectionInfo(dbType, dbServer, dbName, dbUsername, dbPassword, dbPort);
            connectionInfo.setOracleSID("ORCLAUTO");
            connection = new DBConnection(connectionInfo);
            createDb(connectionInfo);

            try {
                connection.connect();
                Statement statement = connection.getConnection().createStatement();
                dbOps.closeConnections(connection, connection.getDbName());
                statement.executeUpdate("DROP TABLESPACE " + connection.getDbInfo().getDbName() + " INCLUDING CONTENTS AND DATAFILES");
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            dbOps.dropDb(connection);
            assertTrue("Oracle DB should not exist: " + connectionInfo.toString(), !dbOps.dbExists(connection));
        }
    }
}
