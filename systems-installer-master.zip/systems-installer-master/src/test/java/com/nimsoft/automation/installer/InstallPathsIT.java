package com.nimsoft.automation.installer;

import com.nimsoft.automation.utils.OS;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;


import java.io.FileNotFoundException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;


/**
 * Created by schja33 on 1/23/14.
 */
@RunWith(Enclosed.class)
public class InstallPathsIT {
    public static class Valid_Parameters {

        @Test
        public void given_valid_7_1_nms_params_getInstaller() throws FileNotFoundException {
            //arrange
            String installType = "NMS";
            String version = "7.1";

            //act
            InstallPaths installPaths = new InstallPaths(installType, version);

            //assert
            if (OS.isWindows())
                assertEquals("Integration of testing NMS 7.1 copy, return full path","i:\\NimBUS-install\\NMS\\7.1\\nmserver_7.1-GA\\Windows\\NoVM\\installNMS.exe", installPaths.getInstaller());
            else
                assertEquals("Intergration of testing NMS 7.1 copy, return full path", "/mnt/vg_main/vol01/QA/NimBUS-install/NMS/7.1/nmserver_7.1-GA/Linux/NoVM/installNMS.bin", installPaths.getInstaller());

        }

        @Test
        public void given_valid_7_5_current_nms_params_getInstaller() throws FileNotFoundException {
            //arrange
            String installType = "NMS";
            String version = "7.5";

            //act
            InstallPaths installPaths = new InstallPaths(installType, version);
            //installPaths.getDrive();

            //assert
            if (OS.isWindows())
                assertEquals("Integration of testing NMS 7.5 current copy, return 0","i:\\NimBUS-install\\NMS\\7.5\\nmserver_7.5-GA\\Windows\\NoVM\\installNMS.exe", installPaths.getInstaller());
            else
                assertEquals("Integration of testing NMS 7.5 current copy, return 0","/mnt/vg_main/vol01/QA/NimBUS-install/NMS/7.5/nmserver_7.5-GA/Linux/NoVM/installNMS.bin", installPaths.getInstaller());

        }

        @Test
        public void given_valid_7_5_build_nms_params_getInstaller() throws FileNotFoundException {
            //arrange
            String installType = "NMS";
            String version = "7.5";
            String build = "2014_01_22-12_05";
            Calendar cal = Calendar.getInstance();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            cal.add(Calendar.DATE,-1);
            String yesterdayDate = dateFormat.format(cal.getTime());

            //act
            InstallPaths installPaths = new InstallPaths(installType, version, build);

            //assert
            if (OS.isWindows())
                assertEquals("Integration of testing NMS 7.5 current copy, return 0","i:\\NimBUS-install\\NMS\\7.5\\nmserver_7.5-GA\\Windows\\NoVM\\installNMS.exe", installPaths.getInstaller());
            else
                assertEquals("Integration of testing NMS 7.5 current copy, return 0","/mnt/vg_main/vol01/QA/NimBUS-install/NMS/7.5/nmserver_7.5-GA/Linux/NoVM/installNMS.bin", installPaths.getInstaller());
        }




        //UMP TESTING
        @Test
        public void given_valid_7_1_ump_params_getInstaller() throws FileNotFoundException {
            //arrange
            String installType = "UMP";
            String version = "7.1";

            //act
            InstallPaths installPaths = new InstallPaths(installType, version);
            //installPaths.getDrive();

            //assert
            if (OS.isWindows())
                assertEquals("Integration of testing UMP 7.1 copy, return 0","i:\\NimBUS-install\\UMP\\7.1.0\\GA\\7.1.0-B\\installUMP.exe", installPaths.getInstaller());
            else
                assertEquals("Integration of testing UMP 7.1 copy, return 0","/mnt/vg_main/vol01/QA/NimBUS-install/UMP/7.1.0/GA/7.1.0-B/installUMP_linux.bin", installPaths.getInstaller());

        }

        @Test
        public void given_valid_7_5_current_ump_params_getInstaller() throws FileNotFoundException {
            //arrange
            String installType = "UMP";
            String version = "7.5";
            Calendar cal = Calendar.getInstance();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            cal.add(Calendar.DATE,-1);
            String yesterdayDate = dateFormat.format(cal.getTime());

            //act
            InstallPaths installPaths = new InstallPaths(installType, version);
            //installPaths.getDrive();

            //assert
            if (OS.isWindows())
                assertEquals("Integration of testing NMS 7.5 current copy, return 0","i:\\NimBUS-install\\UMP\\7.5.0\\GA\\7.5.0-B\\installUMP.exe", installPaths.getInstaller());
            else
                assertEquals("Integration of testing NMS 7.5 current copy, return 0","/mnt/vg_main/vol01/QA/NimBUS-install/UMP/7.5.0/GA/7.5.0-B/installUMP_linux.bin", installPaths.getInstaller());

        }

        @Test
        public void given_valid_7_5_build_ump_params_getInstaller() throws FileNotFoundException {
            //arrange
            String installType = "UMP";
            String version = "7.5";
            String build = "2014-01-15";

            //act
            InstallPaths installPaths = new InstallPaths(installType, version, build);

            //assert
            if (OS.isWindows())
                assertEquals("Integration of testing NMS 7.5 current copy, return 0","i:\\NimBUS-install\\UMP\\7.5.0\\GA\\7.5.0-B\\installUMP.exe", installPaths.getInstaller());
            else
                assertEquals("Integration of testing NMS 7.5 current copy, return 0","/mnt/vg_main/vol01/QA/NimBUS-install/UMP/7.5.0/GA/7.5.0-B/installUMP_linux.bin", installPaths.getInstaller());
        }

        //UR TESTING
        @Test
        public void given_valid_7_1_ur_params_getInstaller() throws FileNotFoundException {
            //arrange
            String installType = "UR";
            String version = "7.1";

            //act
            InstallPaths installPaths = new InstallPaths(installType, version);
            //installPaths.getDrive();

            //assert
            if (OS.isWindows())
                assertEquals("Integration of testing UMP 7.1 copy, return 0","i:\\NimBUS-install\\UR\\7.1.0\\GA\\7.1.0-B\\installUR.exe", installPaths.getInstaller());
            else
                assertEquals("Integration of testing UMP 7.1 copy, return 0","/mnt/vg_main/vol01/QA/NimBUS-install/UR/7.1.0/GA/7.1.0-B/installUR_linux.bin", installPaths.getInstaller());

        }

        @Test
        public void given_valid_7_5_current_ur_params_getInstaller() throws FileNotFoundException {
            //arrange
            String installType = "UR";
            String version = "7.5";
            Calendar cal = Calendar.getInstance();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            cal.add(Calendar.DATE,-1);
            String yesterdayDate = dateFormat.format(cal.getTime());

            //act
            InstallPaths installPaths = new InstallPaths(installType, version);
            //installPaths.getDrive();

            //assert
            if (OS.isWindows())
                assertEquals("Integration of testing NMS 7.5 current copy, return 0","i:\\NimBUS-install\\UR\\7.5.0\\GA\\7.5.0-B\\installUR.exe", installPaths.getInstaller());
            else
                assertEquals("Integration of testing NMS 7.5 current copy, return 0","/mnt/vg_main/vol01/QA/NimBUS-install/UR/7.5.0/GA/7.5.0-B/installUR_linux.bin", installPaths.getInstaller());

        }

        @Test
        public void given_valid_7_5_build_ur_params_getInstaller() throws FileNotFoundException {
            //arrange
            String installType = "UR";
            String version = "7.5";
            String build = "2014-01-15";

            //act
            InstallPaths installPaths = new InstallPaths(installType, version, build);

            //assert
            if (OS.isWindows())
                assertEquals("Integration of testing NMS 7.5 current copy, return 0","i:\\NimBUS-install\\UR\\7.5.0\\GA\\7.5.0-B\\installUR.exe", installPaths.getInstaller());
            else
                assertEquals("Integration of testing NMS 7.5 current copy, return 0","/mnt/vg_main/vol01/QA/NimBUS-install/UR/7.5.0/GA/7.5.0-B/installUR_linux.bin", installPaths.getInstaller());
        }
        /*
                @Test(expected = FileNotFoundException.class)
                public void given_invalid_7_5_build_nms_params_getInstaller() throws FileNotFoundException {
                    //arrange
                    String installType = "NMS";
                    String version = "7.5";
                    String build = "2014_01_22_12_05"; //should be 2014_01_22-12_05

                    //act
                    InstallPaths installPaths = new InstallPaths(installType, version, build);

                    installPaths.getInstaller();

                }
        */

    }

}
