package com.nimsoft.automation.installer;

import com.nimsoft.automation.utils.OS;
import com.nimsoft.automation.installer.InstallPaths;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.util.Map;

/**
 * Created by schja33 on 1/23/14.
 */
@RunWith(Enclosed.class)
public class InstallPathsTest {
    public static class Windows_Setup {
        private String installType;
        private String installTypeUmp;
        private String installTypeUr;
        private String version;
        private String version_75;
        private String build;
        private String build_75;
        private String build_ump_75;
        private String oldVersion;
        private String yesterdayDate;
        public String drive;
        private String installer;
        private String buildBnpp;
        private InstallPaths installPaths_nms;
        private InstallPaths installPaths_ump;
        private InstallPaths installPaths_ur;

        @Before
        public void arrange() throws FileNotFoundException {
            installType = "NMS";
            installTypeUmp = "UMP";
            installTypeUr = "UR";
            version = "7.1";
            version_75 = "7.5";
            oldVersion = "7.0";
            build = "";
            build_75 = "2014_01_20-04_07";
            build_ump_75 = "2014-01-17";
            buildBnpp = "release1.2";

//            act();
        }

        private void act() throws FileNotFoundException {
            installPaths_nms = new InstallPaths(installType,version);
            installPaths_ump = new InstallPaths(installTypeUmp,version);
            installPaths_ur = new InstallPaths(installTypeUr,version);

        }

        @Test
        public void valid_oldVersion_getInstaller() throws FileNotFoundException {
            InstallPaths installPaths = new InstallPaths(installType, oldVersion);
            if (OS.isWindows())
                assertEquals("Should return 7.0 locatino on fileshare", "i:\\NimBUS-install\\NMS\\7.0\\nmserver_7.0-GA\\Windows\\NoVM\\installNMS.exe", installPaths.getInstaller());
            else
                assertEquals("Should return 7.0 locatino on fileshare", "/mnt/vg_main/vol01/QA/NimBUS-install/NMS/7.0/nmserver_7.0-GA/Linux/NoVM/installNMS.bin", installPaths.getInstaller());
        }
        @Test
        public void valid_nms_short_getInstaller() throws Exception {
            installPaths_nms = new InstallPaths(installType,version);
            if (OS.isWindows())
                assertEquals("Should return 7.1 full path nms for Windows", "i:\\NimBUS-install\\NMS\\7.1\\nmserver_7.1-GA\\Windows\\NoVM\\installNMS.exe", installPaths_nms.getInstaller());
            else
                assertEquals("Should return 7.1 full path nms for Windows", "/mnt/vg_main/vol01/QA/NimBUS-install/NMS/7.1/nmserver_7.1-GA/Linux/NoVM/installNMS.bin", installPaths_nms.getInstaller());
        }

        @Test
        public void valid_ump_short_getInstaller() throws Exception {
            installPaths_ump = new InstallPaths(installTypeUmp,version);
            if (OS.isWindows())
                assertEquals("Should return 7.1 full path ump for Windows", "i:\\NimBUS-install\\UMP\\7.1.0\\GA\\7.1.0-B\\installUMP.exe", installPaths_ump.getInstaller());
            else
                assertEquals("Should return 7.1 full path ump for Windows", "/mnt/vg_main/vol01/QA/NimBUS-install/UMP/7.1.0/GA/7.1.0-B/installUMP_linux.bin", installPaths_ump.getInstaller());
        }
        @Test
        public void valid_ur_short_getInstaller() throws Exception{

            installPaths_ur = new InstallPaths(installTypeUr,version);
            if (OS.isWindows())
                assertEquals("Should return 7.1 full path ur for Windows", "i:\\NimBUS-install\\UR\\7.1.0\\GA\\7.1.0-B\\installUR.exe", installPaths_ur.getInstaller());
            else
                assertEquals("Should return 7.1 full path ur for Windows", "/mnt/vg_main/vol01/QA/NimBUS-install/UR/7.1.0/GA/7.1.0-B/installUR_linux.bin", installPaths_ur.getInstaller());
        }
        @Test
        public void valid_long_nms_getInstaller() throws FileNotFoundException {
            String versionLong = "7.5.0";
            InstallPaths installPathsLong = new InstallPaths(installType,versionLong);
            if (OS.isWindows())
                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\NMS\\7.5\\nmserver_7.5-GA\\Windows\\NoVM\\installNMS.exe", installPathsLong.getInstaller());
            else
                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/NMS/7.5/nmserver_7.5-GA/Linux/NoVM/installNMS.bin", installPathsLong.getInstaller());

        }

        @Test
        public void valid_NMS_7_6_VM_Win_Test() throws FileNotFoundException {
            String versionLong = "7.6.0";
            InstallPaths installPaths = new InstallPaths(installType, versionLong);
            if (OS.isWindows())
                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\NMS\\7.6\\nmserver_7.6-GA\\Windows\\VM\\installNMS.exe", installPaths.getInstaller());
            else
                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/NMS/7.6/nmserver_7.6-GA/Linux/NoVM/installNMS.bin", installPaths.getInstaller());
        }

        @Test
        public void valid_NMS_7_6_1_VM_Win_Test() throws FileNotFoundException {
            String versionLong = "7.6.1";
            Map<String, String> optsMap = null;
            InstallPaths installPaths = new InstallPaths("nms", versionLong, "NimBUS-install\\NMS\\7.6.1\\current\\Windows\\VM\\installNMS.exe", optsMap);
            if (OS.isWindows())
                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\NMS\\7.6.1\\current\\Windows\\VM\\installNMS.exe", installPaths.getInstaller());
            else
                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QANimBUS-install\\NMS\\7.6.1\\current\\Windows\\VM\\installNMS.exe", installPaths.getInstaller());
        }




        @Test
        public void valid_NMS_localInstaller() throws FileNotFoundException {
            String localInstaller = "C:\\tmp\\installNMS.exe";
            InstallPaths installPathsLong = new InstallPaths(localInstaller);

            assertEquals("should return correct path for nms Windows latest", "C:\\tmp\\installNMS.exe", installPathsLong.getInstaller());

        }

        @Test
        public void valid_long_ump_getInstaller() throws FileNotFoundException {
            String versionLong = "7.5.0";
            InstallPaths installPathsLong = new InstallPaths(installTypeUmp,versionLong);
            if (OS.isWindows())
                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\UMP\\7.5.0\\GA\\7.5.0-B\\installUMP.exe", installPathsLong.getInstaller());
            else
                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/UMP/7.5.0/GA/7.5.0-B/installUMP_linux.bin", installPathsLong.getInstaller());

        }

        @Test
        public void valid_long_ur_getInstaller() throws FileNotFoundException {
            String versionLong = "7.5.0";
            InstallPaths installPathsLong = new InstallPaths(installTypeUr,versionLong);
            if (OS.isWindows())
                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\UR\\7.5.0\\GA\\7.5.0-B\\installUR.exe", installPathsLong.getInstaller());
            else
                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/UR/7.5.0/GA/7.5.0-B/installUR_linux.bin", installPathsLong.getInstaller());

        }

        @Test
        public void valid_short_nms_getInstaller() throws FileNotFoundException {
            String versionsShort = "7.5";
            InstallPaths installPathsLong = new InstallPaths(installType,versionsShort);
            if (OS.isWindows())
                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\NMS\\7.5\\nmserver_7.5-GA\\Windows\\NoVM\\installNMS.exe", installPathsLong.getInstaller());
            else
                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/NMS/7.5/nmserver_7.5-GA/Linux/NoVM/installNMS.bin", installPathsLong.getInstaller());

        }

        @Test
        public void valid_short_ump_getInstaller() throws FileNotFoundException {
            String versionShort = "7.5";
            InstallPaths installPathsLong = new InstallPaths(installTypeUmp,versionShort);
            if (OS.isWindows())
                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\UMP\\7.5.0\\GA\\7.5.0-B\\installUMP.exe", installPathsLong.getInstaller());
            else
                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/UMP/7.5.0/GA/7.5.0-B/installUMP_linux.bin", installPathsLong.getInstaller());

        }

        @Test
        public void valid_short_ur_getInstaller() throws FileNotFoundException {
            String versionShort = "7.5";
            InstallPaths installPathsLong = new InstallPaths(installTypeUr,versionShort);
            if (OS.isWindows())
                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\UR\\7.5.0\\GA\\7.5.0-B\\installUR.exe", installPathsLong.getInstaller());
            else
                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/UR/7.5.0/GA/7.5.0-B/installUR_linux.bin", installPathsLong.getInstaller());

        }

        @Test
        public void valid_short_nms_76_getInstaller() throws FileNotFoundException {
            String versionsShort = "7.6";
            InstallPaths installPathsLong = new InstallPaths(installType,versionsShort);
            if (OS.isWindows())
                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\NMS\\7.6\\nmserver_7.6-GA\\Windows\\VM\\installNMS.exe", installPathsLong.getInstaller());
            else
                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/NMS/7.6/nmserver_7.6-GA/Linux/NoVM/installNMS.bin", installPathsLong.getInstaller());

        }

        @Test
        public void valid_short_ump_76_getInstaller() throws FileNotFoundException {
            String versionShort = "7.6";
            InstallPaths installPathsLong = new InstallPaths(installTypeUmp,versionShort);
            if(OS.isWindows())
                assertEquals("should return correct path for nms Windows", "i:\\NimBUS-install\\UMP\\7.6.0\\GA\\7.6.0-B\\installUMP.exe", installPathsLong.getInstaller());
            else
                assertEquals("should return correct path for nms Windows", "/mnt/vg_main/vol01/QA/NimBUS-install/UMP/7.6.0/GA/7.6.0-B/installUMP_linux.bin", installPathsLong.getInstaller());

        }

        @Test
        public void valid_short_ur_76_getInstaller() throws FileNotFoundException {
            String versionShort = "7.6";
            InstallPaths installPathsLong = new InstallPaths(installTypeUr,versionShort);
            if (OS.isWindows())
                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\UR\\7.6.0\\GA\\7.6.0-B\\installUR.exe", installPathsLong.getInstaller());
            else
                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/UR/7.6.0/GA/7.6.0-B/installUR_linux.bin", installPathsLong.getInstaller());

        }

        @Test
        public void valid_odd_old_nms_getInstaller() throws FileNotFoundException {
            String versionsOdd = "7.10";
            InstallPaths installPathsLong = new InstallPaths(installType,versionsOdd);
            if (OS.isWindows())
                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\NMS\\7.1\\nmserver_7.1-GA\\Windows\\NoVM\\installNMS.exe", installPathsLong.getInstaller());
            else
                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/NMS/7.1/nmserver_7.1-GA/Linux/NoVM/installNMS.bin", installPathsLong.getInstaller());

        }

        @Test
        public void valid_odd_old_ump_getInstaller() throws FileNotFoundException {
            String versionOdd = "7.10";
            InstallPaths installPathsLong = new InstallPaths(installTypeUmp,versionOdd);
            if (OS.isWindows())
                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\UMP\\7.1.0\\GA\\7.1.0-B\\installUMP.exe", installPathsLong.getInstaller());
            else
                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/UMP/7.1.0/GA/7.1.0-B/installUMP_linux.bin", installPathsLong.getInstaller());

        }

        @Test
        public void valid_odd_old_ur_getInstaller() throws FileNotFoundException {
            String versionOdd = "7.10";
            InstallPaths installPathsLong = new InstallPaths(installTypeUr,versionOdd);
            if (OS.isWindows())
                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\UR\\7.1.0\\GA\\7.1.0-B\\installUR.exe", installPathsLong.getInstaller());
            else
                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/UR/7.1.0/GA/7.1.0-B/installUR_linux.bin", installPathsLong.getInstaller());

        }



        @Test
        public void valid_long_ur_old_getInstaller() throws FileNotFoundException {
            String versionLong = "7.1.0";
            InstallPaths installPathsLong = new InstallPaths(installTypeUr,versionLong);
            if (OS.isWindows())
                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\UR\\7.1.0\\GA\\7.1.0-B\\installUR.exe", installPathsLong.getInstaller());
            else
                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/UR/7.1.0/GA/7.1.0-B/installUR_linux.bin", installPathsLong.getInstaller());

        }

        @Test
        public void valid_long_nms_old_getInstaller() throws FileNotFoundException {
            String versionLong = "7.1.0";
            InstallPaths installPathsLong = new InstallPaths(installType,versionLong);
            if (OS.isWindows())
                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\NMS\\7.1\\nmserver_7.1-GA\\Windows\\NoVM\\installNMS.exe", installPathsLong.getInstaller());
            else
                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/NMS/7.1/nmserver_7.1-GA/Linux/NoVM/installNMS.bin", installPathsLong.getInstaller());

        }

        @Test
        public void valid_long_ump_old_getInstaller() throws FileNotFoundException {
            String versionLong = "7.1.0";
            InstallPaths installPathsLong = new InstallPaths(installTypeUmp,versionLong);
            if(OS.isWindows())
                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\UMP\\7.1.0\\GA\\7.1.0-B\\installUMP.exe", installPathsLong.getInstaller());
            else
                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/UMP/7.1.0/GA/7.1.0-B/installUMP_linux.bin", installPathsLong.getInstaller());

        }

//        @Test
//        public void valid_bnpp_getInstaller() throws FileNotFoundException {
//            String versionLong = "7.50";
//            String bnpp = "bnpp";
//            InstallPaths installPathsLong = new InstallPaths(installType,versionLong, build, bnpp);
//            if (OS.isWindows())
//                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\nmserver_bnpp\\7.5\\current\\Windows\\VM\\installNMS_bnpp.exe", installPathsLong.getInstaller());
//            else
//                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/nmserver_bnpp/7.5/current/Linux/NoVM/installNMS_bnpp.bin", installPathsLong.getInstaller());
//
//        }
//
//        @Test
//        public void valid_bnpp_build_getInstaller() throws FileNotFoundException {
//            String versionLong = "7.50";
//            String bnpp = "bnpp";
//            InstallPaths installPathsLong = new InstallPaths(installType,versionLong, build_75, bnpp);
//            if (OS.isWindows())
//                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\nmserver_bnpp\\7.5\\" + build_75 + "\\Windows\\VM\\installNMS_bnpp.exe", installPathsLong.getInstaller());
//            else
//                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/nmserver_bnpp/7.5/2014_01_20-04_07/Linux/NoVM/installNMS_bnpp.bin", installPathsLong.getInstaller());
//
//        }
//
//
//
//        @Test
//        public void valid_bnpp_build_UMP_getInstaller() throws FileNotFoundException {
//            String versionLong = "7.50";
//            String bnpp = "bnpp";
//            InstallPaths installPathsLong = new InstallPaths(installTypeUmp, versionLong, build_ump_75, bnpp);
//            if (OS.isWindows())
//                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\UMP\\7.5.0\\GA\\7.5.0-B\\installUMP.exe", installPathsLong.getInstaller());
//            else
//                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/UMP/7.5.0/GA/7.5.0-B/installUMP_linux.bin", installPathsLong.getInstaller());
//
//        }
//
//        @Test
//        public void valid_bnpp_UMP_getInstaller() throws FileNotFoundException {
//            String versionLong = "7.50";
//            String bnpp = "bnpp";
//            InstallPaths installPathsLong = new InstallPaths(installTypeUmp, versionLong, build, bnpp);
//            if (OS.isWindows())
//                assertEquals("should return correct path for nms Windows latest", "i:\\NimBUS-install\\UMP\\7.5.0\\GA\\7.5.0-B\\installUMP.exe", installPathsLong.getInstaller());
//            else
//                assertEquals("should return correct path for nms Windows latest", "/mnt/vg_main/vol01/QA/NimBUS-install/UMP/7.5.0/GA/7.5.0-B/installUMP_linux.bin", installPathsLong.getInstaller());
//
//        }

        @Test
        public void valid_checklocalInstaller() throws FileNotFoundException {
            String localInstaller = "c:\\tmp\\installUMP.exe";
            InstallPaths installPathsLong = new InstallPaths(localInstaller);


            assertEquals("should return correct path for nms Windows latest", "c:\\tmp\\installUMP.exe", installPathsLong.getInstaller());

        }

//        @Test
//        public void checkBnppBuild_getInstaller() throws FileNotFoundException {
//            String versionLong = "7.50";
//            String bnpp = "bnpp";
//            InstallPaths installPaths = new InstallPaths(installType, versionLong, buildBnpp, bnpp);
//            if (OS.isWindows())
//                assertEquals("Should return the correct bnpp fileshare location", "i:\\NimBUS-install\\nmserver_bnpp\\7.5\\release1.2\\Windows\\VM\\installNMS_bnpp.exe", installPaths.getInstaller());
//            else
//                assertEquals("Should return the correct bnpp fileshare location", "/mnt/vg_main/vol01/QA/NimBUS-install/nmserver_bnpp/7.5/release1.2/Linux/NoVM/installNMS_bnpp.bin", installPaths.getInstaller());
//        }

        @Test
        public void valid_checkIfPre80Version() throws FileNotFoundException {
            String version = "7.50";
            InstallPaths installPaths = new InstallPaths(installType, version);
            assertEquals("should return true since the version is older than 8.0",true, installPaths.isPre80Version());
        }

        @Test
        public void valid80_checkIfPre80Version() throws FileNotFoundException {
            String newversion = "8.0";
            InstallPaths installPaths = new InstallPaths(installType, newversion);
            assertEquals("should return false since the version is  8.0",false, installPaths.isPre80Version());
        }

        @Test
        public void valid80_getInstaller() throws FileNotFoundException {
            String newversion = "8.0";
            InstallPaths installPaths = new InstallPaths(installType, newversion);
            if (OS.isWindows())
                assertEquals("should return false since the version is  8.0","i:\\NimBUS-install\\uimserver\\8.0\\uimserver_8.0-GA\\windows_x64\\VM\\setupCAUIMServer.exe", installPaths.getInstaller());
            else
                assertEquals("should return false since the version is  8.0","/mnt/vg_main/vol01/QA/NimBUS-install/uimserver/8.0/uimserver_8.0-GA/linux_x64/VM/setupCAUIMServer.bin", installPaths.getInstaller());
        }

        @Test
        public void valid_80NMS_setBuildFileDir() throws FileNotFoundException {
           String newVersion = "8.0";
            InstallPaths installPaths = new InstallPaths(installType, newVersion);
            assertEquals("Should return the new base location on the fileshare", "uimserver", installPaths.setBuildFileDir());
        }

        @Test
        public void valid_80UMP_setBuildFileDir() throws FileNotFoundException {
            String newVersion = "8.0";
            InstallPaths installPaths = new InstallPaths(installTypeUmp, newVersion);
            if (OS.isWindows())
                assertEquals("Should return the location and old name for UMP installers", "i:\\NimBUS-install\\UMP\\8.0.0\\GA\\8.0.0-B\\installUMP.exe", installPaths.getInstaller());
            else
                assertEquals("Should return the location and old name for UMP installers", "/mnt/vg_main/vol01/QA/NimBUS-install/UMP/8.0.0/GA/8.0.0-B/installUMP_linux.bin", installPaths.getInstaller());
        }


        @Test
        public void valid_76_setBuildFileDir() throws FileNotFoundException {
            String newVersion = "7.60";
            InstallPaths installPaths = new InstallPaths(installType, newVersion);
            assertEquals("Should return the new base location on the fileshare", "NMS", installPaths.setBuildFileDir());
        }

        @Test
        public void formatVersionNMSTest() throws FileNotFoundException {
            String version = "8.3";
            InstallPaths path = new InstallPaths(installType, version);
            String testFormat = path.formatVersion(version);

            assertEquals("Should set the version correctly", "8.3", path.formatVersion(version));
        }

        @Test
        public void formatVersionNMSOddVersionTest() throws FileNotFoundException {
            String version = "8.31";
            InstallPaths path = new InstallPaths(installType, version);
            String testFormat = path.formatVersion(version);

            assertEquals("Should set the version correctly", "8.31", path.formatVersion(version));
        }

        @Test
        public void formatVersionNMSOddVersion2Test() throws FileNotFoundException {
            String version = "8.30";
            InstallPaths path = new InstallPaths(installType, version);
            String testFormat = path.formatVersion(version);

            assertEquals("Should set the version correctly", "8.3", path.formatVersion(version));
        }

        @Test
        public void formatVersionUMPTest() throws FileNotFoundException {
            String version = "8.30";
            InstallPaths path = new InstallPaths(installTypeUmp, version);
            String testFormat = path.formatVersion(version);

            assertEquals("Should set the version correctly", "8.3.0", path.formatVersion(version));
        }

        @Test
        public void formatVersionUmpOddVersionTest() throws FileNotFoundException {
            String version = "8.3";
            InstallPaths path = new InstallPaths(installTypeUmp, version);
            String testFormat = path.formatVersion(version);

            assertEquals("Should set the version correctly", "8.3.0", path.formatVersion(version));
        }

        @Test
        public void formatVersionUmpOddVersion2Test() throws FileNotFoundException {
            String version = "8.30";
            InstallPaths path = new InstallPaths(installTypeUmp, version);
            String testFormat = path.formatVersion(version);

            assertEquals("Should set the version correctly", "8.3.0", path.formatVersion(version));
        }

        @Test
        public void formatVersionUmpOddVersion3Test() throws FileNotFoundException {
            String version = "8.3.1";
            InstallPaths path = new InstallPaths(installTypeUmp, version);
            String testFormat = path.formatVersion(version);

            assertEquals("Should set the version correctly", "8.3.1", path.formatVersion(version));
        }

        @Test
        public void latestInstallerTest() throws FileNotFoundException {
            String version = "8.4";

            InstallPaths installPaths = new InstallPaths(installType, version);
            System.out.println("\n\n newInstall path: " + installPaths.latestIntaller("\\\\fileshare\\QA\\NimBUS-install\\uimserver\\8.4\\"));
        }

        @Test
        public void latestInstaller1Test() throws FileNotFoundException {
            String version = "8.2";

            InstallPaths installPaths = new InstallPaths(installType, version);
            System.out.println("\n\n newInstall path: " + installPaths.latestIntaller("\\\\fileshare\\QA\\NimBUS-install\\uimserver\\8.2\\"));
        }

        @Test
        public void tempNewBuildFileDir() throws FileNotFoundException {
            String newVersion = "7.60";
            InstallPaths installPaths = new InstallPaths(installType, newVersion);
            installPaths.init();
//            System.out.println(installPaths);
            //assertEquals("Should return the new base location on the fileshare", "NMS", installPaths.setBuildFileDir());
        }

        @Test
        public void checkPackagesTrueTest() throws FileNotFoundException{
            String newVersion = "8.40";
            InstallPaths installPaths = new InstallPaths(installType, newVersion);
            installPaths.init();
            assertTrue("uimserverpackages.zip should exist for the 8.4 installer", installPaths.packagesExist());
            //TODO: change this line to not hard code a path that will not persist after 8.4 release
            assertTrue("uimserverpackages.zip should exist for the 8.4 installer",
                    installPaths.checkPackages("\\\\fileshare.dev.fco\\QA\\NimBUS-install\\uimserver\\8.4\\2015_09_27-22_23\\windows_x64\\VM\\"));

        }

        @Test
        public void checkPackagesFalseTest() throws FileNotFoundException{
            String newVersion = "8.3";
            InstallPaths installPaths = new InstallPaths(installType, newVersion);
            installPaths.init();
            assertFalse("uimserverpackages.zip should exist for the 8.4 installer", installPaths.packagesExist());
            assertFalse("uimserverpackages.zip should not exist for the 8.3 installer",
                    installPaths.checkPackages("\\\\fileshare.dev.fco\\QA\\NimBUS-install\\uimserver\\8.3\\uimserver_8.3-CR\\linux_x64\\VM\\"));

        }

        @Test
        public void installerDirTest() throws FileNotFoundException{
            String newVersion = "8.3";
            InstallPaths installPaths = new InstallPaths(installType, newVersion);
            installPaths.init();
            assertTrue("Full path should contain the install dir",
                    installPaths.getFullDir().contains(installPaths.installerDir()));
            assertFalse("install dir should not contain the installer name",
                    installPaths.installerDir().contains(installPaths.getInstallName()));
            assertFalse("Fulldir should not equal install dir",
                    installPaths.fullDir.equals(installPaths.installerDir()));

        }


    }
}
